import React from "react";
import { DatePicker } from "csg-react-magnetic/date-picker";

// Adds support for pressing the <enter> key in the field and submitting a form
// if there is a submit button in the form
const DatePickerWithEnter = props => {
  const handleKeyDown = event => {
    if (event.key === "Enter") {
      event.preventDefault();

      const form = event.target.closest("form");

      if (form) {
        const submitButton = form.querySelector('button[type="submit"]');
        if (submitButton) {
          submitButton.click();
        }
      }
    }
  };

  return (
    <DatePicker
      {...props}
      onKeyDown={event => {
        handleKeyDown(event);
        if (props.onKeyDown) props.onKeyDown(event);
      }}
    />
  );
};

export { DatePickerWithEnter };
