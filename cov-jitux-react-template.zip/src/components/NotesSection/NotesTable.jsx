import styles from "./NotesTable.module.css";

import { useState } from "react";

import { DataGrid, ColumnResizeMode, DataGridSortSelectModeType, DataGridSortOrderType } from "csg-react-magnetic/data-grid";

import { ButtonBar } from "components/ButtonBar";
import { ToolbarButton } from "components/ToolbarButton";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

function NotesTable({ noteList, isEditable, onEditNote }) {
  // Setup initial sort order for table. Can sort on multiple columns by listing multiple
  // object in the sortParams array.
  const [sortable, setSortable] = useState({
    sortMode: DataGridSortSelectModeType.Multiple,
    sortParams: [{ sortColumn: "dateAdded", sortOrder: DataGridSortOrderType.Ascending }],
    onSort: sortedColumns => {
      const params = sortedColumns.multiSort?.map(({ sortColumn, sortOrder }) => ({ sortColumn, sortOrder })) || [];
      setSortable(prev => ({ ...prev, sortParams: params }));
    }
  });

  // headerTemplate: used to control the display in the table column header
  // template: used to control the display in the row for a specific column (the data cell, td element)
  const columnTemplates = [
    {
      id: "dateAdded",
      name: "Date Added",
      sortable: true,
      headerStyle: { minWidth: "225px", maxWidth: "225px", width: "225px" }
    },
    {
      id: "user",
      name: "User",
      sortable: true,
      headerStyle: { minWidth: "50px", maxWidth: "225px", width: "225px" }
    },
    {
      id: "note",
      name: "Note",
      sortable: true,
      headerStyle: { minWidth: "225px" },
      template: (col, row) => <p className={styles.notesColumn}>{`${row.note}`}</p>
    }
  ];

  if (isEditable) {
    columnTemplates.push({
      id: "action",
      name: "Action",
      sortable: false,
      headerStyle: { minWidth: "100px" },
      template: (col, row) => (
        <ButtonBar variant="toolbar">
          <ToolbarButton title="Edit Note" icon="edit" onClick={() => onEditNote(row.note, "user", "noteId")} />
        </ButtonBar>
      )
    });
  }

  return (
      <DataGrid
        className={styles.striped}
        columns={columnTemplates}
        data={noteList}
        sortable={sortable}
        pageable={{
          paginator: true,
          first: 0,
          rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
          rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
        }}
        reorderable={{
          reorderableColumns: true,
          onColumnReorder: (dragIndex, dropIndex, reOrderedColumns) => {
            console.log(`dragIndex: ${dragIndex}  dropIndex: ${dropIndex}`);
            console.log(reOrderedColumns);
          }
        }}
        resizable={{
          columnResizeMode: ColumnResizeMode.Expand,
          onColumnResize: e => {
            console.log(e);
          }
        }}
      />
  );
}

export { NotesTable };
