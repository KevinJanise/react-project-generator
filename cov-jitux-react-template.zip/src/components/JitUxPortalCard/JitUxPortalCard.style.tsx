import { css } from "csg-react-magnetic/styled";
import { styled } from "@magnetic/react-components";
import { Enlyte } from "@magnetic/tokens";
import { ApplicationCard } from "csg-react-magnetic/application-card";

export const StyledApplicationCard = styled(ApplicationCard)(
  ({ theme: { Mag = Enlyte } }) => css`
    
  `
);
