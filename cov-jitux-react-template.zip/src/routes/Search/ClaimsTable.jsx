import styles from "./ClaimsTable.module.css";

import { useState } from "react";
import { Link } from "react-router-dom";
import { DataGrid, DataGridSortSelectModeType, DataGridSortOrderType } from "csg-react-magnetic/data-grid";
import { ToolbarButton } from "components/ToolbarButton";
import { ButtonBar } from "components/ButtonBar";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

const ClaimsTable = ({ claimList, onEdit, onTerminate, onClaimSelected }) => {
  // Setup initial sort order for table. Can sort on multiple columns by listing multiple
  // objects in the sortParams array.
  const [sortable, setSortable] = useState({
    sortMode: DataGridSortSelectModeType.Multiple,
    sortParams: [{ sortColumn: "claimantName", sortOrder: DataGridSortOrderType.Ascending }],
    onSort: sortedColumns => {
      const params = sortedColumns.multiSort?.map(({ sortColumn, sortOrder }) => ({ sortColumn, sortOrder })) || [];
      setSortable(prev => ({ ...prev, sortParams: params }));
    }
  });

  // headerTemplate: used to control the display in the table column header
  // template: used to control the display in the row for a specific column (the data cell, td element)
  const columnTemplates = [
    {
      id: "status",
      name: "Claim Status",
      sortable: true,
      headerStyle: { minWidth: "150px" },
      headerTemplate: col => <span className="wrapAtSpaces">{col.name}</span>
    },
    {
      id: "claimNumber",
      name: "Claim Number",
      sortable: true,
      headerStyle: { minWidth: "160px" },
      headerTemplate: col => <span className="wrapAtSpaces">{col.name}</span>,
      template: (_, row) => <Link to={`/claimActivity/${row.claimNumber}`}>{row.claimNumber}</Link>
    },
    {
      id: "claimantName",
      name: "Claimant Name",
      sortable: true,
      headerStyle: { minWidth: "190px" },
      template: (_, row) => <span>{`${row.claimantFirstName} ${row.claimantLastName}`}</span>
    },
    {
      id: "dob",
      name: "Date of Birth",
      sortable: true,
      headerStyle: { minWidth: "140px" },
      headerTemplate: col => <span className="wrapAtSpaces">{col.name}</span>
    },
    {
      id: "doi",
      name: "Date of Injury",
      sortable: true,
      headerStyle: { minWidth: "140px" },
      headerTemplate: col => <span className="wrapAtSpaces">{col.name}</span>
    },
    {
      id: "employer",
      name: "Employer",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "action",
      name: "Action",
      headerStyle: { width: "auto", minWidth: "150px" },
      template: (_, row) => (
        <ButtonBar variant="toolbar">
          <ToolbarButton icon="delete" title="Terminate" onClick={() => onTerminate(row.claimNumber)} />
          <ToolbarButton icon="edit" title="Edit" onClick={() => onEdit(row.claimNumber)} />
        </ButtonBar>
      )
    }
  ];

  return (
    <DataGrid
      className={styles.striped}
      data={claimList}
      columns={columnTemplates}
      selectable={{
        trackByColumn: "claimNumber",
        multiselect: true,
        showCheckbox: true,
        selectAllState: "unchecked"
      }}
      onSelect={selectedClaims => onClaimSelected(selectedClaims)}
      sortable={sortable}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
    />
  );
};

export { ClaimsTable };
