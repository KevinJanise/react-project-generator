import styles from "./ClaimSearchResults.module.css";

import { Link } from "react-router-dom";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { ClaimsTable } from "./ClaimsTable";

function ClaimSearchResults({ claimList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasResults = claimList && claimList.length > 0;

  const handleClaimsSelected = selectedClaims => {
    console.log(selectedClaims);
  };

  const handleTerminate = claimNumber => {
    console.log(`Terminating claim number: ${claimNumber}`);
    onStatusUpdate({ isSuccess: true, message: `Terminated claim number: ${claimNumber}` });
  };

  const handleEdit = claimNumber => {
    console.log(`Editing claim number: ${claimNumber}`);
    onStatusUpdate({ isSuccess: false, isError: true, message: `Error editing claim number: ${claimNumber}` });
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection className={styles.claimSearchResults}>
        {!errorMessage && (
          <p className={styles.claimNotFoundMessage}>
            Claim not found?{" "}
            <Link to={"/submitOrder"} className={styles.submitOrderLink}>
              Submit Order / Referral for a new Claim
            </Link>
          </p>
        )}

        {hasResults && (
          <Grid>
            <Row>
              <Column width="100%">
                <ClaimsTable
                  claimList={claimList}
                  onEdit={handleEdit}
                  onTerminate={handleTerminate}
                  onClaimSelected={handleClaimsSelected}
                />
              </Column>
            </Row>
          </Grid>
        )}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
      </PageSection>
    </LoadingIndicator>
  );
}

export { ClaimSearchResults };
