import styles from "./Search.module.css";

import { useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { TextField } from "csg-react-magnetic/text-field";

import { ButtonBar } from "components/ButtonBar";
import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useConfig } from "hooks/config";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { usePageState } from "hooks/usePageState";

import { FindClaimsCommand } from "services/FindClaimsCommand";

import { ClaimSearchResults } from "./ClaimSearchResults";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

function Search() {
  let config = useConfig();
  console.log("service url = " + config.serviceUrl);

  const [claimList, setClaimList] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [message, setMessage] = useState(null);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();

  let initialFormState = { claimNumber: "", claimantName: "" };
  const { formData, resetForm, handleMagneticChange, setFormData, trimValue } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  // Repopulate state variables and make service calls to get data when component mounts.
  // savePageState is manually called in handleClaimSearch and saves the form data.
  const { savePageState, clearPageState } = usePageState(
    "_Search",
    pageState => {
      setFormData(pageState.formData);
      setHasSearched(pageState.hasSearched);
      doClaimSearch(pageState.formData);
    },
    null
  );

  const validateForm = () => {
    clearErrorMessages();

    // if form is empty display an error message
    if (Validator.isEmpty(formData)) {
      addErrorMessage("global", "Please enter search criteria.");
      return false;
    }

    if (Validator.isNotEmpty(formData.claimNumber) && Validator.length(formData.claimNumber) < 3) {
      addErrorMessage("claimNumber", "Enter at least 3 characters.");
    }

    if (Validator.isEmpty(formData.claimantName)) {
      addErrorMessage("claimantName", "Enter claimant name.");
    }

    return !hasFieldSpecificErrors();
  };

  const doClaimSearch = async searchCriteria => {
    clearSearchResults();

    setHasSearched(true);

    let command = new FindClaimsCommand(searchCriteria);
    let result = await execute(command);

    if (result.isSuccess) {
      let list = result.value;

      setClaimList(list);

      if (Utils.isObjectEmpty(list)) {
        setMessage("No claims were found.");
        showSuccessGrowler("No claims were found.");
      } else {
        showSuccessGrowler(list.length === 1 ? "Found 1 claim." : `Found ${list.length} claims.`);
      }
    } else {
      let error = result.error;
      let errorMessage = null;

      console.error(error);

      if (error.message === "Failed to fetch") {
        errorMessage = "There was an error connecting to the server.";
      } else {
        errorMessage = "There was an error processing your request.";
      }

      setErrorMessage(errorMessage);
      showErrorGrowler(errorMessage);
    }
  };

  // Do the search when the user submits the form either by clicking on the Search button
  // or pressing <Enter> while the Claim Number field has the focus.
  const handleClaimSearch = async event => {
    event.preventDefault();

    clearSearchResults();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    setHasSearched(true);

    // Save the validated form data but not the claim list. Reload list when page reloads.
    savePageState({ formData: formData, hasSearched: true });

    doClaimSearch(formData);
  };

  const showStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    setErrorMessage(null);
    setHasSearched(false);
    setClaimList(null);
  };

  const handleClear = () => {
    clearSearchResults();
    resetForm();
    clearPageState();
  };

  return (
    <div className={styles.search}>
      <PageTitle title="Search" />

      <PageSection>
        <BlockMessage variant="error" style={{ marginBottom: "1rem" }}>
          {getErrorMessage("global")}
        </BlockMessage>

        <form onSubmit={handleClaimSearch}>
          <Grid>
            <Row>
              <Column width="50%">
                <TextField
                  label="Claim Number"
                  name="claimNumber"
                  required
                  onChange={handleMagneticChange("claimNumber", "text")}
                  value={formData.claimNumber}
                  validationError={getErrorMessage("claimNumber")}
                />
              </Column>

              <Column width="50%">
                <TextField
                  label="Claimant Name"
                  name="claimantName"
                  required
                  onChange={handleMagneticChange("claimantName", "text")}
                  value={formData.claimantName}
                  validationError={getErrorMessage("claimantName")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="100%">
                <ButtonBar>
                  <Button variant="primary" type="submit" loading={isExecuting}>
                    Search
                  </Button>

                  <Button variant="outline" type="button" onClick={handleClear}>
                    Clear
                  </Button>
                </ButtonBar>
              </Column>
            </Row>
          </Grid>
        </form>
      </PageSection>

      {hasSearched && (
        <ClaimSearchResults
          claimList={claimList}
          isLoading={isExecuting}
          resultMessage={message}
          errorMessage={errorMessage}
          onStatusUpdate={showStatusUpdate}
        />
      )}
    </div>
  );
}

export { Search };
