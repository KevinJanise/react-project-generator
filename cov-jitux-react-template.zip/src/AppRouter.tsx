import { Switch, Route, Redirect } from "react-router-dom";

import { Components } from "routes/Components";
import { Search } from "routes/Search";

interface IAppRouterProps {
  baseHref?: string;
}

export default function AppRouter({ baseHref }: Readonly<IAppRouterProps>) {
  return (
    <Switch>
      <Route exact path="/components" component={Components} />
      <Route exact path="/search" component={Search} />
      <Route path="*">
        <Redirect to="/search" />
      </Route>
    </Switch>
  );
}
