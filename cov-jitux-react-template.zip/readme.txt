If you have any questions contact Kevin.Janise@enlyte.com

Base project for a new JIT-UX application using Magnetic Components

This is an "in-progress" template project. It was started as a "notes to myself" but other people started using it so I'm in the process of cleaning it up to make it more polished. The idea is that you'll strip out the pages in the routes directory and the Commands in the services directory and replace them with your own. It shows basic use of the Magnetic components with working code so you can easily copy them into your pages. I am currently working on a code generator which will build skeleton components, pages, tables quickly and easily. 

Kevin.Janise@enlyte.com
4/10/2025


Use Node version 20 or later: nvm use 23.8.0

1. Clone template project: https://github.com/enlyte-cov/cov-jitux-react-template.git

2. Copy content except for .git and node_modules into new project

3. In Visual Studio Code
   a. Global search and replace, Match Case, globally change cov-jitux-react-template to [YOUR_PROJECT_NAME]
   
   b. Rename src/cov-jitux-react-template.card.tsx to [YOUR_PROJECT_NAME].card.tsx
   c. Rename src/cov-jitux-react-template.tsx to [YOUR_PROJECT_NAME].tsx

4. Open terminal window in VSC
   a. npm install
   b. npm start   
   c. If using JIT-UX use npm run start:jitux

CSS 
This project uses React's CSS Modules. They are close to "normal" CSS and still provides unique class names so
you don't have to be concerned with naming collisions. It also keeps the CSS and component code "close" so it
is easy to manage and find.


Generic components
Components that can be used across multiple pages are in the "components" folder each in a separate directory.

Pages are in the "routes" folder.

Commands for service calls are in the "services" folder.

Sample Code
All of the sample code is in the src/routes/Home and Search directory. You can delete the directory content or copy it out to a 
backup directory so you have code examples showing how to do things. 


Routes / Navigation
The routes for the samples are in src/AppRouter.tsx. Replace the sample routes with your own routes. 
Links for the menu are in src/components/MenuBar/MenuBar.js


Configuration
The config file, config.json, with the service URLs and other config information is in public/dist/config/config.json. 
Edit it and add properties as needed. You can use the useConfig hook to get the config file then access properties
from any React component. In a JavaScript file, non React, you can use: let config = Config.getInstance();
To get a property it is config.propertyName

In our environment we do one build and the same build image is copied to DEV, QA, UAT, and PROD. A different
config file is copied to the public/dist/config directory. This way we can be sure that the image that was
tested is the one that was promoted.


Services
Services are based on the Command pattern. You extend src/services/Command and implement an execute method. 
Behind the scenes it uses a retryableFetch function which will automatically retry failed attempts 3 times 
and will timeout after 30 seconds on each attempt. The retryableFetch is a drop-in replacement for fetch and
it adds the ability to retry calls with an exponential delay with jitter between attempts and timeouts for
individual requests. The default timeout is defined in the Command object. The retryableFetch is in the utils directory and retries 1 time with a 30 second timeout.

All of those parameters can be configured via your Command object. You execute a command using the useCommand hook.
You can execute a single Command at a time using execute(command) or an array of Commands that can complete
in any order via the executeAsync([command1, command2]) function.
It also provides a cancel function which can be used to cancel unexecuted commands. If your component unmounts 
then the command is automatically cancelled.



Misc Notes - TODO - Clean up and Organize notes received from other people

Install nvm

Point to repo for Magnetic components

1.	Node
You may need to change versions of Node, not sure. This nvm works great for allowing different versions of Node to co-exist on your machine. Natively you can only have one verison.
 
Latest version of nvm: https://github.com/coreybutler/nvm-windows/releases
 
2.	NPM Config file
You should have a .npmrc file in your home directory: C:\Users\[YOUR_USER_ID]
 
Edit it to include our internal repos
 
.npmrc
registry=https://repo.aws.int:443/artifactory/api/npm/npm-repo
@mi:registry=https://repo.aws.int/artifactory/api/npm/npm-repo/
strict-ssl=false



We have imported Magnetic UI library in our code base and now it is working fine  after resolving this issue "GET https://registry.npmjs.org/csg-react-magnetic - Not found.
npm error 404  'csg-react-magnetic@*' is not in this registry."

There are few steps I believe that we can add in documentation of Magnetic UI:
1.	 Current supported React version is 17 so we cannot use  version 18 or 19 as few component in magnetic like textfield does not support latest version.
2.	 Need to update certificate before using Magnetic, below is the steps to update:
Update the URL
Run this to make sure that your URL is correct.
Note that this has a different URL and is https and your URL (highlighted in your email) is different.
npm config set registry https://repo.aws.int/artifactory/api/npm/npm-repo/ -g
 Download the new cert here
https://repo.aws.int/artifactory/installers/certs/corp-cert01ntv-ca.crt
 Install the certificate
Run the following npm command and replace the file name in quotes with the path to the certificate that you downloaded.
npm config set cafile "path-to-my-cert.pem"  <<< You have to change the name in quotes to your cert name.


