import { Command } from "./Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";

class ApproveOrdersCommand extends Command {
  static OPERATION = "APPROVE_ORDERS";

  constructor(orderList, comments) {
    const config = Config.getInstance();
    let url = `${config.serviceUrl}/order-api/v1/order-history`;

    super(url);

    this.orderList = orderList;
    this.comments = comments;
  }

  async execute() {
    try {
        let params = {orderList: this.orderList, comments: this.comments};
        console.log("ApproveOrdersCommand", params);

        await Utils.pause(3500);
        
        return {msg: "ok"}
      //return await this.post(params);
    } catch (error) {
      if (error.response.status === 404) {
        console.log("404 error", error.response);

        return {};
      } else {
        throw error;
      }
    }
  }
}

export { ApproveOrdersCommand };
