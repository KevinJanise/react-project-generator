import { Command } from "./Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";

class SendEmailCommand extends Command {
  static OPERATION = "SEND_EMAIL";

/**
 * Creates a new instance for finding claims.
 * 
 * @constructor
 * @param {Object} searchCriteria - The search criteria for finding claims.
 * @param {Object} [options={}] - Configuration options for the instance.
 * @param {Object} [options.fetchOptions={}] - Options for the fetch API.
 * @param {Object} [options.retryOptions={}] - Options for the retry mechanism.
 * @param {number} [options.retryOptions.maxAttempts=3] - Maximum number of retry attempts.
 * @param {number} [options.retryOptions.baseDelay=1000] - Base delay in milliseconds between retry attempts.
 * @param {number} [options.retryOptions.timeout=30000] - Timeout in milliseconds for an individual retry attempt.
 */
  constructor(message, options = {}) {
    const config = Config.getInstance();
    const endpoint = "/dist/sendEmail.json";
    const url = `${config.serviceUrl}${endpoint}`;
  
    const defaultRetryOptions = {
      maxAttempts: 3,
      baseDelay: 555,
      timeout: 5555
    };
  
    const mergedOptions = {
      ...options,
      retryOptions: {
        ...defaultRetryOptions,
        ...options.retryOptions
      }
    };
  
    super(url, mergedOptions);
  
    this.message = message;
  }

  async execute() {
    try {
      // TODO remove this pause, used to demo loading indicator
      await Utils.pause(3000);

      // this would be post not get but for demo purposes we're using that
      let result = await this.get();   //this.post(message)
      console.log("result", result);

      return result;
    } catch (error) {
      // assumes if you get a 404 error the search results were not found and
      // you did not have an incorrect URL such as the wrong domain name or port
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { SendEmailCommand };
