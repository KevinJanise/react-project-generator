import { Command } from "./Command";
import { Config } from "hooks/config";

import * as FormatUtils from "utils/FormatUtils";
import * as Utils from "utils/Utils";

// the username is just for DEV, it makes you appear as though your logged in
function getMergedOptions(options) {
  const fetchOptionsWithDefaults = {
    headers: {
      username: "LHDIGB" // searchCriteria.username"" // or your specific username
//       username: "TEADCNA"
    },
    ...(options.fetchOptions ?? {})
  };

  const retryOptionsWithDefaults = {
    maxAttempts: 3,
    baseDelay: 1000,
    timeout: 30000,
    ...(options.retryOptions ?? {})
  };

  let mergedOptions = {
    ...options,
    fetchOptions: fetchOptionsWithDefaults,
    retryOptions: retryOptionsWithDefaults
  };

  return mergedOptions;
}

class FindUserCoverageCommand extends Command {
  static OPERATION = "FIND_USER_COVERAGE";

  constructor(userAccountId, options = {}) {
    const config = Config.getInstance();
    let url = null;

    let endpoint = `/coverage-api/v1/user-coverage/${userAccountId}`;

    let mergedOptions = options; // getMergedOptions(options);
//    console.log("mergedOptions", mergedOptions);

    url = `${config.serviceUrl}${endpoint}`;

    super(url, mergedOptions);

    this.userAccountId = userAccountId;
  }

  prepareSearchParams() {
    let searchParams = this.searchCriteria;
    /*
    {
        "adjuster-account-id": this.searchCriteria.assignedTo
    };
*/

    return searchParams;
  }

  processSearchResults(results) {
    let orderList = results.map(result => {
      let startDate = FormatUtils.formatDate(new Date(result.beginDt));
      let throughDate = FormatUtils.formatDate(new Date(result.endDt));
      let coverageFor = result.adjusterName;
      
      // Return a new object with the formatted information
      return {
        ...result,
        startDate,
        throughDate,
        coverageFor
      };
    });

    return orderList;
  }

  async execute() {
    try {
      let searchParams = this.prepareSearchParams();

      console.log(searchParams);

      await Utils.pause(3000);

      // searchParams will be translated into query parameters
      let result = await this.get();
      console.log("result", result);
      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindUserCoverageCommand };
