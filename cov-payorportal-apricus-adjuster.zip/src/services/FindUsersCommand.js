import { Command } from "./Command";
import { Config } from "hooks/config";
import * as Utils from "utils/Utils";
import * as FormatUtils from "utils/FormatUtils";

class FindUsersCommand extends Command {
  static OPERATION = "FIND_USERS";

  constructor(searchCriteria, options = {}) {
    const config = Config.getInstance();
    let url = null;
    let endpoint = "/dist/findUsers.json";

    url = `${config.serviceUrlLocal}${endpoint}`;
    //url = "http://localhost:3060/dist/findUsers.json";

    super(url);

    this.searchCriteria = searchCriteria;
  }

  prepareSearchParams() {
    let searchParams = {};

    searchParams = {...this.searchCriteria};

    return searchParams;
  }

  processSearchResults(results) {
    return results;
  }

  async execute() {
    try {
      let searchParams = this.prepareSearchParams();

      console.log(searchParams);

      // searchParams will be translated into query parameters
      let result = await this.get(searchParams);
      console.log("result", result);
      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindUsersCommand };
