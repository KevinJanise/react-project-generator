import { Command } from "./Command";
import { Config } from "hooks/config";

import * as FormatUtils from "utils/FormatUtils";
import * as Utils from "utils/Utils";

class FindClaimDetailCommand extends Command {
  static OPERATION = "FIND_CLAIM_DETAIL";

  /**
   * Creates a new instance for finding claims.
   *
   * @constructor
   * @param {Object} searchCriteria - The search criteria for finding claims.
   * @param {Object} [options={}] - Configuration options for the instance.
   * @param {Object} [options.fetchOptions={}] - Options for the fetch API.
   * @param {Object} [options.retryOptions={}] - Options for the retry mechanism.
   * @param {number} [options.retryOptions.maxAttempts=3] - Maximum number of retry attempts.
   * @param {number} [options.retryOptions.baseDelay=1000] - Base delay in milliseconds between retry attempts.
   * @param {number} [options.retryOptions.timeout=30000] - Timeout in milliseconds for an individual retry attempt.
   */
  constructor(searchCriteria, options = {}) {
    const config = Config.getInstance();
    let endpoint = "/claim-api/v1/claim-activity";
    const url = `${config.serviceUrl}${endpoint}`;

    const defaultRetryOptions = {
      maxAttempts: 3,
      baseDelay: 555,
      timeout: 5555
    };

    const mergedOptions = {
      ...options,
      retryOptions: {
        ...defaultRetryOptions,
        ...options.retryOptions
      }
    };

    super(url, mergedOptions);

    this.searchCriteria = { ...searchCriteria };
  }

  // Transform incoming search criteria into format the back-end system needs
  prepareSearchParams() {
    let searchParams = {
      "order-date-min": FormatUtils.formatDate(this.searchCriteria.beginDate, "YYYY-MM-DD"),
      "be-id": this.searchCriteria.beId,
      "source-system-cd": this.searchCriteria.sourceSystemCd,
      "source-system-claim-id": this.searchCriteria.sourceSystemClaimId,
      "source-system-claimant-id": this.searchCriteria.sourceSystemClaimantId
    };

    return searchParams;
  }

  processSearchResults(results) {
    return results;
  }

  async execute() {
    try {
      // TODO remove this pause, used to demo loading indicator
      await Utils.pause(3000);

      let searchParams = this.prepareSearchParams();

      // searchParams will be translated into query parameters
      // If no query parameters are used and the incoming searchCriteria
      // was added to the endpoint of the URL then just use this.get();
      let result = await this.get(searchParams);
      console.log("result", result);

      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      // assumes if you get a 404 error the search results were not found and
      // you did not have an incorrect URL such as the wrong domain name or port
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindClaimDetailCommand };
