import { Command } from "./Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";

class FindOrderListByAdjusterCommand extends Command {
  static OPERATION = "FIND_ORDER_LIST_BY_ADJUSTER";

  /**
   * Creates a new instance for finding orders.
   *
   * @constructor
   * @param {Object} searchCriteria - The search criteria
   * @property {string} assignedTo - The adjuster account id
   * @property {('PENDING'|'ACTIVE'|'COMPLETED')[]} phases - The phases of the task
   * @param {Object} [options={}] - Configuration options for the instance.
   * @param {Object} [options.fetchOptions={}] - Options for the fetch API.
   * @param {Object} [options.retryOptions={}] - Options for the retry mechanism.
   * @param {number} [options.retryOptions.maxAttempts=3] - Maximum number of retry attempts.
   * @param {number} [options.retryOptions.baseDelay=1000] - Base delay in milliseconds between retry attempts.
   * @param {number} [options.retryOptions.timeout=30000] - Timeout in milliseconds for an individual retry attempt.
   */
  constructor(searchCriteria, options = {}) {
    const config = Config.getInstance();
    //const endpoint = "/order-api/v1/order-list-by-adjuster?adjuster-account-id=001DM00002OQxjJYAT&phases=PENDING,ACTIVE,COMPLETED";
    // const endpoint = `/order-api/v1/order-list-by-adjuster?adjuster-account-id=${searchCriteria.assignedTo}&phases=PENDING,ACTIVE,COMPLETED`;
    const endpoint = "/order-api/v1/order-list-by-adjuster";
    const url = `${config.serviceUrl}${endpoint}`;

    console.log(url);

    const defaultRetryOptions = {
      maxAttempts: 3,
      baseDelay: 555,
      timeout: 5555
    };

    const mergedOptions = {
      ...options,
      retryOptions: {
        ...defaultRetryOptions,
        ...options.retryOptions
      }
    };

    super(url, mergedOptions);

    this.searchCriteria = searchCriteria;
  }

  // Take params from UI and transform then into what is needed for
  // the back-end services.
  prepareSearchParams() {
    let searchParams = {};
    searchParams = {
      "adjuster-account-id": this.searchCriteria.assignedTo, //  "001DM00002OQxjJYAT"
      "phases": this.searchCriteria.phases.join(",")
    };

    return searchParams;
  }

  processSearchResults(results) {
    return results;

    let orderList = results.map(result => {
      // let startDate = FormatUtils.formatDate(new Date(result.orderDt));
      //    let throughDate = FormatUtils.formatDate(new Date(result.endDt));
      //    let coverageFor = result.adjusterName;

      let userAccountId = result.Id;
      let adjusterName = result.Name;

      // Return a new object with the formatted information
      return {
        userAccountId,
        adjusterName
      };
    });

    return orderList;
  }

  async execute() {
    try {
      // TODO remove this pause, used to demo loading indicator
      await Utils.pause(3000);

      let searchParams = this.prepareSearchParams();

      console.log("searchParams", searchParams);

      // searchParams will be translated into query parameters
      // If no query parameters are used and the incoming searchCriteria
      // was added to the endpoint of the URL then just use this.get();
      //      let result = await this.get(searchParams);
      let result = await this.get(searchParams);
      console.log("result", result);

      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      // assumes if you get a 404 error the search results were not found and
      // you did not have an incorrect URL such as the wrong domain name or port
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindOrderListByAdjusterCommand };
