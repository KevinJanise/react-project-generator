import { Command } from "./Command";
import { Config } from "hooks/config";
import * as Utils from "utils/Utils";
import * as FormatUtils from "utils/FormatUtils";

/**
 * Creates a new instance for finding claims.
 * 
 * @constructor
 * @param {Object} searchCriteria - The search criteria for finding claims.
 * @param {Object} [options={}] - Configuration options for the instance.
 * @param {Object} [options.fetchOptions={}] - Options for the fetch API.
 * @param {Object} [options.retryOptions={}] - Options for the retry mechanism.
 * @param {number} [options.retryOptions.maxAttempts=3] - Maximum number of retry attempts.
 * @param {number} [options.retryOptions.baseDelay=1000] - Base delay in milliseconds between retry attempts.
 * @param {number} [options.retryOptions.timeout=30000] - Timeout in milliseconds for an individual retry attempt.
 */
class FindClaimsCommand extends Command {
  static OPERATION = "FIND_CLAIMS";

  constructor(searchCriteria, options = {}) {
    const config = Config.getInstance();
    let endPoint = null;
    let url = null;

    if (Utils.isNotEmpty(searchCriteria.claimNumber)) {
// https://apricusportal.coventry.dev.enlyte.com/claim-api/v1/claimnum-search?claimNumber=TEST&beId=962501268
      endPoint = `/claim-api/v1/claimnum-search`;
    } else {
      // https://apricusportal.coventry.dev.enlyte.com/claim-api/v1/name-search?firstName=Gbegpevli&lastName=QAKAL&beId=962501268&dob=1996-02-26&doi=2022-07-25
      endPoint = `/claim-api/v1/name-search`;
    }

    url = `${config.serviceUrl}${endPoint}`;

    const defaultRetryOptions = {
      maxAttempts: 3,
      baseDelay: 555,
      timeout: 5555
    };
  
    const mergedOptions = {
      ...options,
      retryOptions: {
        ...defaultRetryOptions,
        ...options.retryOptions
      }
    };
  
    super(url, mergedOptions);

    this.searchCriteria = searchCriteria;
  }

  prepareSearchParams() {
    let searchParams = {};

    if (Utils.isNotEmpty(this.searchCriteria.claimNumber)) {
// https://apricusportal.coventry.dev.enlyte.com/claim-api/v1/claimnum-search?claimNumber=TEST&beId=962501268
      searchParams.claimNum = this.searchCriteria.claimNumber;
      // searchParams.beId = "962504077";
      // searchParams.beId = "962501268";
      searchParams.beId = "6166";  // GB
    } else {
      // firstName=Lauren&lastName=Rhee&beId=962504077&dob=2005-02-10&doi=2024-06-01 06/01/2024
      searchParams.firstName = this.searchCriteria.firstName;
      searchParams.lastName = this.searchCriteria.lastName;
//      searchParams.beId = "962504077";
      searchParams.beId = "6166";  // GB
//      searchParams.dob = FormatUtils.convertDateFormat("2/10/2005"); //2005-02-10
      if (Utils.isNotEmpty(this.searchCriteria.dateOfInjury)) {
        searchParams.doi = FormatUtils.convertDateFormat(this.searchCriteria.dateOfInjury);
      }
    }

    return searchParams;
  }

  processSearchResults(results) {
    let claimList = results.searchMatches.map(result => {
      // Return a new object with the formatted information
      return {
        ...result,
        doi: FormatUtils.convertDateFormat(result.doi) ?? "",
        dob: FormatUtils.convertDateFormat(result.dob) ?? "",
        prescriberNm: FormatUtils.capitalizeWords(result.prescriberNm)
      };
    });

    return claimList;
  }

  async execute() {
    try {
      let searchParams = this.prepareSearchParams();
      let result = await this.get(searchParams);
      console.log("FindClaimsCommand", result);
      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      } else {
        throw error;
      }
    }
  }
}

export { FindClaimsCommand };
