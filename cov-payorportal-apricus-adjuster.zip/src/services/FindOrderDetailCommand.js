import { Command } from "services/Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";
import * as FormatUtils from "utils/FormatUtils";

class FindOrderDetailCommand extends Command {
  static OPERATION = "FIND_ORDER_DETAIL";

  constructor(orderId, offlineDataFlag, options = {}) {
    const config = Config.getInstance();

    // https://apricus-services.dev.enlyte360.com/order-api/v1/orders/{order-id}

    // has serviceUrl and endpoint
    let url = `${config.serviceUrl}/order-api/v1/orders/${orderId}`;
    console.log("FindOrderDetailCommand url: " + url);

    // Merge default options this command provides with provided options
    // Any options provided in the options parameter will be used
    /*
    const retryOptionsWithDefaults = {
      maxAttempts: 3,
      baseDelay: 1000,
      timeout: 10000,
      ...(options.retryOptions ?? {})
    };
    options.retryOptions = retryOptionsWithDefaults;
*/

    super(url, options);

    this.offlineDataFlag = offlineDataFlag;
  }

  processSearchResults = result => {
    const processedOrderDetails = this.processOrderDetails(result);
    const processedServiceItems = this.processServiceItems(result.serviceItems);

    return {
      ...processedOrderDetails,
      serviceItems: processedServiceItems
    };
  };

  processServiceItems = serviceItems =>
    serviceItems.map(item => ({
      ...item,
      serviceDt: FormatUtils.convertDateFormat(item.serviceDt) ?? ""
    }));

  processOrderDetails = ({ orderDt, birthDt, injuryDt, ...otherDetails }) => {
    return {
      ...otherDetails,
      birthDt: FormatUtils.formatDate(birthDt) ?? "",
      injuryDt: FormatUtils.formatDate(injuryDt) ?? "",
      orderDt: FormatUtils.formatDate(orderDt) ?? ""
    };
  };

  async execute() {
    try {
      await Utils.pause(3000);

      let result = await this.get({ "offline-data-flag": this.offlineDataFlag });
      let processedResults = this.processSearchResults(result);

      if (Math.random() < -.5) {
        //throw new Error("BOGUS Invalid response");
        throw new Error("Failed to fetch");
      }

//      return {};
      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      } else {
        throw error;
      }
    }
  }
}

export { FindOrderDetailCommand };
