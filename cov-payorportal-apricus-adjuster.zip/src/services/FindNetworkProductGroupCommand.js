import { Command } from "./Command";
import { Config } from "hooks/config";

class FindNetworkProductGroupCommand extends Command {
  static OPERATION = "FIND_NETWORK_PRODUCT_GROUP";

  constructor(clientId, options = {}) {
    const config = Config.getInstance();
    let url = null;
    let endpoint = `/client-api/v1/clients/${clientId}/network-product-groups`;
// https://nct-admin-services.dev.enlyte360.com/client-api/v1/clients/{client-id}/network-product-groups

    url = `${config.serviceUrl}${endpoint}`;
    console.log("FindNetworkProductGroupCommand url = " + url);
    
    super(url);

//    this.searchCriteria = searchCriteria;
  }

  prepareSearchParams() {
    let searchParams = {};

    searchParams = this.searchCriteria;

    return searchParams;
  }

  processSearchResults(results) {
    return results;
  }

  async execute() {
    try {
//      let searchParams = this.prepareSearchParams();

  //    console.log(searchParams);

      // searchParams will be translated into query parameters
      let result = await this.get();
      console.log("result", result);
      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindNetworkProductGroupCommand };
