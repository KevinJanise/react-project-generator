import { Command } from "./Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";

class TransferOrdersCommand extends Command {
  static OPERATION = "TRANSFER_ORDERS";

  constructor(orderList, transferTo, comments) {
    const config = Config.getInstance();
    let url = `${config.serviceUrl}/order-api/v1/order-history`;

    super(url);

    this.orderList = orderList;
    this.transferTo = transferTo;
    this.comments = comments;
  }

  async execute() {
    try {
        let params = {orderList: this.orderList, transferTo: this.transferTo, comments: this.comments};
        console.log("TransferOrdersCommand", params);

        await Utils.pause(3500);
        
        return {msg: "ok"}
      //return await this.post(params);
    } catch (error) {
      if (error.response.status === 404) {
        console.log("404 error", error.response);

        return {};
      } else {
        throw error;
      }
    }
  }
}

export { TransferOrdersCommand };
