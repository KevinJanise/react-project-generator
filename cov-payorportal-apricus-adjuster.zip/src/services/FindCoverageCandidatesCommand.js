import { Command } from "./Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";

// the username is just for DEV, it makes you appear as though your logged in
function getMergedOptions(options) {
  const fetchOptionsWithDefaults = {
    headers: {
      username: "LHDIGB" // searchCriteria.username"" // or your specific username
      // only needs this for testing, when you make the call the service will get the logged in user
      // from the OAUTH token
    },
    ...(options.fetchOptions ?? {})
  };

  const retryOptionsWithDefaults = {
    maxAttempts: 3,
    baseDelay: 1000,
    timeout: 30000,
    ...(options.retryOptions ?? {})
  };

  let mergedOptions = {
    ...options,
    fetchOptions: fetchOptionsWithDefaults,
    retryOptions: retryOptionsWithDefaults
  };

  return mergedOptions;
}

class FindCoverageCandidatesCommand extends Command {
  static OPERATION = "FIND_COVERAGE_CANDIDATES";

  constructor(searchCriteria, options = {}) {
    const config = Config.getInstance();
    let url = null;
    let endpoint = "/coverage-api/v1/coverage-for-candidates";

    let mergedOptions = getMergedOptions(options);
    console.log("mergedOptions", mergedOptions);

    url = `${config.serviceUrl}${endpoint}`;

    super(url, mergedOptions);

    this.searchCriteria = searchCriteria;
  }

  prepareSearchParams() {
    let searchParams = this.searchCriteria;
    /*
    {
        "adjuster-account-id": this.searchCriteria.assignedTo
    };
*/

    return searchParams;
  }

  processSearchResults(results) {
    console.log("processSearchResults: ", results);

    return results;
  }

  async execute() {
    try {
      let searchParams = this.prepareSearchParams();

      console.log(searchParams);

      await Utils.pause(3000);
      
      // searchParams will be translated into query parameters
      let result = await this.get();
      console.log("result", result);
      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindCoverageCandidatesCommand };
