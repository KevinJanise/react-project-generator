import { useAppContext } from "cov-jitux-context";

function useAuthenticatedUser() {
  const { context } = useAppContext();

  return {
    email: context.identity?.userInfo["mi-email"],
    firstName: context.identity?.userInfo["mi-fname"],
    lastName: context.identity?.userInfo["mi-lname"],
    name: context.identity?.userInfo["mi-fullname"],
    userName: context.identity?.userInfo.user_name,
    companyCode: context.identity?.company_code
  };
}

export { useAuthenticatedUser };
