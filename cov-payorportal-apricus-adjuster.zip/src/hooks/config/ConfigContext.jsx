import { createContext } from "react";

const ConfigContext = createContext(null);
ConfigContext.displayName = "ConfigContext";

export { ConfigContext };
