// src/contexts/growler/GrowlerProvider.js
import { useState, useCallback } from "react";
import { Growler as MagneticGrowler } from "csg-react-magnetic/growler";
import { GrowlerContext } from './GrowlerContext';

const GrowlerProvider = ({ children, defaultDuration = 5000 }) => {
  const [growler, setGrowler] = useState(null);

  const _showGrowler = useCallback(
    (message, type, duration = defaultDuration) => {
      setGrowler({ message, type, duration });
    },
    [defaultDuration]
  );

  const showSuccessGrowler = useCallback(
    (message, duration = defaultDuration) => {
      _showGrowler(message, "success", duration);
    },
    [_showGrowler, defaultDuration]
  );

  const showErrorGrowler = useCallback(
    (message, duration = defaultDuration) => {
      _showGrowler(message, "error", duration);
    },
    [_showGrowler, defaultDuration]
  );

  return (
    <GrowlerContext.Provider value={{ showSuccessGrowler, showErrorGrowler }}>
      {children}
      
      {growler && (
        <MagneticGrowler
          onClose={() => setGrowler(null)}
          duration={growler.duration}
          alert={growler.type === "error"}
          style={{ position: "fixed" }}
          top
          left
        >
          {growler.message}
        </MagneticGrowler>
      )}
    </GrowlerContext.Provider>
  );
};

export { GrowlerProvider };
