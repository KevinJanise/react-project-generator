import { createContext } from "react";

const GrowlerContext = createContext(null);
GrowlerContext.displayName = "GrowlerContext";

export { GrowlerContext };
