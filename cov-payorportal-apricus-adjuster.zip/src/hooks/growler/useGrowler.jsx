import { useContext } from "react";
import { GrowlerContext } from "./GrowlerContext";

const useGrowler = () => {
  const context = useContext(GrowlerContext);
  if (!context) {
    throw new Error("useGrowler must be used within a GrowlerProvider");
  }

  return context;
};

export { useGrowler };
