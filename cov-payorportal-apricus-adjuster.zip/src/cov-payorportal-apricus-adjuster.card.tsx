import {JitUxPortalCard} from "components/JitUxPortalCard";
import * as Jitux from "cov-jitux-appstore/scripts";

export const mount = Jitux.mount(JitUxPortalCard);
export const unmount = Jitux.unmount;
export const getMetadata = () => {};
