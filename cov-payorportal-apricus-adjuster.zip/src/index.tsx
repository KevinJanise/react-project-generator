import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./index.scss";
//import { AppContextProvider } from "cov-jitux-context/app-context/useAppContext";
//import { initContext } from "cov-jitux-context/app-context/context-util";
//const oauth = require('cov-enlyte360-oauth');
//const context = initContext();
//const auth = oauth.auth.authCheck();

/*
  <React.StrictMode> 
    {auth?<App jitux={context}/>:<></>}
  </React.StrictMode>,
*/

ReactDOM.render(  
  <React.StrictMode> 
    <App />
  </React.StrictMode>,
  document.getElementById("root")
);