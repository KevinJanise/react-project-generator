/**
 * Creates a debounced version of the provided function that delays its execution until after a specified
 * amount of time has passed since the last time it was invoked.
 *
 * @param {Function} func - The function to debounce. This function will be invoked after the delay.
 * @param {number} delay - The number of milliseconds to wait after the last call before invoking the function.
 * @param {Object} [options={}] - Configuration options to customize the debouncing behavior.
 * @param {boolean} [options.leading=false] - If `true`, the function will be invoked on the leading edge (immediately on the first call).
 * @param {boolean} [options.trailing=true] - If `true`, the function will be invoked on the trailing edge (after the specified delay).
 * @param {Object} [options.context=null] - The context (`this`) to use when invoking the function.
 *
 * @returns {Function} - A debounced version of the provided function.
 * The returned debounced function has the following methods:
 *  - `cancel()`: Cancels any pending invocation of the debounced function.
 *  - `flush()`: Immediately invokes the function, regardless of the delay.
 *  - `pending()`: Returns `true` if there is a pending invocation, otherwise `false`.
 *
 * @throws {TypeError} Throws an error if `func` is not a function, `delay` is not a positive number, or `options` is not an object.
 *
 * @example
 * // Example usage in a search input field:
 * const debouncedSearch = debounce(
 *   (query) => { console.log('Searching for:', query); },
 *   500,
 *   { leading: false, trailing: true }
 * );
 *
 * // Simulate input change events that trigger the debounced search function
 * debouncedSearch('first query'); // Will wait for 500ms before calling the search function
 * debouncedSearch('second query'); // Will reset the 500ms delay, and call the search function once the typing pauses.
 * debouncedSearch.flush(); // Will immediately call the search function, regardless of the delay.
 * debouncedSearch.cancel(); // Cancels any pending search.
 */
export const debounce = (func, delay, options = {}) => {
  if (typeof func !== "function") {
    throw new TypeError("Expected a function");
  }

  if (typeof delay !== "number" || delay < 0) {
    throw new TypeError("Delay must be a positive number");
  }

  if (typeof options !== "object") {
    throw new TypeError("Options must be an object");
  }

  const { leading = false, trailing = true, context = null } = options;

  let timeoutId;
  let lastArgs;
  let lastCallTime = 0;
  let result;

  const debounced = function (...args) {
    const time = Date.now();
    const invokeImmediately = leading && !lastCallTime;
    lastArgs = args;
    lastCallTime = time;

    // If leading invocation is requested and it's time to invoke
    if (invokeImmediately) {
      result = func.apply(context, args);
    }

    // Clear previous timeout
    clearTimeout(timeoutId);

    // Schedule the trailing invocation if needed
    if (trailing) {
      timeoutId = setTimeout(() => {
        if (lastArgs) {
          result = func.apply(context, lastArgs);
          lastArgs = undefined; // reset after invocation
        }
      }, delay);
    }

    return result;
  };

  // Cancels any pending invocations
  debounced.cancel = () => {
    clearTimeout(timeoutId);
    timeoutId = null;
    lastArgs = null;
    lastCallTime = 0;
  };

  // Immediately invokes the function if it hasn't been called recently (flushes pending invocation)
  debounced.flush = () => {
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutId = null;
      if (lastArgs) {
        result = func.apply(context, lastArgs);
        lastArgs = null; // Reset the arguments after flushing
      }
    }
    return result;
  };

  // Returns whether there is a pending invocation
  debounced.pending = () => {
    return timeoutId !== null;
  };

  return debounced;
};

// returns true if the object has no properties
export function isObjectEmpty(obj) {
  if (obj == null) return true;
  return Object.keys(obj).length === 0; // && obj.constructor === Object;
}

// For security reasons, the Clipboard API only works in secure contexts (HTTPS)
// and requires user permission. The permission is usually granted automatically
// when triggered by a user action like a button click.
export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (err) {
    console.error("Failed to copy text: ", err);
  }
}

export function trim(value) {
  if (value === null || value === undefined) return value;

  return value.trim();
}

export function isEmpty(obj) {
  // Check if the input is null, undefined, or an empty string
  if (obj === null || obj === undefined || obj === "") {
    return true;
  }

  // Check if it's an object or array
  if (typeof obj !== 'object') {
    return false;
  }

  // If it's an array, check if it's empty or if all elements are empty
  if (Array.isArray(obj)) {
    return obj.length === 0 || obj.every(isEmpty);
  }

  // For objects, check each property
  for (let key in obj) {
    if (Object.hasOwn(obj, key)) {
      const value = obj[key];

      // Check if the value is empty
      if (!isEmpty(value)) {
        return false;
      }
    }
  }

  return true;
}

export function isNotEmpty(value) {
  return !isEmpty(value);
}

export const pause = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
};


/**
 * Transforms an array based on a mapping configuration.

mappingConfig adds new properties to an existing array. You may need to keep the original
data intact but have specific fields added to the new object. The mappingConfig
is an object where the key is the new field name and the value is the old/original field name.
You can also use a function to compute the value of the new field.
You have access to the original object in the function via the item parameter.
 * 
 * @param {Array} originalArray - The original array to transform
 * @param {Object} mappingConfig - Configuration object that maps new field names to original field names
 *                                 You can also use a function to compute the value of a new field
 * @param {boolean} [onlyNewFields=false] - If true, returns only the new mapped fields; if false, adds new fields to the original items
 * @returns {Array} - The transformed array
 * 
 * Example:
 * const mappingConfig = { 
 *   newFieldName1: "originalField1", 
 *   newFieldName2: "originalField2", 
 *   newComputedFieldName: item => (item.originalField1 === "123")  // function that returns a new computed value
 * };
 */
export function transformArray(originalArray, mappingConfig, onlyNewFields = false) {  
  return originalArray.map(item => {
    // Start with either an empty object or a copy of the original item
    const transformedItem = onlyNewFields ? {} : { ...item };
    
    for (const [newKey, oldKey] of Object.entries(mappingConfig)) {
      if (typeof oldKey === 'function') {
        // If oldKey is a function, use it to compute the value
        transformedItem[newKey] = oldKey(item);
      } else if (!onlyNewFields || oldKey !== newKey) {
        // For onlyNewFields=true: always add the mapped field
        // For onlyNewFields=false: only add if the new key is different from the old key
        transformedItem[newKey] = item[oldKey];
      }
    }
    return transformedItem;
  });
}