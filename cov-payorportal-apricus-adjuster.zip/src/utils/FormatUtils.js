function isEmptyString(str) {
  return str === "" || str === null || str === undefined;
}

// Captializes the first letter of each word in the string
export function capitalizeWords(str) {
    if (isEmptyString(str)) return str;
    
    // Split the string into an array of words
    return str
      .split(' ')
      // Capitalize the first letter of each word
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      // Join the words back into a string
      .join(' ');
}

// Takes a date string in YYYY-MM-DD and returns MM/DD/YYYY
// or MM/DD/YYYY and returns YYYY-MM-DD
export function convertDateFormat(dateString) {
  if (isEmptyString(dateString)) return dateString;
  
  // Regular expressions to match the two formats
  const yyyyMMddRegex = /^\d{4}-\d{2}-\d{2}$/;
  const mmDDyyyyRegex = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

  if (yyyyMMddRegex.test(dateString)) {
    // Convert from YYYY-MM-DD to MM/DD/YYYY
    const [year, month, day] = dateString.split('-');
    return `${month.padStart(2, '0')}/${day.padStart(2, '0')}/${year}`;
  } else if (mmDDyyyyRegex.test(dateString)) {
    // Convert from MM/DD/YYYY to YYYY-MM-DD
    const [month, day, year] = dateString.split('/');
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  } else {
    throw new Error("Invalid date format. Please use YYYY-MM-DD or MM/DD/YYYY.");
  }
}

// Takes a date object and returns MM/DD/YYYY by default
// Pass in any format with the values MM DD YYYY
export function formatDateORIG(date, format = 'MM/DD/YYYY') {
  // If it's a string, try to convert it to a Date object
  if (typeof date === 'string') {
    const parsedDate = new Date(date);
    // Check if the parsed date is valid
    if (!isNaN(parsedDate.getTime())) {
      date = parsedDate;
    } else {
      // If conversion failed, return the original string
      return date;
    }
  }

  if (!(date instanceof Date)) {
    console.log("the date is not a date object!");
    throw new Error('Invalid date object');
  //  return date;
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  let formattedDate = format;
  formattedDate = formattedDate.replace(/YYYY/g, year);
  formattedDate = formattedDate.replace(/MM/g, month);
  formattedDate = formattedDate.replace(/DD/g, day);

  return formattedDate;
}




export function formatDate(input, format = 'MM/DD/YYYY') {
  let workingDate;

  // If it's a string, try to convert it to a Date object
  if (typeof input === 'string') {
    const parsedDate = new Date(input);
    // Check if the parsed date is valid
    if (!isNaN(parsedDate.getTime())) {
      workingDate = parsedDate;
    } else {
      // If conversion failed, return the original string
      return input;
    }
  } else if (input instanceof Date) {
    workingDate = input;
  } else {
    console.log("the input is not a date object or valid date string!");
    return input;
  }

  const year = workingDate.getFullYear();
  const month = String(workingDate.getMonth() + 1).padStart(2, '0');
  const day = String(workingDate.getDate()).padStart(2, '0');

  let formattedDate = format;
  formattedDate = formattedDate.replace(/YYYY/g, year);
  formattedDate = formattedDate.replace(/MM/g, month);
  formattedDate = formattedDate.replace(/DD/g, day);

  return formattedDate;
}
