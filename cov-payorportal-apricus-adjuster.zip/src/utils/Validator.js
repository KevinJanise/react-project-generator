export function isEmpty(obj) {
  console.log("checking isEmpty obj: ", obj);
  
  // Check if the input is null, undefined, or an empty string
  if (obj === null || obj === undefined || obj === "") {
    return true;
  }

  // Check if it's an object or array
  if (typeof obj !== 'object') {
    return obj === false; // Consider false as empty
  }

  // If it's an array, check if it's empty or if all elements are empty
  if (Array.isArray(obj)) {
    return obj.length === 0 || obj.every(isEmpty);
  }

  // For objects, check each property
  let allFalseOrEmpty = true;
  for (let key in obj) {
    if (Object.hasOwn(obj, key)) {
      const value = obj[key];

      // Check if the value is empty or false
      if (!isEmpty(value) && value !== false) {
        allFalseOrEmpty = false;
        break;
      }
    }
  }

  return allFalseOrEmpty;
}

export function isNotEmpty(value) {
  return !isEmpty(value);
}

// Validates a date is in the form MM/DD/YYYY or MM-DD-YYYY
export function isDate(value) {
  const dateRegex = /^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/;
  const matches = dateRegex.exec(value);

  if (!matches) {
    return false; // Invalid format
  }

  let dateObject = new Date(value);

  return !isNaN(dateObject) && dateObject.toString() !== "Invalid Date";
}

export function trimmedLength(value) {
  if (value === null || value === undefined) return 0;

  return value.trim().length;
}

export function length(value) {
  if (value === null || value === undefined) return 0;

  return value.length;
}

export function isUndefined(variable) {
  return typeof variable === "undefined";
}

export function isUndefinedOrNull(variable) {
  return typeof variable === "undefined" || variable === null;
}

export function matchesRegularExpression(regularExpression, value) {
  let regEx = new RegExp(regularExpression);

  return regEx.test(value);
}

export function isEmailAddress(emailAddress) {
  if (isUndefinedOrNull(emailAddress)) return false;

  const regex = /^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  return regex.test(emailAddress);
}

// handles (###) ###-#### or ########## or ### ### #### or ###-###-####
export function isTelephoneNumber(telephoneNumber) {
  if (isUndefinedOrNull(telephoneNumber)) return false;

  const phoneRegex = /^(\(\d{3}\) ?|\d{3}-|\d{3} ?-?)\d{3}-?\d{4}$/;
  return phoneRegex.test(telephoneNumber);
}

export function isNumeric(str) {
  if (isUndefinedOrNull(str)) return false;

  const regex = /^\d+$/;
  return regex.test(str);
}

export function isURL(str) {
  try {
    new URL(str);
  } catch (error) {
    return false;
  }

  return true;
}

// returns the index of the item with the matching value in the property
export function hasValueInObjects(objectArray, value, propName) {
  // Iterate through the array of objects
  let obj = null;

  for (let i = 0; i < objectArray.length; ++i) {
    obj = objectArray[i];

    if (obj.hasOwnProperty(propName) && obj[propName] === value) {
      return i;
    }
  }

  // Value not found in any of the objects
  return -1;
}

export function hasValidCharacters(value, validChars) {
  // Check if each character in value is present in validChars
  for (const element of value) {
    if (validChars.indexOf(element) === -1) {
      return false;
    }
  }

  return true;
}

// formats: 5 digits, 9 digits, or 12345-1234
export function isZipCode(zipCode) {
  // Regular expression for US ZIP code validation
  const zipCodeRegex = /^(\d{5}(-\d{4})?|\d{9})$/;

  return zipCodeRegex.test(zipCode);
}

/**
 * Compares two dates and determines if the first date is before the second date,
 * ignoring time components and comparing only MM/DD/YYYY
 * 
 * @param {Date|string|number} date1 - The first date to compare
 * @param {Date|string|number} date2 - The second date to compare
 * @returns {boolean} - Returns true if date1 is before date2, false otherwise
 */
export function isDateBefore(date1, date2) {
  // Convert inputs to Date objects if they aren't already
  const firstDate = date1 instanceof Date ? date1 : new Date(date1);
  const secondDate = date2 instanceof Date ? date2 : new Date(date2);
  
  // Check if either date is invalid
  if (isNaN(firstDate.getTime()) || isNaN(secondDate.getTime())) {
    throw new Error('Invalid date provided');
  }
  
  // Create new Date objects with only year, month, and day components
  const firstDateNoTime = new Date(
    firstDate.getFullYear(),
    firstDate.getMonth(),
    firstDate.getDate()
  );
  
  const secondDateNoTime = new Date(
    secondDate.getFullYear(),
    secondDate.getMonth(),
    secondDate.getDate()
  );
  
  // Compare dates without time and return result
  return firstDateNoTime < secondDateNoTime;
}
