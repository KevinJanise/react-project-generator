import styles from "./UserSearch.module.css";

import { useState, useEffect } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { SingleSelect } from "csg-react-magnetic/single-select";
import { TextField } from "csg-react-magnetic/text-field";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LabeledControlGroup } from "components/LabeledControlGroup";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { usePageState } from "hooks/usePageState";

import { FindClientsCommand } from "services/FindClientsCommand";
import { FindUsersCommand } from "services/FindUsersCommand";

import { UserSearchResults } from "./UserSearchResults";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

const ALL_CLIENTS = "***";

function transformClientDataForDropdown(clientData) {
  console.log("transformClientDataForDropdown: ", clientData);

  return clientData.map(client => ({
    id: client.clientId,
    name: client.clientNm,
    isActive: client.clientStatusCd === "ACTIVE"
  }));
}

/* begin client dropdown specific items */
const clientDropdownTemplate = props => {
  return <span style={{ color: props.isActive ? "black" : "red" }}>{props.name}</span>;
};

function UserSearch() {
  const [clientList, setClientList] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [message, setMessage] = useState(null);
  const [userList, setUserList] = useState(null);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();

  let initialFormState = {
    client: "",
    eMail: "",
    firstName: "",
    lastName: "",
    showActive: true,
    showDraft: true,
    showInactive: false,
    userName: "",
  };
  const { formData, resetForm, handleMagneticChange, setFormData, trimFormValues } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  // Repopulate state variables and make service calls to get data when component mounts.  
  const { savePageState, clearPageState } = usePageState(
    "_UserSearch",
    pageState => {
      setFormData(pageState.formData);
      setHasSearched(pageState.hasSearched);
      doUserSearch(pageState.formData);
    },
    null
  );

  // Intiailize client drop-down
  useEffect(() => {
    async function init() {
      // To populate client drop-down box
      const findClientsCommand = new FindClientsCommand({ clientName: ALL_CLIENTS });
      let result = await execute(findClientsCommand);
      console.log("useEffect - FindClientsCommand result", result);

      if (result.isCanceled) return;

      if (result.isSuccess) {
        let listData = transformClientDataForDropdown(result.value);
        //        listData = [];
        //        setErrorMessage("Clients were not found");
        console.log("transformed list data: ", listData);
        setClientList(listData);
        console.log(result);
      } else {
        showErrorGrowler(JSON.stringify(result.error));
        console.log(result.error);
      }
    }

    init();
  }, [execute, showErrorGrowler]);

  const validateForm = () => {
    clearErrorMessages();

    // if form is empty display an error message
    if (Validator.isEmpty(formData)) {
      addErrorMessage("global", "Please enter search criteria.");
      return false;
    }

    if (Validator.isNotEmpty(formData.firstName) && Validator.length(formData.firstName) < 3) {
      addErrorMessage("firstName", "Enter at least 3 characters.");
    }

    if (formData.showActive === false && formData.showDraft === false && formData.showInactive === false) {
      addErrorMessage("status", "Select a status.");
    }

    return !hasFieldSpecificErrors();
  };

  const doUserSearch = async searchCriteria => {
    clearSearchResults();

    setHasSearched(true);

    let command = new FindUsersCommand(searchCriteria);
    let result = await execute(command);

    if (result.isSuccess) {
      let list = result.value;

      setUserList(list);

      if (Utils.isObjectEmpty(list)) {
        setMessage("No users were found.");
        showSuccessGrowler("No users were found.");
      } else {
        showSuccessGrowler(list.length === 1 ? "Found 1 user." : `Found ${list.length} users.`);
      }
    } else {
      let error = result?.error;
      let errorMessage = null;

      console.error(error);

      if (error?.message === "Failed to fetch") {
        errorMessage = "There was an error connecting to the server.";
      } else {
        errorMessage = "There was an error processing your request.";
      }

      setErrorMessage(errorMessage);
      showErrorGrowler(errorMessage);
    }
  };

  const handleUserSearch = async event => {
    event.preventDefault();

    clearSearchResults();

    // Trim all form values before validation
    trimFormValues();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    setHasSearched(true);

    // Save the validated form data but not the client list. Reload list when page reloads.
    savePageState({ formData: formData, hasSearched: true });

    doUserSearch(formData);
  };

  const handleStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    setErrorMessage(null);
    setHasSearched(false);
    setUserList(null);
  };

  const handleClear = () => {
    clearSearchResults();
    resetForm();
    clearPageState();
  };

  return (
    <div className={styles.userSearch}>
      <PageTitle title="User Search" />

      <PageSection>
        <BlockMessage variant="error" style={{ marginBottom: "1rem" }}>
          {getErrorMessage("global")}
        </BlockMessage>

        <form onSubmit={handleUserSearch}>
          <Grid>
            <Row>
              <Column width="50%">
                <SingleSelect
                  label="Client"
                  name="client"
                  placeholder="Select One..."
                  optionTemplate={clientDropdownTemplate}
                  value={formData.client}
                  options={clientList}
                  onChange={handleMagneticChange("client", "single-select")}
                  validationError={getErrorMessage("client")}
                />
              </Column>
              <Column width="50%">
                <TextField
                  label="Username"
                  name="userName"
                  onChange={handleMagneticChange("userName", "text")}
                  value={formData.userName}
                  validationError={getErrorMessage("userName")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="50%">
                <TextField
                  label="First Name"
                  name="firstName"
                  onChange={handleMagneticChange("firstName", "text")}
                  value={formData.firstName}
                  validationError={getErrorMessage("firstName")}
                />
              </Column>

              <Column width="50%">
                <TextField
                  label="Last Name"
                  name="lastName"
                  onChange={handleMagneticChange("lastName", "text")}
                  value={formData.lastName}
                  validationError={getErrorMessage("lastName")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="50%">
                <TextField
                  label="Email"
                  name="eMail"
                  onChange={handleMagneticChange("eMail", "text")}
                  value={formData.eMail}
                  validationError={getErrorMessage("eMail")}
                />
              </Column>

              <Column width="50%">
                <LabeledControlGroup
                  label="Status"
                  layout="row"
                  required
                  validationError={getErrorMessage("status")}
                  requiredFulfilled={formData.showInactive || formData.showActive || formData.showDraft}
                >
                  <Checkbox
                    style={{ marginRight: "2rem" }}
                    className="minWidthAuto"
                    label="Draft"
                    name="showDraft"
                    checked={formData.showDraft}
                    onChange={handleMagneticChange("showDraft", "checkbox")}
                  />

                  <Checkbox
                    style={{ marginRight: "2rem" }}
                    className="minWidthAuto"
                    label="Active"
                    name="showActive"
                    checked={formData.showActive}
                    onChange={handleMagneticChange("showActive", "checkbox")}
                  />

                  <Checkbox
                    style={{ marginRight: "2rem" }}
                    className="minWidthAuto"
                    label="Inactive"
                    name="showInactive"
                    checked={formData.showInactive}
                    onChange={handleMagneticChange("showInactive", "checkbox")}
                  />
                </LabeledControlGroup>
              </Column>
            </Row>

            <Row>
              <Column width="100%">
                <Button variant="primary" type="submit" loading={isExecuting} style={{ marginRight: "1rem" }}>
                  Search
                </Button>

                <Button variant="outline" type="button" onClick={handleClear}>
                  Clear
                </Button>
              </Column>
            </Row>
          </Grid>
        </form>
      </PageSection>

      {hasSearched && (
        <UserSearchResults
          userList={userList}
          isLoading={isExecuting}
          resultMessage={message}
          errorMessage={errorMessage}
          onStatusUpdate={handleStatusUpdate}
        />
      )}
    </div>
  );
}

export { UserSearch };
