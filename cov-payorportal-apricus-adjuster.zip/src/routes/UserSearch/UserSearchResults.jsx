import styles from "./UserSearchResults.module.css";

import { useHistory } from "react-router-dom";

import { BlockMessage } from "components/BlockMessage";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { UserTable } from "./UserTable";

function UserSearchResults({ userList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasResults = userList && userList.length > 0;
  const history = useHistory();

  const handleEdit = username => {
    console.log("UserSearchResults handleEdit: ", username);

    history.push(`/userDetails/${username}`);
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection className={styles.userSearchResults}>
        {hasResults && <UserTable userList={userList} onEdit={handleEdit} />}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
      </PageSection>
    </LoadingIndicator>
  );
}

export { UserSearchResults };
