import styles from "./UserTable.module.css";
import { useState } from "react";

import { Link } from "react-router-dom";

import { DataGrid, ColumnResizeMode } from "csg-react-magnetic/data-grid";
import { Icon } from "csg-react-magnetic/icon";

import { ButtonBar } from "components/ButtonBar";
import { ToolbarButton } from "components/ToolbarButton";

// import { usePageState } from "hooks/usePageState";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

/**
 * ClaimsTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 * It allows for selection of multiple orders and provides pagination functionality.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.userList - An array of order objects to be displayed in the table
 * @param {Function} props.onOrderSelected - Callback function triggered when orders are selected
 *
 * @example
 * <ClaimsTable
 *   userList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 *   onOrderSelected={(selectedOrders) => console.log(selectedOrders)}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function UserTable({ userList, onEdit }) {
  // headerTemplate is what appears in the table header
  // template is what appears in the row. Create one if you want something custom such as a link
  // otherwise it will use the field in the object array corresponding to the column id
  const columnTemplates = [
    {
      id: "clientName",
      name: "Primary Client",
      sortable: true,
      headerStyle: { minWidth: "175px" }
    },
    {
      id: "username",
      name: "Username",
      sortable: true,
      headerStyle: { minWidth: "160px" }
    },
    {
      id: "userType",
      name: "User Type",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "firstName",
      name: "First Name",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "lastName",
      name: "Last Name",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "status",
      name: "Status",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "action",
      name: "Action",
      headerStyle: { width: "auto", minWidth: "150px" },
      template: (col, row) => (
        <ButtonBar variant="toolbar">
          <ToolbarButton title="Manage User" icon="user-fill" onClick={() => onEdit(row.username)} />
        </ButtonBar>
      )
    }
  ];

  const [columns, setColumns] = useState(columnTemplates);

  /*
  const { savePageState, clearPageState } = usePageState(
    "_UserTable",
    pageState => {
      console.log("UserTable pageState", pageState);
      // setColumns(pageState.columns);
    },
    () => {
      console.log("saving columns for UserTable", columns);

      return { columns: columns };
    }
  );
*/

  return (
    <DataGrid
      data={userList}
      reorderable={{
        reorderableColumns: true,
        onColumnReorder: e => {
          console.log(e);
        }
      }}
      resizable={{
        columnResizeMode: ColumnResizeMode.Expand,
        onColumnResize: e => {
          console.log(e);
        }
      }}
      columns={columns}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
    />
  );
}

export { UserTable };
