import styles from "./Coverage.module.css";

import { useState, useEffect } from "react";

import { Button } from "csg-react-magnetic/button";
import { SingleSelect } from "csg-react-magnetic/single-select";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { PageStateContainer, PAGE_STATE } from "components/PageStateContainer";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { usePageState } from "hooks/usePageState";
import { useStableFunction } from "hooks/useStableFunction";

import { CoverageSearchResults } from "./CoverageSearchResults";

import { FindUserCoverageCommand } from "services/FindUserCoverageCommand";
import { FindCoverageCandidatesCommand } from "services/FindCoverageCandidatesCommand";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

// this will come from the logged in user
const userAccountId = "001DM00002OQxahYAD";
/* {
    "Name": "LH Dilshan",
    "Id": "001DM00002OQxahYAD",
    "CCUserId": "LHDIGB"
}
*/

function transformCoverageCandidateDataForDropdown(userList) {
  return userList.map(user => ({
    id: user.Id,
    name: user.Name
  }));
}

function Coverage() {
  const [pageLoadingState, setPageLoadingState] = useState(PAGE_STATE.LOADING);
  const [pageInitializationErrorMessage, setPageInitializationErrorMessage] = useState(null);

  const [coverageForList, setCoverageForList] = useState([]);
  const [coverageList, setCoverageList] = useState([]);

  const [errorMessage, setErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [message, setMessage] = useState(null);
  const [searchErrorMessage, setSearchErrorMessage] = useState(null);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();
  let initialFormState = { assignedTo: null, phases: [] };
  const { formData, resetForm, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const clear = () => {
    clearSearchResults();
    resetForm();
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    setErrorMessage(null);
    setPageInitializationErrorMessage(null);
    setSearchErrorMessage(null);
    setHasSearched(false);
    setCoverageList(null);
  };

  // Finds the users in the "Coverage For" dropdown
  const initializePage = useStableFunction(async () => {
    setPageLoadingState(PAGE_STATE.LOADING);
    clear();

    const command = new FindCoverageCandidatesCommand();
    const result = await execute(command);

    // TODO - used for testing error condition - begin remove this!!!!!!!!!!!!!!

    if (Math.random() < -10.5) {
      result.isSuccess = false;
      result.isError = true;
      result.error = {};
      result.error.message = "Failed to fetch";
    }
    // TODO - end remove this!!!!!!!!!!!!!!

    if (result.isCanceled) return;

    if (result.isSuccess) {
      let candidateList = transformCoverageCandidateDataForDropdown(result.value);

      setCoverageForList(candidateList);

      if (Utils.isEmpty(candidateList)) {
        setPageLoadingState(PAGE_STATE.ERROR);
        setPageInitializationErrorMessage("Coverage for list was not initialized!");
      } else {
        setPageLoadingState(PAGE_STATE.READY);
      }
    } else {
      console.error(result.error);
      setPageLoadingState(PAGE_STATE.ERROR);
      setPageInitializationErrorMessage("Oops! There was an error loading the page.");
    }
  });

  useEffect(() => {
    initializePage();

    return () => {
      // TODO Cleanup logic if needed
    };
  }, [initializePage]);

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.coverageFor)) {
      addErrorMessage("coverageFor", "Please select Coverage For.");
    }

    return !hasFieldSpecificErrors();
  };

  // Finds coverage for the selected "Coverage For" user after the clicking the Show button
  const findCoverage = async searchCriteria => {
    clearSearchResults();
    setIsSearching(true);
    setHasSearched(true);

    console.log("searchCriteria: ", searchCriteria);

    const command = new FindUserCoverageCommand(userAccountId);
    let result = await execute(command);
    console.log("FindOrderListByAdjusterCommand", result);

    setIsSearching(false);

    // TODO - used for testing error condition - begin remove this!!!!!!!!!!!!!!

    /*
    result.isSuccess = false;
    result.isError = true;
    result.error = {};
    result.error.message = "Failed to fetch";
*/
    // TODO - end remove this!!!!!!!!!!!!!!

    if (result.isCanceled) return;

    if (result.isSuccess) {
      let list = result.value;

      //      list = [];

      setCoverageList(list);

      if (Utils.isObjectEmpty(list)) {
        setMessage("No coverage items were found.");
        showSuccessGrowler("No coverage items were found.");
      } else {
        showSuccessGrowler(list.length === 1 ? "Found 1 coverage item." : `Found ${list.length} coverage items.`);
      }
    } else {
      console.error(result.error);

      let errorMessage = "There was an error processing your request. Please try again later.";

      if (result.error.message === "Failed to fetch") {
        errorMessage = "There was an error connecting to the server.";
      }

      setSearchErrorMessage(errorMessage);
      showErrorGrowler(errorMessage);
    }
  };

  const handleStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      setErrorMessage(message.message);
      showErrorGrowler(message.message);
    }
  };

  const handleClear = () => {
    clear();
  };

  const handleFindCoverage = async event => {
    event.preventDefault();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    findCoverage(formData);

    console.log(formData);
  };

  const handleRetry = () => {
    initializePage();
  };

  /*
  const handleCloseError = () => {
    setErrorMessage(null);
  };
*/

  return (
    <div data-testid="coverage" className={styles.coverage}>
      <PageTitle title="Coverage" />

      <PageSection>
        <PageStateContainer
          state={pageLoadingState}
          initializationErrorMessage={pageInitializationErrorMessage}
          onRetry={handleRetry}
          renderDelay={333}
        >
          {pageLoadingState === PAGE_STATE.READY && (
            <>
              <BlockMessage
                variant="error"
                style={{ marginBottom: "1rem" }}
                onClose={() => {
                  setErrorMessage(null);
                }}
              >
                {errorMessage}
              </BlockMessage>

              <form onSubmit={handleFindCoverage}>
                <Grid>
                  <Row>
                    <Column width="50%">
                      <SingleSelect
                        label="Coverage For"
                        required
                        name="coverageFor"
                        placeholder="Select One..."
                        value={formData.coverageFor}
                        options={coverageForList}
                        onChange={handleMagneticChange("coverageFor", "single-select")}
                        validationError={getErrorMessage("coverageFor")}
                      />
                    </Column>
                  </Row>

                  <Row>
                    <Column width="100%">
                      <ButtonBar>
                        <Button variant="primary" type="button" onClick={handleFindCoverage} loading={isSearching}>
                          <span className="noWrap">Show</span>
                        </Button>

                        <Button variant="outline" type="button" onClick={handleClear}>
                          Clear
                        </Button>
                      </ButtonBar>
                    </Column>
                  </Row>
                </Grid>
              </form>
            </>
          )}
        </PageStateContainer>
      </PageSection>

      {hasSearched && (
        <CoverageSearchResults
          coverageList={coverageList}
          isLoading={isSearching}
          resultMessage={message}
          errorMessage={searchErrorMessage}
          onStatusUpdate={handleStatusUpdate}
        />
      )}
    </div>
  );
}

export { Coverage };
