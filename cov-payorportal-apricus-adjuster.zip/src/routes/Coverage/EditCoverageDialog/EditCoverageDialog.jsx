import styles from "./EditCoverageDialog.module.css";

import { useState, useEffect } from "react";

import { Button } from "csg-react-magnetic/button";
import { Modal } from "csg-react-magnetic/modal";
import { SingleSelect } from "csg-react-magnetic/single-select";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { DatePickerWithEnter } from "components/DatePickerWithEnter";
import { Grid, Row, Column } from "components/Grid";
import { PageStateContainer, PAGE_STATE as DIALOG_STATE } from "components/PageStateContainer";
import { ProgressIndicator } from "components/ProgressIndicator";

import { useStableFunction } from "hooks/useStableFunction";
import { useCommand } from "hooks/useCommand";

import { FindAssignToCandidatesCommand } from "services/FindAssignToCandidatesCommand";
import { FindCoverageCandidatesCommand } from "services/FindCoverageCandidatesCommand";
import { UpdateCoverageCommand } from "services/UpdateCoverageCommand";

import * as Utils from "utils/Utils";

import * as Validator from "utils/Validator";
import * as FormatUtils from "utils/FormatUtils";
import { useForm } from "hooks/useForm";
import { useErrorMessages } from "hooks/useErrorMessages";

/*
const executeCommand = async command => {
  const commandId = command.getId?.() || `command-${performance.now()}`;
  try {
    const value = await command.execute();
    return {
      command,
      commandId,
      isCanceled: command.getIsCanceled(),
      isSuccess: true,
      isError: false,
      value,
      error: null
    };
  } catch (error) {
    return {
      command,
      commandId,
      isCanceled: command.getIsCanceled(),
      isSuccess: false,
      isError: true,
      value: null,
      error
    };
  }
};

class EditCoverageDialogHelper {
  initializeDialog = async coverage => {
    // Initialize dialog logic here
    const findFromUserCommand = new FindCoverageCandidatesCommand();
    let result = await executeCommand(findFromUserCommand);

    if (!result.isSuccess) {
      throw new Error(result.error?.message || "Unknown error occurred");
    }

    return { fromUserList: result.value, toUserList: 123 };
  };
}
*/

// In any component file
import { withLoading } from 'hocs/withLoading';

// TODO - create a custom property for overriding the position of the spinner
const LoadableSingleSelect = withLoading(SingleSelect);
// TODO hoc for change events withChangeEvent(Textfield)

const EditCoverageDialog = ({ title, coverage, onStatusUpdate, onOk, onCancel, hideModal }) => {
  const {
    addErrorMessage,
    addGlobalErrorMessage,
    clearErrorMessages,
    getErrorMessage,
    hasFieldSpecificErrors,
    setFocusOnFirstError,
    removeErrorMessage
  } = useErrorMessages();

  const [fromUserList, setFromUserList] = useState([]);
  const [toUserList, setToUserList] = useState([]);

  let initialFormState = {
    startDate: FormatUtils.formatDate(coverage?.beginDt),
    throughDate: FormatUtils.formatDate(coverage?.endDt),
    fromUser: "", // coverage?.adjusterId,
    toUser: "", //coverage?.coveringAdjusterId
  };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const [dialogLoadingState, setDialogLoadingState] = useState(DIALOG_STATE.LOADING);
  const [dialogInitializationErrorMessage, setDialogInitializationErrorMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { execute, cancel: cancelCommand, executeAsync } = useCommand();

  const clear = () => {
    setToUserList(null);

    setErrorMessage(null);
    setDialogInitializationErrorMessage(null);
  };

  const initializeDialog = useStableFunction(async () => {
    setDialogLoadingState(DIALOG_STATE.LOADING);
    clear();

    // if no coverage, then we are in "create" mode
    // if coverage, then we are in "edit" mode
    /*
    if (!coverage) {
      setDialogInitializationErrorMessage("coverage is required");
      setDialogLoadingState(DIALOG_STATE.ERROR);
      return;
    }
*/

    try {
      const findFromUserCommand = new FindCoverageCandidatesCommand();
      const fromUserResult = await execute(findFromUserCommand);

      // Early return if any command was canceled
      if (fromUserResult.isCanceled) {
        return;
      }

      // Handle errors
      if (!fromUserResult.isSuccess) {
        throw new Error(fromUserResult.error?.message || "Unknown error occurred");
      }

      console.log("fromUserResult", fromUserResult);

      // Check for empty results
      if (Utils.isObjectEmpty(fromUserResult.value)) {
        setDialogInitializationErrorMessage("fromUserList was not found!");
        setDialogLoadingState(DIALOG_STATE.ERROR);
        return;
      }

      // Set user lists
      setFromUserList(Utils.transformArray(fromUserResult.value, { id: "Id", name: "Name" }), true);
     // await loadToUserList(coverage.adjusterId);

      setDialogLoadingState(DIALOG_STATE.READY);
    } catch (error) {
      console.error("Error loading page:", error);
      setDialogInitializationErrorMessage(`Oops! There was an error loading the dialog box. - ${error.message}`);
      setDialogLoadingState(DIALOG_STATE.ERROR);
    }
  });

  useEffect(() => {
    initializeDialog();
  }, [initializeDialog]);

  const handleRetry = () => {
    initializeDialog();
  };

  const handleCancel = () => {
    cancelCommand();
    hideModal();
    onCancel?.();
    onStatusUpdate({ isSuccess: true, message: "Cancel pressed!" });
  };

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.startDate)) {
      addErrorMessage("startDate", "Please enter a start date.");
    } else {
      if (Validator.isDateBefore(formData.startDate, Date.now())) {
        addErrorMessage("startDate", "Start must be today or later.");
      }
    }

    if (Validator.isEmpty(formData.throughDate)) {
      addErrorMessage("throughDate", "Please enter a through date.");
    }

    if (!Validator.isEmpty(formData.startDate) && !Validator.isEmpty(formData.throughDate)) {
      if (!Validator.isDateBefore(formData.startDate, formData.throughDate)) {
        addErrorMessage("startDate", "Start must come before through date.");
      }
    }

    if (Validator.isEmpty(formData.toUser)) {
      addErrorMessage("toUser", "Please select a to user.");
    }

    if (Validator.isEmpty(formData.fromUser)) {
      addErrorMessage("fromUser", "Please select a from user.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleSaveCoverage = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    setIsSaving(true);

    let command = new UpdateCoverageCommand(formData);
    //let result = await execute(command);
    let result = {};

    result.isSuccess = false;
    result.isError = true;
    result.error = {};
    result.error.message = "Failed to fetch";

    if (result.isSuccess) {
      hideModal();

      console.log(result);
      onStatusUpdate({ isSuccess: true, message: `Approved orders.` });
      onOk?.();
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", "There was a problem approving orders.");
      }
    }
  };

  const loadToUserList = useStableFunction(async fromUserAccountId => {
    console.log("loadToUserList called!!!!!!!", fromUserAccountId);

    clear();

    if (!fromUserAccountId) {
      addGlobalErrorMessage("userAccountId is required");

      return;
    }

    // Executing Command should never return an error but we'll use a try-catch just in case
    try {
      setIsLoading(true);

      const command = new FindAssignToCandidatesCommand(fromUserAccountId);
      const result = await execute(command);

      // setIsLoading(false);

      // Handle canceled request - normally because user left the page and page unmounted
      if (result.isCanceled) return;

      // Handle successful API call
      if (result.isSuccess) {
        // Check if assignToCandidateList was found
        if (Utils.isObjectEmpty(result.value)) {
          addGlobalErrorMessage("assignToCandidateList was not found!");
          return;
        }

        // Process valid assignToCandidateList
        setToUserList(Utils.transformArray(result.value, { id: "userAccountId", name: "adjusterName" }), true);
        return;
      }

      // Handle API error
      throw new Error(result.error?.message || "Unknown error occurred");
    } catch (error) {
      console.error("Error loading page:", error);
      addGlobalErrorMessage(`assignToCandidateList was not found - ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  });

  // Called when "From User" is changed. "To User" list is dependent on the selected "From User".
  useEffect(() => {
    loadToUserList(formData.fromUser);
  }, [addErrorMessage, addGlobalErrorMessage, formData.fromUser, loadToUserList]);

  return (
    <Modal
      className={styles.editCoverageDialog}
      width="600px"
      title={title}
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button onClick={handleSaveCoverage} loading={isSaving} disabled={dialogLoadingState !== DIALOG_STATE.READY}>
            OK
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <PageStateContainer
          errorStyle={{ marginTop: ".75rem" }}
          loadingStyle={{ marginTop: ".75rem" }}
          state={dialogLoadingState}
          initializationErrorMessage={dialogInitializationErrorMessage}
          onRetry={handleRetry}
          renderDelay={333}
        >
          {dialogLoadingState === DIALOG_STATE.READY && (
            <>
              <BlockMessage variant="error" className={styles.blockMessage} onClose={() => removeErrorMessage("global")}>
                {getErrorMessage("global")}
              </BlockMessage>

              <Grid>
                <Row>
                  <Column width="50%">
                    <SingleSelect
                      style={{ width: "100%" }}
                      required
                      label="From User"
                      placeholder="Select One..."
                      name="fromUser"
                      value={formData.fromUser}
                      options={fromUserList}
                      onChange={handleMagneticChange("fromUser", "select")}
                      validationError={getErrorMessage("fromUser")}
                    />
                  </Column>

                  <Column width="50%">
                    <LoadableSingleSelect
                      style={{ width: "100%" }}
                      required
                      isLoading={isLoading}
                      disabled={isLoading || Utils.isEmpty(toUserList)}
                      label="Assigned To"
                      placeholder="Select One..."
                      name="toUser"
                      value={formData.toUser}
                      options={toUserList}
                      onChange={handleMagneticChange("toUser", "select")}
                      validationError={getErrorMessage("toUser")}
                    />
                  </Column>
                </Row>

                <Row>
                  <Column width="50%">
                    <DatePickerWithEnter
                      label="Start Date"
                      required
                      data-name="startDate"
                      style={{ width: "100%" }}
                      value={formData.startDate}
                      onChange={handleMagneticChange("startDate", "text")}
                      validationError={getErrorMessage("startDate")}
                    />
                  </Column>

                  <Column width="50%">
                    <DatePickerWithEnter
                      label="Through Date"
                      required
                      data-name="throughDate"
                      style={{ width: "100%" }}
                      value={formData.throughDate}
                      onChange={handleMagneticChange("throughDate", "text")}
                      validationError={getErrorMessage("throughDate")}
                    />
                  </Column>
                </Row>
              </Grid>

              <ProgressIndicator isLoading={isSaving} position="bottom" />
            </>
          )}
        </PageStateContainer>
      </div>
    </Modal>
  );
};

export { EditCoverageDialog };
