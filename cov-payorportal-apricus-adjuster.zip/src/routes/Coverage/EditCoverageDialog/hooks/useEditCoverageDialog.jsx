import { useModal } from "csg-react-magnetic/modal";

import { EditCoverageDialog } from "../EditCoverageDialog";

function useEditCoverageDialog() {
  const [editCoverageDialog, showModal, hideModal] = useModal();

  const showEditCoverageDialog = ({ title, coverage, onStatusUpdate, onOk, onCancel }) => {
    showModal(
      <EditCoverageDialog
        title={title}
        coverage={coverage}
        onStatusUpdate={onStatusUpdate}
        onOk={onOk}
        onCancel={onCancel}
        hideModal={hideModal}
      />
    );
  };

  return { editCoverageDialog, showEditCoverageDialog };
}

export { useEditCoverageDialog };
