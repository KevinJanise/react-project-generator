import styles from "./CoverageSearchResults.module.css";

import { Link } from "react-router-dom";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { CoverageTable } from "./CoverageTable";

import { useConfirmationDialog } from "components/ConfirmationDialog";
import { useEditCoverageDialog } from "./EditCoverageDialog";
import { useGrowler } from "hooks/growler";

import * as Utils from "utils/Utils";

function CoverageSearchResults({ coverageList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasCoverage = Utils.isNotEmpty(coverageList);
  // const hasCoverage = Boolean(coverageList?.length > 0)

  const { confirmationDialog, showConfirmationDialog } = useConfirmationDialog();
  const { editCoverageDialog, showEditCoverageDialog } = useEditCoverageDialog();
  const { showSuccessGrowler, showErrorGrowler } = useGrowler();

  const handleOnAddNewCoverage = () => {
    console.log("handleOnAddNewCoverage", {});
    let coverage = {};
    showEditCoverageDialog({title: "Add Coverage", coverage, onStatusUpdate});
  };

  const handleOnEditCoverage = coverage => {
    console.log("handleOnEdit", coverage);
    showEditCoverageDialog({title: "Edit Coverage", coverage, onStatusUpdate});
  };

  // User click on the OK button in the confirmation dialog
  const deleteCoverage = coverage => {
    console.log("deleteCoverage", coverage);
    showSuccessGrowler(`Deleted coverage for ${coverage.coverageFor}`);
    onStatusUpdate({ isSuccess: false, message: "There was an error deleting coverage, it was not deleted." });
  };

  // User clicked on the delete action button in the table
  const handleOnDeleteCoverage = coverage => {
    console.log("** handleOnDelete", coverage);

    showConfirmationDialog({
      title: "Delete Coverage",
      // yesLabel: "Yes",
      // noLabel: "No",
      onYes: () => deleteCoverage(coverage),
      onNo: () => {
        showSuccessGrowler(`Canceld delete coverage for ${coverage.adjusterName}`);
      },
      message: (
        <p>
          Delete coverage for <strong>{coverage.adjusterName}</strong> from <strong>{coverage.startDate}</strong> through{" "}
          <strong>{coverage.throughDate}</strong>?
        </p>
      )
    });
  };

  return (
    <PageSection className={styles.coverageSearchResults}>
      <LoadingIndicator isLoading={isLoading} renderDelay={333}>
        {!errorMessage && (
          <p className={styles.coverageNotFoundMessage} onClick={handleOnAddNewCoverage}>
            Coverage not found? Add new coverage.
          </p>
        )}

        {hasCoverage && (
          <Grid>
            <Row>
              <Column width="100%">
                <CoverageTable coverageList={coverageList} onEdit={handleOnEditCoverage} onDelete={handleOnDeleteCoverage} />
              </Column>
            </Row>
          </Grid>
        )}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>

        {confirmationDialog}
        {editCoverageDialog}
      </LoadingIndicator>
    </PageSection>
  );
}

export { CoverageSearchResults };
