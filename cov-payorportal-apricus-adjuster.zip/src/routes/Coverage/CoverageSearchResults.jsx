import styles from "./CoverageSearchResults.module.css";

import { Link } from "react-router-dom";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { CoverageTable } from "./CoverageTable";

import { useConfirmationDialog } from "components/ConfirmationDialog";
import { useGrowler } from "hooks/growler";

function CoverageSearchResults({ coverageList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasCoverageListItems = coverageList && coverageList.length > 0;
  const { confirmationDialog, showConfirmationDialog } = useConfirmationDialog();
  const { showSuccessGrowler, showErrorGrowler } = useGrowler();

  const handleOnEdit = coverage => {
    console.log("handleOnEdit", coverage);
  };

  // User click on the OK button in the confirmation dialog
  const deleteCoverage = coverage => {
    console.log("deleteCoverage", coverage);
    showSuccessGrowler(`Deleted coverage for ${coverage.adjusterName}`);
  };

  // User clicked on the delete action button in the table
  const handleOnDelete = coverage => {
    showConfirmationDialog({
      title: "Delete Coverage",
      // yesLabel: "Yes",
      // noLabel: "No",
      onYes: () => deleteCoverage(coverage),
      onNo: () => {
        showSuccessGrowler(`Canceld delete coverage for ${coverage.adjusterName}`);
      },
      message: (
        <p>
          Delete coverage for <strong>{coverage.adjusterName}</strong> from <strong>{coverage.startDate}</strong> through{" "}
          <strong>{coverage.throughDate}</strong>?
        </p>
      )
    });
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection className={styles.coverageSearchResults}>
        {!errorMessage && (
          <p className={styles.coverageNotFoundMessage}>
            Coverage not found?{" "}
            <Link to={"/submitCoverage"} className={styles.submitCoverageLink}>
              Add new coverage.
            </Link>
          </p>
        )}

        {hasCoverageListItems && (
          <Grid>
            <Row>
              <Column width="100%">
                <CoverageTable coverageList={coverageList} onEdit={handleOnEdit} onDelete={handleOnDelete} />
              </Column>
            </Row>
          </Grid>
        )}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
      </PageSection>

      {confirmationDialog}
    </LoadingIndicator>
  );
}

export { CoverageSearchResults };
