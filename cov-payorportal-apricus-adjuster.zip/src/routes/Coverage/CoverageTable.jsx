import styles from "./CoverageTable.module.css";
import { Link } from "react-router-dom";

import { DataGrid } from "csg-react-magnetic/data-grid";

import { ButtonBar } from "components/ButtonBar";
import { ToolbarButton } from "components/ToolbarButton";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

/**
 * CoverageTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 * It allows for selection of multiple orders and provides pagination functionality.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.claimList - An array of order objects to be displayed in the table
 * @param {Function} props.onOrderSelected - Callback function triggered when orders are selected
 *
 * @example
 * <CoverageTable
 *   claimList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 *   onOrderSelected={(selectedOrders) => console.log(selectedOrders)}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function CoverageTable({ coverageList, onEdit, onDelete }) {
  // headerTemplate is what appears in the table header
  // template is what appears in the row. Create one if you want something custom such as a link
  // otherwise it will use the field in the object array corresponding to the column id
  const columnTemplates = [
    {
        id: "startDate",
        name: "Start Date",
        sortable: true,
        headerStyle: { minWidth: "140px" }
      },
      {
        id: "throughDate",
        name: "Through Date",
        sortable: true,
        headerStyle: { minWidth: "140px" }
      },
      {
      id: "coverageFor",
      name: "Coverage For",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "coveringAdjusterName",
      name: "Coverage Assigned To",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "action",
      name: "Action",
      headerStyle: { width: "auto", minWidth: "150px" },
      template: (col, row) => (
        <ButtonBar variant="toolbar">
          <ToolbarButton title="Delete" icon="delete" onClick={() => onDelete(row)} />
          <ToolbarButton title="Edit" icon="edit" onClick={() => onEdit(row)} />
        </ButtonBar>
      )
    }
  ];

  return (
    <DataGrid
      data={coverageList}
      columns={columnTemplates}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
    />
  );
}

export { CoverageTable };
