import { DataGrid } from "csg-react-magnetic/data-grid";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15];

const columnTemplates = [
    {
        id: "decisionDt",
        name: "Date",
        sortable: true,
        headerStyle: { minWidth: "140px" }
      },
      {
        id: "decision",
        name: "Status",
        sortable: true,
        headerStyle: { minWidth: "140px" }
      },
      {
        id: "actorNm",
        name: "User",
        sortable: true,
        headerStyle: { minWidth: "120px" }
      },
              {
    id: "comments",
    name: "Comments",
    sortable: true,
    headerStyle: { minWidth: "200px" }
  },
];

/**
 * OrderStatusHistoryTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.statusHistoryList - An array of order objects to be displayed in the table
 *
 * @example
 * <OrderStatusHistoryTable
 *   statusHistoryList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function OrderStatusHistoryTable({ statusHistoryList }) {
  return (
    <div>
      <DataGrid
        data={statusHistoryList}
        columns={columnTemplates}
        pageable={{
          paginator: false,
          first: 0,
          rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
          rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
        }}
      />
    </div>
  );
}

export { OrderStatusHistoryTable };
