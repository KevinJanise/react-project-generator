import styles from "./OrderDetail.module.css";

import { useState, useEffect } from "react";

import { useParams, useLocation } from "react-router-dom";

import { LabelValuePair } from "csg-react-magnetic/label-value-pair";
import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { SingleSelect } from "csg-react-magnetic/single-select";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { LabeledControlGroup } from "components/LabeledControlGroup";
import { PageStateContainer, PAGE_STATE } from "components/PageStateContainer";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useGrowler } from "hooks/growler";
import { useStableFunction } from "hooks/useStableFunction";
import { useApproveOrdersDialog, useDenyOrdersDialog, useTransferOrdersDialog } from "components/OrderDialogs";

import { FindOrderDetailCommand } from "services/FindOrderDetailCommand";

import { ServiceItemsTable } from "./ServiceItemsTable";

import * as Utils from "utils/Utils";
import * as FormatUtils from "utils/FormatUtils";

function OrderDetail() {
  const [pageState, setPageState] = useState(PAGE_STATE.LOADING);
  const [errorMessage, setErrorMessage] = useState(null);
  const [pageInitializationErrorMessage, setPageInitializationErrorMessage] = useState(null);
  const [orderDetail, setOrderDetail] = useState(null);
  const [pageTitle, setPageTitle] = useState("Order Details");
  // const { orderNumber, offlineDataFlag } = useParams(); // get order number from URL

  const location = useLocation();
  const { orderNumber, offlineDataFlag } = location.state || {}; // get data from behind the scenes

  const { approveOrdersDialog, showApproveOrdersDialog } = useApproveOrdersDialog();
  const { denyOrdersDialog, showDenyOrdersDialog } = useDenyOrdersDialog();
  const { transferOrdersDialog, showTransferOrdersDialog } = useTransferOrdersDialog();

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();

  const clear = () => {
    clearSearchResults();
  };

  const clearSearchResults = () => {
    setErrorMessage(null);
    setPageInitializationErrorMessage(null);
  };

  // TODO - move this logic to the other pages!!!!!!!!!!!!!!
  const initializePage = useStableFunction(async () => {
    setPageState(PAGE_STATE.LOADING);
    clear();

    // Executing Command should never return an error but we'll use a try-catch just in case
    try {
      const command = new FindOrderDetailCommand(orderNumber, offlineDataFlag);
      const result = await execute(command);

    if (Math.random() < 10.5) {
      result.isSuccess = false;
      result.isError = true;
      result.error = {};
      result.error.message = "Failed to fetch";
    }

      // Handle canceled request
      if (result.isCanceled) return;

      // Handle successful API call
      if (result.isSuccess) {
        // Check if order details were found
        if (Utils.isObjectEmpty(result.value)) {
          setPageInitializationErrorMessage("Order was not found!");
          setPageState(PAGE_STATE.ERROR);
          return;
        }

        // Process valid order details
        setOrderDetail(result.value);
        setPageTitle(`Order Details - ${result.value.orderNum} - ${result.value.status}`);
        setPageState(PAGE_STATE.READY);
        return;
      }

      // Handle API error
      throw new Error(result.error.message || "Unknown error occurred");
    } catch (error) {
      console.error("Error loading order details:", error);
      setPageInitializationErrorMessage(`Oops! There was an error loading the page. - ${error.message}`);
      setPageState(PAGE_STATE.ERROR);
    }
  });

  useEffect(() => {
    initializePage();

    return () => {
      // TODO Cleanup logic if needed
    };
  }, [initializePage]);

  const handleStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const handleRetry = () => {
    initializePage();
  };

  const handleApprove = () => {
    showApproveOrdersDialog([orderDetail], handleStatusUpdate);
  };

  const handleDeny = () => {
    showDenyOrdersDialog([orderDetail], handleStatusUpdate);
  };

  const handleTransfer = () => {
    showTransferOrdersDialog([orderDetail], handleStatusUpdate);
  };

  const handleContactApricus = () => {
    //    showContactApricusDialog([orderDetail]);
  };

  const formatAddress = (theStreet, theCity, theState, theZip) => {
    // Extract and trim all address fields
    const street = theStreet?.trim() || "";
    const city = theCity?.trim() || "";
    const state = theState?.trim() || "";
    const zip = theZip?.trim() || "";

    // Check if all fields are empty after trimming
    if (!street && !city && !state && !zip) {
      return null;
    }

    // Format the address string with trimmed values
    return `${FormatUtils.capitalizeWords(street)}\n${FormatUtils.capitalizeWords(city)}, ${state.toUpperCase()} ${zip}`;
  };

  const ActionButtons = () => {
    return (
      <ButtonBar className={styles.actionButtonBar}>
        <Button variant="primary" type="button" onClick={handleApprove}>
          <span className="noWrap">Approve</span>
        </Button>

        <Button variant="primary" type="button" onClick={handleDeny}>
          <span className="noWrap">Deny</span>
        </Button>

        <Button variant="primary" type="button" onClick={handleTransfer}>
          <span className="noWrap">Transfer</span>
        </Button>

        <Button variant="primary" type="button" onClick={handleContactApricus}>
          <span className="noWrap">Contact Apricus</span>
        </Button>
      </ButtonBar>
    );
  };

  // {isPageInitialized && assignedToCandidateList?.length > 0 && (

  // What should isPageInitialized mean? It was done successfully and is ready to be used.
  // What would it be if you ran though the initialization but there was an error?
  // How can you make that code clear as to how it is handled?

  return (
    <div data-testid="order-detail" className={styles.orderDetail}>
      <PageTitle title={`${pageTitle}`} />

      <PageStateContainer
        state={pageState}
        initializationErrorMessage={pageInitializationErrorMessage}
        onRetry={handleRetry}
        renderDelay={333}
      >
        {pageState === PAGE_STATE.READY && (
          <>
            <BlockMessage variant="error" style={{ marginBottom: "1rem" }}>
              {errorMessage}
            </BlockMessage>

            <Grid style={{ marginBottom: "1rem" }}>
              <Row>
                <Column style={{ paddingLeft: "0rem" }}>
                  <ActionButtons />
                </Column>
              </Row>
            </Grid>

            <PageSection>
              <PageSection title="Claim Details">
                <Grid>
                  <Row>
                    <Column width="33.33%">
                      <LabelValuePair label="Claim Number">{orderDetail.claimNum}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Claimant Name">{FormatUtils.capitalizeWords(orderDetail.claimantNm)}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Claim Type">{orderDetail.claimType}</LabelValuePair>
                    </Column>
                  </Row>

                  <Row>
                    <Column width="33.33%">
                      <LabelValuePair label="Date of Birth">{orderDetail.birthDt}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Date of Injury">{orderDetail.injuryDt}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Jurisdiction">{orderDetail.jurisdiction}</LabelValuePair>
                    </Column>
                  </Row>

                  <Row>
                    <Column width="33.33%">
                      <LabelValuePair label="Employer">{orderDetail.employer}</LabelValuePair>
                    </Column>
                  </Row>
                </Grid>
              </PageSection>

              <PageSection title="Order Details" style={{ marginTop: "1rem" }}>
                <Grid>
                  <Row noCollapse={false}>
                    <Column width="33.33%">
                      <LabelValuePair label="Order Date">{orderDetail.orderDt}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Requested By">{orderDetail.requester}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Requester Role">{orderDetail.requesterRole}</LabelValuePair>
                    </Column>
                  </Row>

                  <Row noCollapse={false}>
                    <Column width="33.33%">
                      <LabelValuePair label="Prescriber">{FormatUtils.capitalizeWords(orderDetail.prescriberNm)}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Prescriber Phone">{orderDetail.prescriberPhone}</LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Authorization Reason">{orderDetail.authorizationReason}</LabelValuePair>
                    </Column>
                  </Row>

                  <Row>
                    <Column width="33.33%">
                      <LabelValuePair label="Delivery / Service Address">
                        <div className={styles.address}>
                          {formatAddress(
                            orderDetail.deliveryServiceAddressLine1,
                            orderDetail.deliveryServiceCity,
                            orderDetail.deliveryServiceState,
                            orderDetail.deliveryServiceZip
                          )}
                        </div>
                      </LabelValuePair>
                    </Column>
                    <Column width="33.33%">
                      <LabelValuePair label="Facility / Other">Missing !!!</LabelValuePair>
                    </Column>
                  </Row>

                  <Row>
                    <Column width="100%">
                      <ServiceItemsTable serviceItemList={orderDetail.serviceItems} />
                    </Column>
                  </Row>
                </Grid>
              </PageSection>

              <PageSection title="Documents" style={{ marginTop: "1rem" }}>
                <h4>Documents Go Here!</h4>
              </PageSection>
            </PageSection>

            {/* References to dialogs here  */}
            {approveOrdersDialog}
            {denyOrdersDialog}
            {transferOrdersDialog}
          </>
        )}
      </PageStateContainer>
    </div>
  );
}

export { OrderDetail };
