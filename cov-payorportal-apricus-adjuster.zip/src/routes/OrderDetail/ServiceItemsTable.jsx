import styles from "./OrderDetail.module.css";

import { DataGrid } from "csg-react-magnetic/data-grid";
import { Icon } from "csg-react-magnetic/icon";
import { Tooltip } from "csg-react-magnetic/tooltip";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15];

const columnTemplates = [
  {
    id: "description",
    name: "Item / Service Description",
    sortable: true,
    headerStyle: { minWidth: "100px", width: "100px" }
  },
  {
    id: "rental",
    name: "Rental",
    sortable: true,
    headerStyle: { minWidth: "120px" },
    // row template for rental column
    template: (col, row) => {
      if (row?.rental !== "") {
        return row.rental === "N" ? "No" : "Yes";
      } else {
        return <></>;
      }
    }
  },
  {
    id: "status",
    name: "Status",
    sortable: true,
    headerStyle: { minWidth: "140px" }
  },
  {
    id: "serviceDt",
    name: "Service Date",
    sortable: true,
    headerStyle: { minWidth: "140px" }
  },
  {
    id: "price",
    name: "Price",
    sortable: true,
    headerStyle: { minWidth: "130px" },
    // column header template
    headerTemplate: (col, row) => {
      return (
        <>
          <span className="wrapAtSpaces">{col.name}</span>
          <Icon id="tooltipTrigger" className={styles.tooltipIcon} style={{ marginLeft: ".5rem", pointerEvents: "auto" }} iconClass="help-outlined-circle" />
          <Tooltip triggerId="tooltipTrigger">
            <p className={styles.tooltipText}>This is an estimate. Actual price will be determined at the time of billing.</p>
          </Tooltip>
        </>
      );
    }
  },
  {
    id: "code",
    name: "Code",
    sortable: true,
    headerStyle: { minWidth: "120px" }
  },
  {
    id: "quantity",
    name: "Quantity",
    sortable: true,
    headerStyle: { minWidth: "130px" }
  }
];

/**
 * ServiceItemsTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.serviceItemList - An array of order objects to be displayed in the table
 *
 * @example
 * <ServiceItemsTable
 *   serviceItemList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function ServiceItemsTable({ serviceItemList }) {
  return (
    <div>
      <DataGrid
        data={serviceItemList}
        columns={columnTemplates}
        pageable={{
          paginator: false,
          first: 0,
          rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
          rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
        }}
      />
    </div>
  );
}

export { ServiceItemsTable };
