// components/OrderResults.js
import { useState } from "react";

import { Link } from "react-router-dom";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { SingleSelect } from "csg-react-magnetic/single-select";
import { LabelValuePair } from "csg-react-magnetic/label-value-pair";
import { DatePicker } from "csg-react-magnetic/date-picker";

import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { ErrorMessage } from "components/ErrorMessage";
import { LabeledControlGroup } from "components/LabeledControlGroup";
import { PageSection } from "components/PageSection";

import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import * as FormatUtils from "utils/FormatUtils";

function ClaimActivityResults({ claimDetail, isLoading, resultMessage, onStatusUpdate }) {
  let initialFormState = { afterDate: null, showPending: false, showActive: false, showCompleted: false };
  const { formData, handleChange, resetForm, handleMagneticChange, updateInitialState, setFormData } = useForm(initialFormState);
  const {
    addErrorMessage,
    clearErrorMessages,
    getErrorMessage,
    hasErrorMessages,
    hasFieldSpecificErrors,
    setFocusOnFirstError
  } = useErrorMessages();

  const handleFilterOrders = () => {
    console.log("handleFilterOrders");
  };

  const handleOrderServices = () => {
    console.log("handleOrderServcies");
  };

  const handleDownloadClaimActivity = () => {
    console.log("handleDownloadClaimActivity");
  };

  const ActionButtons = () => {
    return (
      <ButtonBar style={{ marginBottom: "1rem" }}>
        <Button variant="primary" type="button" onClick={handleOrderServices}>
          Order Services
        </Button>

        <Button variant="primary" type="button" onClick={handleDownloadClaimActivity}>
          Download Claim Activity
        </Button>
      </ButtonBar>
    );
  };

  return (
    <>
      {claimDetail && (
        <div>
          <Grid>
            <Row>
              <Column>
                <ActionButtons />
              </Column>
            </Row>
          </Grid>

          <PageSection contentStyle={{ paddingTop: ".75rem" }}>
            <Grid>
              <Row>
                <Column width="33.33%">
                  <LabelValuePair label="Claimant Name">{claimDetail.claimantName}</LabelValuePair>
                </Column>
                <Column width="33.33%">
                  <LabelValuePair label="Date of Birth">{FormatUtils.convertDateFormat(claimDetail.dateOfBirth)}</LabelValuePair>
                </Column>
                <Column width="33.33%">
                  <LabelValuePair label="Claim Type">{claimDetail.claimType || "N/A"}</LabelValuePair>
                </Column>
              </Row>

              <Row>
                <Column width="33.33%">
                  <LabelValuePair label="Date of Injury">{FormatUtils.convertDateFormat(claimDetail.dateOfInjury)}</LabelValuePair>
                </Column>
                <Column width="33.33%">
                  <LabelValuePair label="Jurisdiction">{claimDetail.jurisdiction || "N/A"}</LabelValuePair>
                </Column>
                <Column width="33.33%">
                  <LabelValuePair label="Employer">{claimDetail.employer || "N/A"}</LabelValuePair>
                </Column>
              </Row>
            </Grid>
          </PageSection>

          <PageSection style={{ marginTop: "1rem" }} contentStyle={{ paddingTop: ".75rem" }}>
            <Grid>
              <Row>
                <Column>
                  <span>Show Orders / Referrals </span>
                </Column>
              </Row>
              <Row>
                <Column width="50%">
                  <DatePicker
                    label="Received After"
                    data-name="afterDate"
                    style={{ width: "100%" }}
                    value={formData.dateOfInjury}
                    onChange={handleMagneticChange("afterDate", "text")}
                    validationError={getErrorMessage("afterDate")}
                  />
                </Column>

                <Column width="50%">
                  <LabeledControlGroup
                    label="Status Is"
                    style={{ width: "100%" }}
                    layout="row"
                    validationError={getErrorMessage("orderStatus")}
                  >
                    <Checkbox
                      style={{ marginRight: "2rem" }}
                      className="minWidthAuto"
                      label="Pending"
                      name="showPending"
                      checked={formData.showPending}
                      onChange={handleMagneticChange("showPending", "checkbox")}
                    />

                    <Checkbox
                      style={{ marginRight: "2rem" }}
                      className="minWidthAuto"
                      label="Active"
                      name="showActive"
                      checked={formData.showActive}
                      onChange={handleMagneticChange("showActive", "checkbox")}
                    />

                    <Checkbox
                      style={{ marginRight: "2rem" }}
                      className="minWidthAuto"
                      label="Completed"
                      name="showCompleted"
                      checked={formData.showCompleted}
                      onChange={handleMagneticChange("showCompleted", "checkbox")}
                    />
                  </LabeledControlGroup>
                </Column>
              </Row>

              <Row>
                <Column width="100%">
                  <Button variant="primary" type="button" onClick={handleFilterOrders}>
                    <span className="noWrap">Filter</span>
                  </Button>
                </Column>
              </Row>
            </Grid>
          </PageSection>
        </div>
      )}
    </>
  );
}

export { ClaimActivityResults };
