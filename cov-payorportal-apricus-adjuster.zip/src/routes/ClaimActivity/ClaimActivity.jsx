import styles from "./ClaimActivity.module.css";

import { useState, useEffect } from "react";
import { useLocation } from "react-router";

import { PageStateContainer, PAGE_STATE } from "components/PageStateContainer";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useStableFunction } from "hooks/useStableFunction";
import { useCommand } from "hooks/useCommand";
import { FindClaimDetailCommand } from "services/FindClaimDetailCommand";
import * as Utils from "utils/Utils";

import { ClaimActivityResults } from "./ClaimActivityResults";

function ClaimActivity() {
  const location = useLocation();
  const { claimSearchCriteria } = location.state || {}; // get data from behind the scenes
  const [claimDetail, setClaimDetail] = useState(null);
  const [pageLoadingState, setPageLoadingState] = useState(PAGE_STATE.LOADING);
  const [pageInitializationErrorMessage, setPageInitializationErrorMessage] = useState(null);
  const { execute } = useCommand();
  const hasClaimDetail = Utils.isNotEmpty(claimDetail);
  const [pageTitle, setPageTitle] = useState("Claim Activity");

  const clear = () => {
    setClaimDetail(null);
    setPageInitializationErrorMessage(null);
  };

  const initializePage = useStableFunction(async () => {
    setPageLoadingState(PAGE_STATE.LOADING);
    clear();

    if (!claimSearchCriteria) {
      setPageInitializationErrorMessage("claimSearchCriteria is required");
      setPageLoadingState(PAGE_STATE.ERROR);

      return;
    }

    // Executing Command should never return an error but we'll use a try-catch just in case
    try {
      const command = new FindClaimDetailCommand(claimSearchCriteria);
      const result = await execute(command);

      // Handle canceled request - normally because user left the page and page unmounted
      if (result.isCanceled) return;

      // Handle successful API call
      if (result.isSuccess) {
        // Check if claimDetail was found
        if (Utils.isObjectEmpty(result.value)) {
          setPageInitializationErrorMessage(`No claim activity was found for claim ${claimSearchCriteria.claimNumber}`);
          setPageLoadingState(PAGE_STATE.ERROR);
          return;
        }

        // Process valid claimDetail
        setClaimDetail(result.value);
        setPageTitle(`Claim Activity for Claim ${result.value.claimNum}`);
        setPageLoadingState(PAGE_STATE.READY);
        return;
      }

      // Handle API error
      throw new Error(result.error?.message || "Unknown error occurred");
    } catch (error) {
      console.error("Error loading page:", error);
      setPageInitializationErrorMessage(`Oops! There was an error loading the page. - ${error.message}`);
      setPageLoadingState(PAGE_STATE.ERROR);
    }
  });

  useEffect(() => {
    initializePage();
  }, [initializePage]);

  const handleRetry = () => {
    initializePage();
  };

  return (
    <div data-testid="claim-activity" className={styles.claimActivity}>
      <PageTitle title={pageTitle} />

      <PageSection>
        <PageStateContainer
          state={pageLoadingState}
          initializationErrorMessage={pageInitializationErrorMessage}
          onRetry={handleRetry}
          renderDelay={333}
        >
          {pageLoadingState === PAGE_STATE.READY && (
            <>
              <ClaimActivityResults
                claimDetail={claimDetail}
                onStatusUpdate={() => {
                  console.log("onStatusUpdate!!!!");
                }}
              />
            </>
          )}
        </PageStateContainer>
      </PageSection>
    </div>
  );
}

export { ClaimActivity };
