import styles from "./ClaimSearch.module.css";
import { Link } from "react-router-dom";

import { DataGrid } from "csg-react-magnetic/data-grid";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

// headerTemplate is what appears in the table header
// template is what appears in the row. Create one if you want something custom such as a link
// otherwise it will use the field in the object array corresponding to the column id
const columnTemplates = [
  {
    id: "status",
    name: "Claim Type",
    sortable: true,
    headerStyle: { minWidth: "150px" }
  },
  {
    id: "claimNumber",
    name: "Claim Number",
    sortable: true,
    headerStyle: { minWidth: "160px" },
    //    template: (col, row) => <Link to={`/claimActivity/${row.claimNumber}`} state={{row}}>{row[col.id]}</Link>,
    template: (col, row) => (
      <Link
        to={{
          pathname: "/claimActivity",
          state: {
            claimSearchCriteria: row // set key-value pairs here, value can be an object
          }
        }}
      >
        {row[col.id]}
      </Link>
    )
  },
  {
    id: "claimantName",
    name: "Claimant Name",
    sortable: true,
    headerStyle: { minWidth: "190px" },
    template: (col, row) => <span>{`${row.claimantFirstName + " " + row.claimantLastName}`}</span>
  },
  {
    id: "dob",
    name: "Date of Birth",
    sortable: true,
    headerStyle: { minWidth: "140px" },
    headerTemplate: (col, row) => <span className="wrapAtSpaces">{col.name}</span>
  },
  {
    id: "doi",
    name: "Date of Injury",
    sortable: true,
    headerStyle: { minWidth: "140px" },
    headerTemplate: (col, row) => <span className="wrapAtSpaces">{col.name}</span>
  },
  {
    id: "employer",
    name: "Employer",
    sortable: true,
    headerStyle: { minWidth: "190px" }
  },
  {
    id: "action",
    name: "Action",
    headerStyle: { width: "auto", minWidth: "0px" }
  }
];

/**
 * ClaimsTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 * It allows for selection of multiple orders and provides pagination functionality.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.claimList - An array of order objects to be displayed in the table
 * @param {Function} props.onOrderSelected - Callback function triggered when orders are selected
 *
 * @example
 * <ClaimsTable
 *   claimList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 *   onOrderSelected={(selectedOrders) => console.log(selectedOrders)}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function ClaimsTable({ claimList }) {
  return (
    <DataGrid
      data={claimList}
      columns={columnTemplates}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
    />
  );
}

export { ClaimsTable };
