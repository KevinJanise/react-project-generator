import styles from "./ClaimSearch.module.css";

import { useEffect, useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { TextField } from "csg-react-magnetic/text-field";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { DatePickerWithEnter } from "components/DatePickerWithEnter";
import { Grid, Row, Column } from "components/Grid";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { usePageState } from "hooks/usePageState";

import { FindClaimsCommand } from "services/FindClaimsCommand";

import { ClaimSearchResults } from "./ClaimSearchResults";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

function ClaimSearch() {
  const [claimList, setClaimList] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [message, setMessage] = useState(null);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();

  let initialFormState = { claimNumber: "", dateOfInjury: "", firstName: "", lastName: "" };
  const { formData, resetForm, handleMagneticChange, setFormData, trimValue } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  // Repopulate state variables and make service calls to get data.
  const { savePageState, clearPageState } = usePageState(
    "_ClaimSearch",
    pageState => {
      setFormData(pageState.formData);
      setHasSearched(pageState.hasSearched);
      doClaimSearch(pageState.formData);
    },
    null
  );

  const [disableField, setDisableField] = useState({
    claimNumber: false,
    firstName: false,
    lastName: false,
    dateOfInjury: false
  });

  const [searchBy, setSearchBy] = useState({
    claimNumber: false,
    claimant: false
  });

  // Enable and disable fields based on what fields user fills in.
  useEffect(() => {
    const claimNumberHasValue = Validator.isNotEmpty(formData.claimNumber, true);

    const otherFieldsHaveValue =
      Validator.isNotEmpty(formData.firstName, true) ||
      Validator.isNotEmpty(formData.lastName, true) ||
      Validator.isNotEmpty(formData.dateOfInjury, true);

    setSearchBy({
      claimNumber: claimNumberHasValue,
      claimant: otherFieldsHaveValue
    });

    setDisableField({
      claimNumber: otherFieldsHaveValue,
      firstName: claimNumberHasValue,
      lastName: claimNumberHasValue,
      dateOfInjury: claimNumberHasValue
    });
  }, [formData]);

  const validateForm = () => {
    clearErrorMessages();

    // if form is empty display an error message
    if (Validator.isEmpty(formData)) {
      addErrorMessage("global", "Please enter search criteria.");
      return false;
    }

    if (searchBy.claimNumber) {
      if (Validator.isNotEmpty(formData.claimNumber) && Validator.trimmedLength(formData.claimNumber) < 3) {
        addErrorMessage("claimNumber", "Enter at least 3 characters.");
      }
    } else if (searchBy.claimant) {
      if (Validator.isEmpty(formData.lastName)) {
        addErrorMessage("lastName", "Enter a last name.");
      }

      if (Validator.trimmedLength(formData.firstName) < 3) {
        addErrorMessage("firstName", "Enter at least 3 characters.");
      }
    }

    return !hasFieldSpecificErrors();
  };

  const doClaimSearch = async searchCriteria => {
    clearSearchResults();

    setHasSearched(true);

    let command = new FindClaimsCommand(searchCriteria);
    let result = await execute(command);

    console.log(result);

    if (result.isSuccess) {
      let list = result.value;

      setClaimList(list);

      if (Utils.isObjectEmpty(list)) {
        setMessage("No claims were found.");
        showSuccessGrowler("No claims were found.");
      } else {
        showSuccessGrowler(list.length === 1 ? "Found 1 claim." : `Found ${list.length} claims.`);
      }
    } else {
      let error = result.error;
      let errorMessage = null;

      console.error(error);

      if (error.message === "Failed to fetch") {
        errorMessage = "There was an error connecting to the server.";
      } else {
        errorMessage = "There was an error processing your request.";
      }

      setErrorMessage(errorMessage);
      showErrorGrowler(errorMessage);
    }
  };

  const handleClaimSearch = async event => {
    event.preventDefault();

    clearSearchResults();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    setHasSearched(true);

    // Save the validated form data but not the claim list. Reload list when page reloads.
    savePageState({ formData: formData, hasSearched: true });

    doClaimSearch(formData);
  };

  const showStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    setErrorMessage(null);
    setHasSearched(false);
    setClaimList(null);
  };

  const handleClear = () => {
    clearSearchResults();
    resetForm();
    clearPageState();
  };

  return (
    <div data-testid="claim-search" className={styles.claimSearch}>
      <PageTitle title="Claim Search" />

      <PageSection>
        <BlockMessage style={{ marginBottom: "1rem" }}>{getErrorMessage("global")}</BlockMessage>

        <form onSubmit={handleClaimSearch}>
          <PageSection>
            <Grid>
              <Row>
                <Column width="50%">
                  <TextField
                    label="Claim Number"
                    name="claimNumber"
                    required
                    onChange={handleMagneticChange("claimNumber", "text")}
                    value={formData.claimNumber}
                    validationError={getErrorMessage("claimNumber")}
                    disabled={disableField.claimNumber}
                    onBlur={trimValue}
                  />
                </Column>
              </Row>
            </Grid>
          </PageSection>

          <p style={{ paddingLeft: "1rem", fontWeight: "600", color: "#474552", fontSize: "0.857143rem" }}>Or</p>
          <PageSection style={{ marginBottom: "1rem" }}>
            <Grid>
              <Row>
                <Column width="50%">
                  <TextField
                    label="Last Name"
                    name="lastName"
                    required
                    onChange={handleMagneticChange("lastName", "text")}
                    value={formData.lastName}
                    validationError={getErrorMessage("lastName")}
                    disabled={disableField.lastName}
                    onBlur={trimValue}
                  />
                </Column>

                <Column width="50%">
                  <TextField
                    label="First Name"
                    name="firstName"
                    required
                    placeholder="3 characters minimum"
                    onChange={handleMagneticChange("firstName", "text")}
                    value={formData.firstName}
                    validationError={getErrorMessage("firstName")}
                    disabled={disableField.firstName}
                    onBlur={trimValue}
                  />
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <DatePickerWithEnter
                    label="Date of Injury"
                    data-name="dateOfInjury"
                    style={{ width: "100%" }}
                    value={formData.dateOfInjury}
                    onChange={handleMagneticChange("dateOfInjury", "text")}
                    validationError={getErrorMessage("dateOfInjury")}
                    disabled={disableField.dateOfInjury}
                    onBlur={trimValue}
                  />
                </Column>
              </Row>
            </Grid>
          </PageSection>

          <Grid>
            <Row>
              <Column width="100%">
                <ButtonBar>
                  <Button variant="primary" type="submit" loading={isExecuting}>
                    Search
                  </Button>

                  <Button variant="outline" type="button" onClick={handleClear}>
                    Clear
                  </Button>
                </ButtonBar>
              </Column>
            </Row>
          </Grid>
        </form>
      </PageSection>

      {hasSearched && (
        <ClaimSearchResults
          claimList={claimList}
          isLoading={isExecuting}
          resultMessage={message}
          errorMessage={errorMessage}
          onStatusUpdate={showStatusUpdate}
        />
      )}
    </div>
  );
}

export { ClaimSearch };
