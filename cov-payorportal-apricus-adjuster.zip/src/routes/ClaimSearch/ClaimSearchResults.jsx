import styles from "./ClaimSearchResults.module.css";

import { Link } from "react-router-dom";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { ClaimsTable } from "./ClaimsTable";

function ClaimSearchResults({ claimList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasClaims = Boolean(claimList?.length);

  return (
    <PageSection className={styles.claimSearchResults}>
      <LoadingIndicator isLoading={isLoading} renderDelay={333}>
        {!errorMessage && (
          <p className={styles.claimNotFoundMessage}>
            Claim not found?{" "}
            <Link to={"/submitOrder"} className={styles.submitClaimLink}>
              Submit Order / Referral for a new Claim
            </Link>
          </p>
        )}

        {hasClaims && (
          <Grid>
            <Row>
              <Column width="100%">
                <ClaimsTable claimList={claimList} />
              </Column>
            </Row>
          </Grid>
        )}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
      </LoadingIndicator>
    </PageSection>
  );
}

export { ClaimSearchResults };
