// components/OrderResults.js
import { useState } from "react";

import { Button } from "csg-react-magnetic/button";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { OrdersTable } from "./OrdersTable";
import { PageSection } from "components/PageSection";

import { useApproveOrdersDialog, useDenyOrdersDialog, useTransferOrdersDialog } from "components/OrderDialogs";
import { useServiceLinesDialog } from "components/ServiceLinesDialog";


function OrderResults({ orderList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasOrderListItems = Boolean(orderList?.length);

  const [isActionDisabled, setIsActionDisabled] = useState(true);
  const [selectedOrders, setSelectedOrders] = useState([]);
  const { approveOrdersDialog, showApproveOrdersDialog } = useApproveOrdersDialog();
  const { denyOrdersDialog, showDenyOrdersDialog } = useDenyOrdersDialog();
  const { transferOrdersDialog, showTransferOrdersDialog } = useTransferOrdersDialog();
  const { serviceLinesDialog, showServiceLinesDialog } = useServiceLinesDialog();

  const handleOrdersSelected = selectedOrders => {
    setIsActionDisabled(selectedOrders.length === 0);
    setSelectedOrders(selectedOrders);
  };

  const handleApprove = () => {
    showApproveOrdersDialog(selectedOrders, onStatusUpdate);
  };

  const handleDeny = () => {
    showDenyOrdersDialog(selectedOrders, onStatusUpdate);
  };

  const handleTransfer = () => {
    showTransferOrdersDialog(selectedOrders, onStatusUpdate);
  };

  const handleViewServiceLines = (orderNumber, serviceLines) => {
    showServiceLinesDialog(orderNumber, serviceLines);
  };

  return (
    <PageSection style={{ marginTop: "1rem" }}>
      <LoadingIndicator isLoading={isLoading} renderDelay={333}>
        {hasOrderListItems && (
          <div>
            <Grid>
              <Row>
                <Column align="left">
                  <Button
                    variant="primary"
                    type="button"
                    onClick={handleApprove}
                    disabled={isActionDisabled}
                    style={{ marginRight: "1rem" }}
                  >
                    Approve
                  </Button>

                  <Button variant="primary" type="button" onClick={handleDeny} disabled={isActionDisabled} style={{ marginRight: "1rem" }}>
                    Deny
                  </Button>

                  <Button variant="primary" type="button" onClick={handleTransfer} disabled={isActionDisabled}>
                    Transfer
                  </Button>
                </Column>
              </Row>

              <Row>
                <Column width="100%">
                  <OrdersTable orderList={orderList} onOrderSelected={handleOrdersSelected} onViewServiceLines={handleViewServiceLines} />
                </Column>
              </Row>
            </Grid>

            {/* References to dialogs here  */}
            {approveOrdersDialog}
            {denyOrdersDialog}
            {transferOrdersDialog}
            {serviceLinesDialog}
          </div>
        )}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
      </LoadingIndicator>
    </PageSection>
  );
}

export { OrderResults };
