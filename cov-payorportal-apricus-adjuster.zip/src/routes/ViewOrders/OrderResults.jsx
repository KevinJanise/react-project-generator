// components/OrderResults.js
import { useState } from "react";

import { Button } from "csg-react-magnetic/button";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { OrdersTable } from "./OrdersTable";
import { PageSection } from "components/PageSection";

import { useApproveOrdersDialog, useDenyOrdersDialog, useTransferOrdersDialog } from "components/OrderDialogs";

function OrderResults({ orderList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const { approveOrdersDialog, showApproveOrdersDialog } = useApproveOrdersDialog();
  const { denyOrdersDialog, showDenyOrdersDialog } = useDenyOrdersDialog();
  const { transferOrdersDialog, showTransferOrdersDialog } = useTransferOrdersDialog();
  const [isActionDisabled, setIsActionDisabled] = useState(true);
  const [selectedOrders, setSelectedOrders] = useState([]);

  const hasOrderListItems = orderList && orderList.length > 0;

  const handleOrdersSelected = selectedOrders => {
    setIsActionDisabled(selectedOrders.length === 0);
    setSelectedOrders(selectedOrders);
  };

  const handleApprove = () => {
    showApproveOrdersDialog(selectedOrders, onStatusUpdate);
  };

  const handleDeny = () => {
    showDenyOrdersDialog(selectedOrders, onStatusUpdate);
  };

  const handleTransfer = () => {
    showTransferOrdersDialog(selectedOrders, onStatusUpdate);
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection style={{ marginTop: "1rem" }}>
        {hasOrderListItems && (
          <div>
            <Grid>
              <Row>
                <Column align="left">
                  <Button
                    variant="primary"
                    type="button"
                    onClick={handleApprove}
                    disabled={isActionDisabled}
                    style={{ marginRight: "1rem" }}
                  >
                    Approve
                  </Button>

                  <Button variant="primary" type="button" onClick={handleDeny} disabled={isActionDisabled} style={{ marginRight: "1rem" }}>
                    Deny
                  </Button>

                  <Button variant="primary" type="button" onClick={handleTransfer} disabled={isActionDisabled}>
                    Transfer
                  </Button>
                </Column>
              </Row>

              <Row>
                <Column width="100%">
                  <OrdersTable orderList={orderList} onOrderSelected={handleOrdersSelected} />
                </Column>
              </Row>
            </Grid>

            {/* References to dialogs here  */}
            {approveOrdersDialog}
            {denyOrdersDialog}
            {transferOrdersDialog}
          </div>
        )}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
        
      </PageSection>
    </LoadingIndicator>
  );
}

export { OrderResults };
