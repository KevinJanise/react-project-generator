import styles from "./ViewOrders.module.css";
import { Link } from "react-router-dom";

import { DataGrid } from "csg-react-magnetic/data-grid";
import { Icon } from "csg-react-magnetic/icon";
import { Tooltip } from "csg-react-magnetic/tooltip";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

const columnTemplates = [
  {
    id: "status",
    name: "Status",
    sortable: true,
    headerStyle: { minWidth: "150px" }
  },
  {
    id: "orderDt",
    name: "Received Date",
    sortable: true,
    headerStyle: { minWidth: "140px" },
    headerTemplate: (col, row) => <span className="wrapAtSpaces">{col.name}</span>
  },
  {
    id: "orderNum",
    name: "Order #",
    sortable: true,
    headerStyle: { minWidth: "125px" },
    template: (col, row) => {
     // return <Link to={`/orderDetail/${row.orderId}/${row.offlineDataFlag}`}>{row[col.id]}</Link>;
     return <Link 
  to={{
    pathname: `/orderDetail`,
    state: { 
      orderNumber: row.orderId, 
      offlineDataFlag: row.offlineDataFlag 
    }
  }}
>
  {row[col.id]}
</Link>
    }
  },
  {
    id: "claimNum",
    name: "Claim Number",
    sortable: true,
    headerStyle: { minWidth: "140px" },
    template: (col, row) => <Link to={`/claimActivity/${row[col.id]}`}>{row[col.id]}</Link>,
    headerTemplate: (col, row) => <span className="wrapAtSpaces">{col.name}</span>
  },
  {
    id: "claimantNm",
    name: "Claimant Name",
    sortable: true,
    headerStyle: { minWidth: "150px" },
    headerTemplate: (col, row) => <span className="wrapAtSpaces">{col.name}</span>
  },
  /*
  {
    id: "serviceItems",
    name: "Items / Services",
    sortable: true,
    headerStyle: { minWidth: "200px" },
    // column header template
    headerTemplate: (col, row) => {
      return (
        <>
          <span className="wrapAtSpaces">{col.name}</span>

          <Icon id="tooltipTrigger" className={styles.tooltipIcon} style={{ marginLeft: ".5rem", pointerEvents: "auto" }} iconClass="help-outlined-circle" />
          <Tooltip triggerId="tooltipTrigger">
            <p className={styles.tooltipText}>The first item in the order is listed. Click on the Description to view all Service Items.</p>
          </Tooltip>
        </>
      );
    },
    // row template
    template: (col, row) => {
      // TODO - display popup for multiple lines?
      if (row.serviceItems?.length > 1) {
        return `${row.serviceItems.length} items!`;
      } else {
        return <>{row.serviceItems[0]}</>;
      }
    }
  },
  */
  /*
  {
    id: "prescriberNm",
    name: "Prescriber",
    sortable: true,
    headerStyle: { minWidth: "150px" }
  },
  {
    id: "requestedBy",
    name: "Requested By",
    sortable: true,
    headerStyle: { minWidth: "190px" }
  },
  {
    id: "requesterRole",
    name: "Requestor Role",
    sortable: true,
    headerStyle: { minWidth: "190px" }
  },
  */
  {
    id: "images",
    name: "Images",
    headerStyle: { minWidth: "120px" },
    // row template
    template: (col, row) => {
      // TODO - how many images types? Get icon/css based on type.
      if (row.images !== "") {
        return (
          <a href={`/dist/${row.images}`} className={styles.icon_pdf} target="_blank" rel="noopener noreferrer">
            {" "}
          </a>
        );
      } else {
        return <></>;
      }
    }
  },
  {
    id: "action",
    name: "Action",
    headerStyle: { width: "auto", minWidth: "0px" }
  }
];

/**
 * OrdersTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 * It allows for selection of multiple orders and provides pagination functionality.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.orderList - An array of order objects to be displayed in the table
 * @param {Function} props.onOrderSelected - Callback function triggered when orders are selected
 *
 * @example
 * <OrdersTable
 *   orderList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 *   onOrderSelected={(selectedOrders) => console.log(selectedOrders)}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function OrdersTable({ orderList, onOrderSelected }) {
  return (
    <DataGrid
      data={orderList}
      columns={columnTemplates}
      selectable={{
        trackByColumn: "claimNum",
        multiselect: true,
        showCheckbox: true,
        selectAllState: "unchecked"
      }}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
      onSelect={(selectedOrders, isAllSelection) => {
        onOrderSelected(selectedOrders);
      }}
    />
  );
}

export { OrdersTable };
