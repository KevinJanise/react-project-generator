import styles from "./ViewOrders.module.css";

import { useState, useEffect } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { SingleSelect } from "csg-react-magnetic/single-select";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { LabeledControlGroup } from "components/LabeledControlGroup";
import { PageStateContainer, PAGE_STATE } from "components/PageStateContainer";

import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { usePageState } from "hooks/usePageState";
import { useStableFunction } from "hooks/useStableFunction";

import { OrderResults } from "./OrderResults";

import { FindOrderListByAdjusterCommand } from "services/FindOrderListByAdjusterCommand";
import { FindAssignToCandidatesCommand } from "services/FindAssignToCandidatesCommand";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

// TODO - get from logged in user
const userAccountId = "001DM00002OQxahYAD";

function transformUserDataForDropdown(userList) {
  return userList.map(user => ({
    id: user.userAccountId,
    name: user.adjusterName
  }));
}

function ViewOrders() {
  const [pageState, setPageState] = useState(PAGE_STATE.LOADING);
  const [assignedToCandidateList, setAssignedToCandidateList] = useState([]);
  const [errorMessage, setErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [isFiltering, setIsFiltering] = useState(false);
  const [message, setMessage] = useState(null);
  const [orderList, setOrderList] = useState(null);
  const [pageInitializationErrorMessage, setPageInitializationErrorMessage] = useState(null);
  const [searchErrorMessage, setSearchErrorMessage] = useState(null);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();
  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  let initialFormState = { assignedTo: null, phases: ["PENDING", "ACTIVE"] };
  const { formData, resetForm, handleMagneticChange } = useForm(initialFormState);

  const clear = () => {
    clearSearchResults();
    resetForm();
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    setErrorMessage(null);
    setPageInitializationErrorMessage(null);
    setSearchErrorMessage(null);
    setHasSearched(false);
    setOrderList(null);
  };

  // stableFunction is a an unchanging ref to a function so you can pass it as a dependency
  // to useEffect. Behind the scenes the function it references updates on every page refresh
  // so it always has current values but doesn't cause a re-render.
  const initializePage = useStableFunction(async () => {
    setPageState(PAGE_STATE.LOADING);
    clear();

    const command = new FindAssignToCandidatesCommand(userAccountId);
    const result = await execute(command);

    // TODO - used for testing error condition - begin remove this!!!!!!!!!!!!!!

    if (Math.random() < -10.5) {
      result.isSuccess = false;
      result.isError = true;
      result.error = {};
      result.error.message = "Failed to fetch";
    }
    // TODO - end remove this!!!!!!!!!!!!!!

    if (result.isCanceled) return;

    if (result.isSuccess) {
      let candidateList = transformUserDataForDropdown(result.value);

      setAssignedToCandidateList(candidateList);

      if (Utils.isEmpty(candidateList)) {
        if (candidateList?.length === 0) {
          setPageInitializationErrorMessage(`No "Assign To" candidates were found. There is a problem with your account setup.`);
        } else {
          setPageInitializationErrorMessage("Assign to candidate list was not initialized!");
        }
        setPageState(PAGE_STATE.ERROR);
      } else {
        setPageState(PAGE_STATE.READY);
      }
    } else {
      console.error(result.error);
      setPageInitializationErrorMessage("Oops! There was an error loading the page.");
      setPageState(PAGE_STATE.ERROR);
    }
  });

  useEffect(() => {
    initializePage();
  }, [initializePage]);

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.assignedTo)) {
      addErrorMessage("assignedTo", "Select assigned to.");
    }

    if (formData.phases.length === 0) {
      addErrorMessage("phases", "Select order status.");
    }

    if (hasFieldSpecificErrors()) {
      addErrorMessage("global", "Fix errors on page!");
    }

    return !hasFieldSpecificErrors();
  };

  const filterOrders = async searchCriteria => {
    clearSearchResults();
    setIsFiltering(true);
    setHasSearched(true);

    console.log("searchCriteria: ", searchCriteria);

    let command = new FindOrderListByAdjusterCommand(searchCriteria);
    let result = await execute(command);
    console.log("FindOrderListByAdjusterCommand", result);

    setIsFiltering(false);

    // TODO - used for testing error condition - begin remove this!!!!!!!!!!!!!!

    /*
    result.isSuccess = false;
    result.isError = true;
    result.error = {};
    result.error.message = "Failed to fetch";
*/
    // TODO - end remove this!!!!!!!!!!!!!!

    if (result.isSuccess) {
      let list = result.value;

      setOrderList(list);

      if (Utils.isObjectEmpty(list)) {
        setMessage(`No orders were found.`);
        showSuccessGrowler("No orders were found.");
      } else {
        showSuccessGrowler(list.length === 1 ? "Found 1 order." : `Found ${list.length} orders.`);
      }
    } else {
      console.error(result.error);

      let errorMessage = "There was an error processing your request. Please try again later.";

      if (result.error.message === "Failed to fetch") {
        errorMessage = "There was an error connecting to the server.";
      }

      setSearchErrorMessage(errorMessage);
      showErrorGrowler(errorMessage);
    }
  };

  const handleStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const handleClear = () => {
    clear();
  };

  const handleFilterOrders = async event => {
    event.preventDefault();

    clearSearchResults();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    //    setHasSearched(true);
    //savePageState({ formData: formData, hasSearched: true });

    filterOrders(formData);
  };

  const handleRetry = () => {
    initializePage();
  };

  // {isPageInitialized && assignedToCandidateList?.length > 0 && (

  // What should isPageInitialized mean? It was done successfully and is ready to be used.
  // What would it be if you ran though the initialization but there was an error?
  // How can you make that code clear as to how it is handled?

  return (
    <div data-testid="view-orders" className={styles.viewOrders}>
      <PageTitle title="View Orders" />

      <PageSection>
        <PageStateContainer
          state={pageState}
          initializationErrorMessage={pageInitializationErrorMessage}
          onRetry={handleRetry}
          renderDelay={333}
        >
          {pageState === PAGE_STATE.READY && (
            <>
              <BlockMessage variant="error" style={{ marginBottom: "1rem" }}>
                {errorMessage}
              </BlockMessage>

              <form onSubmit={handleFilterOrders}>
                <Grid>
                  <Row>
                    <Column width="50%">
                      <SingleSelect
                        style={{ width: "100%" }}
                        required
                        label="Show Orders / Referrals Assigned To"
                        placeholder="Select One..."
                        name="assignedTo"
                        value={formData.assignedTo}
                        options={assignedToCandidateList}
                        onChange={handleMagneticChange("assignedTo", "select")}
                        validationError={getErrorMessage("assignedTo")}
                      />
                    </Column>

                    <Column width="50%">
                      <LabeledControlGroup
                        label="Show Orders / Referrals That Are"
                        layout="row"
                        required
                        validationError={getErrorMessage("phases")}
                        requiredFulfilled={formData.phases.length > 0}
                      >
                        <Checkbox
                          style={{ marginRight: "2rem" }}
                          className="minWidthAuto"
                          label="Pending"
                          name="phases"
                          checked={formData.phases.includes("PENDING")}
                          onChange={handleMagneticChange("phases", "checkbox", "PENDING")}
                        />

                        <Checkbox
                          style={{ marginRight: "2rem" }}
                          className="minWidthAuto"
                          label="Active"
                          name="phases"
                          checked={formData.phases.includes("ACTIVE")}
                          onChange={handleMagneticChange("phases", "checkbox", "ACTIVE")}
                        />

                        <Checkbox
                          style={{ marginRight: "2rem" }}
                          className="minWidthAuto"
                          label="Completed"
                          name="phases"
                          checked={formData.phases.includes("COMPLETED")}
                          onChange={handleMagneticChange("phases", "checkbox", "COMPLETED")}
                        />
                      </LabeledControlGroup>
                    </Column>
                  </Row>

                  <Row>
                    <Column width="100%">
                      <ButtonBar>
                        <Button variant="primary" type="button" onClick={handleFilterOrders} loading={isFiltering}>
                          <span className="noWrap">Filter</span>
                        </Button>

                        <Button variant="outline" type="button" onClick={handleClear}>
                          Clear
                        </Button>
                      </ButtonBar>
                    </Column>
                  </Row>
                </Grid>
              </form>
            </>
          )}
        </PageStateContainer>
      </PageSection>

      {hasSearched && (
        <OrderResults
          orderList={orderList}
          isLoading={isFiltering}
          resultMessage={message}
          errorMessage={searchErrorMessage}
          onStatusUpdate={handleStatusUpdate}
        />
      )}
    </div>
  );
}

export { ViewOrders };
