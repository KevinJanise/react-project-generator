import styles from "./OrderDetail.module.css";

import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

import { LabelValuePair } from "csg-react-magnetic/label-value-pair";

import { capitalizeWords } from "utils/FormatUtils";

import { Grid, Row, Column } from "components/Grid";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";
import { BlockMessage } from "components/BlockMessage";

import { FindOrderCommand } from "services/FindOrderCommand";

import { useCommand } from "hooks/useCommand";

import * as Utils from "utils/Utils";
import { LoadingIndicator } from "components/LoadingIndicator";

function OrderDetail() {
  const [orderDetail, setOrderDetail] = useState(null);
  const [message, setMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  // AppRouter.jsx - <Route exact path="/orderDetail/:orderNumber" component={OrderDetail} />
  const { orderNumber } = useParams(); // get order number from route URL

  const { execute, isExecuting } = useCommand();

  useEffect(() => {
    const findOrderDetail = async () => {
      const findOrderCommand = new FindOrderCommand(orderNumber);
      let result = await execute(findOrderCommand);

      if (result.isSuccess) {
        let detail = result.value;

        setOrderDetail(detail);

        if (Utils.isObjectEmpty(detail)) {
          setMessage("No order was found.");
        }
      } else {
        let error = result.error;
        let errorMessage = null;

        console.error(error);

        if (error.message === "Failed to fetch") {
          errorMessage = "There was an error connecting to the server.";
        } else {
          errorMessage = "There was an error processing your request.";
        }

        setErrorMessage(errorMessage);
      }
    };

    findOrderDetail();
  }, [execute, orderNumber]);

  return (
    <>
      <div className={styles.clientSearch}>
        <PageTitle title={`Order Details - ${orderNumber}`} />

        <LoadingIndicator isLoading={isExecuting}>
          <BlockMessage variant="warn"><span>{message}</span></BlockMessage>

          <BlockMessage variant="danger" heading="Processing Error"><p>{errorMessage}</p></BlockMessage>

          {orderDetail && (
            <>
              <PageSection title="Order Details">
                <Grid>
                  <Row>
                    <Column width="33%">
                      <LabelValuePair label="Order Date">{orderDetail.orderDt || "N/A"}</LabelValuePair>
                    </Column>
                    <Column width="33%">
                      <LabelValuePair label="Requested By">{orderDetail.requester}</LabelValuePair>
                    </Column>
                    <Column width="33%">
                      <LabelValuePair label="Requester Role">{orderDetail.requesterRole}</LabelValuePair>
                    </Column>
                  </Row>

                  <Row>
                    <Column width="33%">
                      <LabelValuePair label="Prescriber">{capitalizeWords(orderDetail.prescriberNm) || "N/A"}</LabelValuePair>
                    </Column>
                    <Column width="33%">
                      <LabelValuePair label="Prescriber Phone">{orderDetail.prescriberPhone}</LabelValuePair>
                    </Column>
                    <Column width="33%">
                      <LabelValuePair label="Authorization Reason">{orderDetail.authorizationReason || "N/A"}</LabelValuePair>
                    </Column>
                  </Row>
                </Grid>
              </PageSection>
            </>
          )}
        </LoadingIndicator>
      </div>
    </>
  );
}

export { OrderDetail };
