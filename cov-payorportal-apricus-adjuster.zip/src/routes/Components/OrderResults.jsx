// components/OrderResults.js
import { useState } from "react";

import { Button } from "csg-react-magnetic/button";

import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { OrdersTable } from "./OrdersTable";
import { PageSection } from "components/PageSection";
import { useApproveOrderDialog } from "components/TechSupportDialog";
import { useDenyOrderDialog } from "components/TechSupportDialog";
import { useTransferOrderDialog } from "components/TechSupportDialog";

export function OrderResults({ orderList, isLoading, resultMessage, onStatusUpdate }) {
  const { approveOrderDialog, showApproveOrderDialog } = useApproveOrderDialog(onStatusUpdate);
  const { denyOrderDialog, showDenyOrderDialog } = useDenyOrderDialog(onStatusUpdate);
  const { transferOrderDialog, showTransferOrderDialog } = useTransferOrderDialog(onStatusUpdate);
  const [isActionDisabled, setIsActionDisabled] = useState(true);
  const [selectedOrders, setSelectedOrders] = useState([]);

  const handleOrdersSelected = selectedOrders => {
    setIsActionDisabled(selectedOrders.length === 0);
    setSelectedOrders(selectedOrders);
  };

  const handleApprove = () => {
    showApproveOrderDialog(selectedOrders);
  };

  const handleDeny = () => {
    showDenyOrderDialog(selectedOrders);
  };

  const handleTransfer = () => {
    showTransferOrderDialog(selectedOrders);
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection style={{ marginTop: "1rem" }}>
        {orderList && orderList.length > 0 ? (
          <div>
            <Grid>
              <Row style={{ marginBottom: "1rem" }}>
                <Column width="auto">
                  <Button variant="primary" type="button" onClick={handleApprove} disabled={isActionDisabled}>
                    Approve
                  </Button>
                </Column>

                <Column width="auto">
                  <Button variant="primary" type="button" onClick={handleDeny} disabled={isActionDisabled}>
                    Deny
                  </Button>
                </Column>

                <Column width="auto">
                  <Button variant="primary" type="button" onClick={handleTransfer} disabled={isActionDisabled}>
                    Transfer
                  </Button>
                </Column>
              </Row>
            </Grid>

            <OrdersTable orderList={orderList} onOrderSelected={handleOrdersSelected} />

            {/* References to dialogs here  */}
            {approveOrderDialog}
            {denyOrderDialog}
            {transferOrderDialog}
          </div>
        ) : (
          <p>{resultMessage}</p>
        )}
      </PageSection>
    </LoadingIndicator>
  );
}
