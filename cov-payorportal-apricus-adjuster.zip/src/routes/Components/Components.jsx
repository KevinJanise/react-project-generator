import styles from "./Components.module.css";

import { useState, useEffect, useCallback, useRef } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { DatePicker } from "csg-react-magnetic/date-picker";
import { MultiSelect } from "csg-react-magnetic/multi-select";
import { RadioButton } from "csg-react-magnetic/radiobutton";
import { RadioButtonGroup } from "csg-react-magnetic/radiobutton-group";
import { SingleSelect } from "csg-react-magnetic/single-select";
import { TextArea } from "csg-react-magnetic/text-area";
import { TextField } from "csg-react-magnetic/text-field";

import { useCommand } from "hooks/useCommand";
import { useConfig } from "hooks/config";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { useMediaQuery } from "hooks/useMediaQuery";
import { usePageState } from "hooks/usePageState";
import { useStableFunction } from "hooks/useStableFunction";

import { useContactTechSupportDialog } from "components/TechSupportDialog";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LabeledControlGroup } from "components/LabeledControlGroup";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";
import { ProgressIndicator } from "components/ProgressIndicator";

import { OrdersTable } from "./OrdersTable";

import { FindOrderCommand } from "services/FindOrderCommand";
import { FindOrderHistoryCommand } from "services/FindOrderHistoryCommand";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

function Components() {
  // need to have id and name properties for each element in list
  const ORDER_OPTIONS2 = [
    { id: "x500DU00000BigOqYAJ", name: "500DU00000BigOqYAJ" },
    { id: "y500DU00000BigecYAB", name: "500DU00000BigecYAB" }
  ];

  const ORDER_OPTIONS = [
    { id: "0", name: "Option 0" },
    { id: "1", name: "Option 1" },
    { id: "2", name: "Option 2" },
    { id: "3", name: "Option 3" },
    { id: "4", name: "Option 4" }
  ];

  const MULTI_SELECT_OPTIONS = [
    { id: "1", name: "Option 1" },
    { id: "2", name: "Option 2" },
    { id: "3", name: "Option 3" },
    { id: "4", name: "Option 4" },
    { id: "5", name: "Option 5" }
  ];

  const initialFormState = {
    claimNumber: "",
    comments: "",
    computerLanguages: [],
    dateOfInjury: "",
    isActive: "",
    multiSelect: [],
    orderId: "",
    sendEmail: "No",
    showActive: false,
    showCompleted: false,
    showPending: true
  };

  // Have a delay here because if dismissing a modal and show growler the growler flickers
  // because of the refresh caused by the popup and overlay going away
  const onStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  let config = useConfig();
  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting, cancel } = useCommand();
  const { contactTechSupportDialog, showContactTechSupportDialog } = useContactTechSupportDialog();

  const { formData, resetForm, handleChange, handleMagneticChange, setFormData, trimValue } = useForm(initialFormState);
  const {
    addErrorMessage,
    clearErrorMessages,
    getErrorMessage,
    hasErrorMessages,
    hasFieldSpecificErrors,
    setFocusOnFirstError
  } = useErrorMessages();

  const [orderList, setOrderList] = useState([]);
  const [indicatorPosition, setIndicatorPosition] = useState("top");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingProgressIndicator, setIsLoadingProgressIndicator] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [message, setMessage] = useState(null);
  const isSmallScreen = useMediaQuery("(max-width: 768px)"); // is the maximum width 768 pixels, in other words is screen smaller than 768 px

  // repopulate state varaibles, call functions to make service requests
  const onLoadPageState = pageState => {
    console.log("onLoadPageState");
    console.log(pageState);

    //setFormData({ ...formData, ...pageState.formData });
    setFormData(pageState.formData);

    //    setInitialSearchParams({claimNumber: "1234"});
    //    setInitialSearchParams(pageState.formData);

    //updateInitialState(pageState.formData);
  };

  // return the state you want to save / have restored on a page reload
  const onSavePageState = () => {
    let pageState = { formData: formData, message: "this is a message" };
    return pageState;
  };

  const { savePageState, clearPageState } = usePageState("_Home", onLoadPageState, onSavePageState);

  // hook helps to avoid getting caught in dependency hell and infinite loops in useEffect
  // behind the scenes it uses a ref to always have the latest ref to the function
  // by the time this is called the searchParams should be valid
  // will need to only store page state after a search is done since that is when the
  // params are validated
  // could enter values and navigate away without validating them
  // could revalidate them here but not display error messages???
  // prefix a stableFunction with sf?? let them know it is not a normal function?
  const sfPerformSearch = useStableFunction(async searchParams => {
    setIsLoading(true);
    try {
      let command = new FindOrderHistoryCommand(searchParams);
      let result = await execute(command);

      console.log(result);

      if (result.isSuccess) {
        let list = result.value;

        setOrderList(list);

        if (Utils.isObjectEmpty(list)) {
          setMessage("No orders were found.");
          showSuccessGrowler("No orders were found.");
        } else {
          showSuccessGrowler(list.length === 1 ? "Found 1 order." : `Found ${list.length} orders.`);
        }
      } else {
        let error = result.error;
        let errorMessage = null;

        console.error(error);

        if (error.message === "Failed to fetch") {
          errorMessage = "There was an error connecting to the server.";
        } else {
          errorMessage = "There was an error processing your request.";
        }

        setErrorMessage(errorMessage);
        showErrorGrowler(errorMessage);
      }
    } catch (error) {
      console.error(error);
      setMessage(error.message);
    } finally {
      setIsLoading(isExecuting);
    }
  });

  const [initialSearchParams, setInitialSearchParams] = useState(null);

  // I only want to do this when the page first loads
  useEffect(() => {
    // initialSearchParams are set in onLoadPageState
    if (Validator.isNotEmpty(initialSearchParams)) {
      console.log(`useEffect called!!! calling a service with params:`, initialSearchParams);
      sfPerformSearch(initialSearchParams);
    }
  }, [initialSearchParams, sfPerformSearch]);

  const handleClear = () => {
    setOrderList([]);
    clearPageState();
    resetForm();
  };

  const validateForm = () => {
    clearErrorMessages();
    return true;
  };

  const validateForm2 = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.claimNumber)) {
      addErrorMessage("claimNumber", "Enter claim number.");
    }

    if (Validator.isEmpty(formData.orderId)) {
      addErrorMessage("orderId", "Enter order id.");
    }

    if (Validator.isEmpty(formData.multiSelect)) {
      addErrorMessage("multiSelect", "Select items.");
    }

    if (Validator.isEmpty(formData.comments)) {
      addErrorMessage("comments", "Enter comments.");
    }

    if (Validator.isEmpty(formData.dateOfInjury)) {
      addErrorMessage("dateOfInjury", "Enter date of injury.");
    }

    if (Validator.isEmpty(formData.computerLanguages)) {
      addErrorMessage("computerLanguages", "Select languages.");
    }

    if (hasFieldSpecificErrors()) {
      addErrorMessage("global", "Fix errors on page!");
    }

    return !hasFieldSpecificErrors();
  };

  const handleDoSearch = async () => {
    let isFormValid = validateForm();
    if (!isFormValid) {
      setFocusOnFirstError();
      return;
    }

    console.log(formData);

    setIsLoading(isExecuting);

    await sfPerformSearch(formData);
  };

  const handleDoCancelSearch = () => {
    setIsLoading(false);
    cancel();
  };

  return (
    <div className={`${styles.home}`}>
      <BlockMessage style={{ margin: "0 0 1rem .5rem" }}>{getErrorMessage("global")}</BlockMessage>

      <form>
        <PageSection title="Magnetic Components" style={{ marginBottom: "2rem" }}>
        <a href="http://qweb120ntv.staging.int/csg-react-magnetic/?path=/docs/overview--overview" target="_blank" rel="noreferrer">Magnetic Component Documentation</a>

          {message}

          <div style={{ margin: "1rem", position: "relative" }}>            
            <Grid>
              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }} title="TextField">
                    <TextField
                      label="Claim Number"
                      name="claimNumber"
                      required
                      onChange={handleMagneticChange("claimNumber", "text")}
                      value={formData.claimNumber}
                      validationError={getErrorMessage("claimNumber")}
                      onBlur={trimValue}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>TextArea</h4>

                    <TextArea
                      label="Comments"
                      name="comments"
                      required
                      onChange={handleMagneticChange("comments", "text")}
                      value={formData.comments}
                      validationError={getErrorMessage("comments")}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>SingleSelect</h4>
                    {/* returns just the id of the object selected, can type in the field and it does filtering */}
                    <SingleSelect
                      label="Order ID"
                      required
                      name="orderId"
                      value={formData.orderId}
                      options={ORDER_OPTIONS}
                      onChange={handleMagneticChange("orderId", "`-select")}
                      validationError={getErrorMessage("orderId")}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>MultiSelect</h4>

                    <MultiSelect
                      label="Multi-Select"
                      name="multiSelect"
                      required
                      style={{ width: "100%" }}
                      value={formData.multiSelect}
                      options={MULTI_SELECT_OPTIONS}
                      onChange={handleMagneticChange("multiSelect", "multi-select")}
                      validationError={getErrorMessage("multiSelect")}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>DatePicker</h4>

                    <DatePicker
                      label="Date of Injury"
                      data-name="dateOfInjury"
                      style={{ width: "100%" }}
                      required={true}
                      value={formData.dateOfInjury}
                      onChange={handleMagneticChange("dateOfInjury", "text")}
                      validationError={getErrorMessage("dateOfInjury")}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>Checkbox - Individual</h4>

                    <div>
                      <span className="noWrap">Show Orders/Referrals that are:</span>
                      <Checkbox
                        className={styles.minWidthAuto}
                        label="Pending"
                        name="showPending"
                        checked={formData.showPending}
                        onChange={handleMagneticChange("showPending", "checkbox")}
                      />

                      <Checkbox
                        className={styles.minWidthAuto}
                        label="Active"
                        name="showActive"
                        checked={formData.showActive}
                        onChange={handleMagneticChange("showActive", "checkbox")}
                      />

                      <Checkbox
                        className={styles.minWidthAuto}
                        label="Completed"
                        name="showCompleted"
                        checked={formData.showCompleted}
                        onChange={handleMagneticChange("showCompleted", "checkbox")}
                      />
                    </div>
                  </PageSection>
                </Column>
              </Row>

              <Column width="50%">
                <PageSection style={{ width: "100%" }}>
                  <h4>Checkbox - individual in LabeledControlGroup</h4>
                  <LabeledControlGroup
                    label="Show Orders / Referrals That Are"
                    layout="row"
                    required
                    validationError={getErrorMessage("orderStatus")}
                    requiredFulfilled={formData.showPending || formData.showActive || formData.showCompleted}
                  >
                    <Checkbox
                      style={{ marginRight: "2rem" }}
                      className="minWidthAuto"
                      label="Pending"
                      name="showPending"
                      checked={formData.showPending}
                      onChange={handleMagneticChange("showPending", "checkbox")}
                    />

                    <Checkbox
                      style={{ marginRight: "2rem" }}
                      className="minWidthAuto"
                      label="Active"
                      name="showActive"
                      checked={formData.showActive}
                      onChange={handleMagneticChange("showActive", "checkbox")}
                    />

                    <Checkbox
                      style={{ marginRight: "2rem" }}
                      className="minWidthAuto"
                      label="Completed"
                      name="showCompleted"
                      checked={formData.showCompleted}
                      onChange={handleMagneticChange("showCompleted", "checkbox")}
                    />
                  </LabeledControlGroup>
                </PageSection>
              </Column>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>Checkbox - array in LabeledControlGroup</h4>

                    <LabeledControlGroup
                      label="Select languages"
                      layout="row"
                      required
                      validationError={getErrorMessage("computerLanguages")}
                      requiredFulfilled={formData.computerLanguages.length > 0}
                    >
                      <Checkbox
                        style={{ marginRight: "2rem" }}
                        className="minWidthAuto"
                        label="Java"
                        name="computerLanguages"
                        checked={formData.computerLanguages.includes("Java")}
                        onChange={handleMagneticChange("computerLanguages", "checkbox", "Java")}
                      />

                      <Checkbox
                        style={{ marginRight: "2rem" }}
                        className="minWidthAuto"
                        label="JavaScript"
                        name="computerLanguages"
                        checked={formData.computerLanguages.includes("JavaScript")}
                        onChange={handleMagneticChange("computerLanguages", "checkbox", "JavaScript")}
                      />

                      <Checkbox
                        style={{ marginRight: "2rem" }}
                        className="minWidthAuto"
                        label="C++"
                        name="computerLanguages"
                        checked={formData.computerLanguages.includes("C++")}
                        onChange={handleMagneticChange("computerLanguages", "checkbox", "C++")}
                      />
                    </LabeledControlGroup>
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>RadioButton in LabeledControlGroup</h4>

                    <LabeledControlGroup
                      label="Is Client Active"
                      layout="row"
                      required
                      validationError={getErrorMessage("isActive")}
                      requiredFulfilled={Validator.isNotEmpty(formData.isActive)}
                    >
                      {/* the RadioButton just sends a boolean, we'll send a custom value onChange={handleMagneticChange("isActive", "radio", "No")} */}
                      <RadioButton
                        name="isActive"
                        label="Yes"
                        value="Yes"
                        style={{ marginRight: "2rem" }}
                        checked={formData.isActive === "Yes"}
                        onChange={handleMagneticChange("isActive", "radio", "Yes")}
                      />

                      <RadioButton
                        name="isActive"
                        label="No"
                        value="No"
                        style={{ marginRight: "2rem" }}
                        checked={formData.isActive === "No"}
                        onChange={handleMagneticChange("isActive", "radio", "No")}
                      />
                    </LabeledControlGroup>
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>RadioButton in RadioButtonGroup</h4>

                    <RadioButtonGroup legend="Is client active?" required onChange={handleChange}>
                      {/* the RadioButton just sends a boolean, we'll send a custom value onChange={handleMagneticChange("isActive", "radio", "No")} */}
                      {/* If the RadioButton is in a RadioButtonGroup then the RadioButtonGroup fires a normal RadioButton event */}
                      <RadioButton name="isActive" label="Yes" value="Yes" checked={formData.isActive === "Yes"} onChange={e => {}} />

                      <RadioButton name="isActive" label="No" value="No" checked={formData.isActive === "No"} onChange={e => {}} />
                    </RadioButtonGroup>
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>RadioButton (not in a RadioButtonGroup)</h4>
                    <p>sendEmail</p>

                    {/* the RadioButton just sends a boolean, we'll send a custom value onChange={handleMagneticChange("isActive", "radio", "No")} */}
                    {/* to get normal event to fire RadioButton needs to be in a RadioButtonGroup*/}
                    <RadioButton
                      name="sendEmail"
                      label="Yes"
                      value="Yes"
                      checked={formData.sendEmail === "Yes"}
                      onChange={handleMagneticChange("sendEmail", "radio", "Yes")}
                    />

                    <RadioButton
                      name="sendEmail"
                      label="No"
                      value="No"
                      checked={formData.sendEmail === "No"}
                      onChange={handleMagneticChange("sendEmail", "radio", "No")}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>Modal Dialog</h4>

                    <Button
                      variant="primary"
                      type="button"
                      onClick={() => {
                        showContactTechSupportDialog(onStatusUpdate);
                      }}
                    >
                      <span className="noWrap">Show Modal</span>
                    </Button>
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>LoadingIndicator</h4>
                    <LoadingIndicator isLoading={isLoading} renderDelay={0}>
                      <p>Content renders when isLoading is false</p>
                      <p>
                        NOTE: Objects are still evaluated event though it isn't visible so things like {`{user.firstName}`} will error out
                        with a null value if user isn't yet populated. You have to account for that.
                      </p>
                    </LoadingIndicator>
                    <Button
                      variant="primary"
                      type="button"
                      onClick={() => {
                        setIsLoading(true);
                      }}
                      loading={isLoading}
                      style={{ marginRight: "1rem" }}
                    >
                      <span className="noWrap">Show Loading</span>
                    </Button>

                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        setIsLoading(false);
                      }}
                    >
                      <span className="noWrap">Stop Loading</span>
                    </Button>
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%">
                  <PageSection style={{ width: "100%" }}>
                    <h4>Indefinite Progress Indicator</h4>

                    <ProgressIndicator position={indicatorPosition} isLoading={isLoadingProgressIndicator} />

                    <Button
                      variant="primary"
                      type="button"
                      onClick={() => {
                        setIsLoadingProgressIndicator(true);
                      }}
                      loading={isLoadingProgressIndicator}
                      style={{ marginRight: "1rem" }}
                    >
                      <span className="noWrap">Show Indicator</span>
                    </Button>

                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        setIsLoadingProgressIndicator(false);
                      }}
                    >
                      <span className="noWrap">Stop Indicator</span>
                    </Button>

                    <Checkbox
                      className={styles.minWidthAuto}
                      label="top"
                      checked={indicatorPosition === "top"}
                      onChange={v => {
                        setIndicatorPosition(v ? "top" : "bottom");
                      }}
                    />

                    <RadioButton
                      label="Top"
                      checked={indicatorPosition === "top"}
                      onChange={() => {
                        setIndicatorPosition("top");
                      }}
                    />

                    <RadioButton
                      label="Bottom"
                      checked={indicatorPosition === "bottom"}
                      onChange={() => {
                        setIndicatorPosition("bottom");
                      }}
                    />
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="100%">
                  <PageSection style={{ width: "100%" }}>
                    <ProgressIndicator position="bottom" isLoading={isExecuting} />
                    <h4>Data Grid (use buttons below - grid has links to detail page)</h4>
                    <LoadingIndicator isLoading={isExecuting} renderDelay={0}>
                      <OrdersTable
                        orderList={orderList}
                        onOrderSelected={list => {
                          console.log(list);
                        }}
                      />
                    </LoadingIndicator>
                  </PageSection>
                </Column>
              </Row>

              <Row>
                <Column width="50%" align="right">
                  <PageSection style={{ width: "100%" }}>
                    <h4>Button</h4>
                    <Button variant="primary" type="button" onClick={handleDoSearch} loading={isExecuting} style={{ marginRight: "1rem" }}>
                      <span className="noWrap">Search</span>
                    </Button>

                    <Button variant="outline" type="button" onClick={handleDoCancelSearch} style={{ marginRight: "1rem" }}>
                      <span className="noWrap">Cancel</span>
                    </Button>

                    <Button variant="outline" type="button" onClick={handleClear}>
                      <span className="noWrap">Clear</span>
                    </Button>
                  </PageSection>
                </Column>
              </Row>
            </Grid>
          </div>
        </PageSection>

        <PageSection title="Hooks">
          <Grid>
            <Row>
              <Column width="75%">
                <PageSection style={{ width: "100%" }}>
                  <h4>useConfig</h4>
                  <p>config.json in public/dist/config</p>
                  <p>
                    <code>
                      let config = useConfig(); // in React component: config.propertyName
                      <br />
                      let config = Config.getInstance(); // in JavaScript class: config.propertyName
                    </code>
                  </p>
                  <p>config.serviceUrl = {config.serviceUrl}</p>
                  <p>config.portalApplctnCd = {config.portalApplctnCd}</p>
                </PageSection>
              </Column>
            </Row>

            <Row>
              <Column width="75%">
                <PageSection style={{ width: "100%" }}>
                  <h4>useMediaQuery</h4>
                  <p>
                    <code>const isSmallScreen = useMediaQuery("(max-width: 768px)");</code>
                  </p>
                  <p>{isSmallScreen ? "Small Screen" : "Large Screen"}</p>
                </PageSection>
              </Column>
            </Row>

            <Row>
              <Column width="75%">
                <PageSection style={{ width: "100%" }}>
                  <h4>useGrowler</h4>
                  <pre>
                    <code>
                      {`
const { showSuccessGrowler, showErrorGrowler } = useGrowler();

showSuccessGrowler("Success message");

showErrorGrowler("Error message");
                    `}
                    </code>
                  </pre>
                  <Button
                    variant="primary"
                    type="button"
                    onClick={() => showSuccessGrowler("This is a success message!")}
                    style={{ marginRight: "1rem" }}
                  >
                    <span className="noWrap">Success Message</span>
                  </Button>

                  <Button variant="primary" type="button" onClick={() => showErrorGrowler("This is an error message!")}>
                    <span className="noWrap">Error Message</span>
                  </Button>
                </PageSection>
              </Column>
            </Row>

            <Row>
              <Column width="75%">
                <PageSection style={{ width: "100%" }}>
                  <h4>usePageState</h4>
                  <pre>
                    <code>
                      {`
// Called when component is created - page refreshed or navigated to
// Hook calls it passing in the state returned from onSavePageState
const onLoadPageState = (pageState) => {
    setFormData(pageState.formData);
};

// Hook calls this when it is time to save the page state
// return the state you want to save / have restored on a page reload
const onSavePageState = () => {
    let pageState = { formData: formData, message: "this is a message" };
    return pageState;
};

const { savePageState, clearPageState } = usePageState("_Home", onLoadPageState, onSavePageState);

// save just some form fields on demand
const { savePageState, clearPageState } = usePageState("_Home", onLoadPageState, null);
let pageState = { formData: {claimNumber: formData.claimNumber} };
savePageState(pageState);

// load just those fields in and merge them with the initial form data when the page loads
const onLoadPageState = pageState => {
  setFormData({...formData, ...pageState.formData});
};

                    `}
                    </code>
                  </pre>
                </PageSection>
              </Column>
            </Row>

            <Row>
              <Column width="75%">
                <PageSection style={{ width: "100%" }}>
                  <h4>useStableFunction</h4>
                  <p>
                    A custom React hook that returns a stable function reference, ensuring it always calls the latest version of the
                    provided function. Useful for preventing stale closures in event handlers, effects, or callbacks. You can use the
                    function in useEffect and list it in the dependencies without getting into an infinite loop or dependency hell.
                  </p>

                  <pre>
                    <code>
                      {`

  import { useStableFunction } from "hooks/useStableFunction";

  const sfPerformSearch = useStableFunction(async (searchParams) => {
    setIsLoading(true);
    try {
      let command = new FindOrderHistoryCommand(searchParams);
      let result = await execute(command);

      if (Utils.isObjectEmpty(result)) {
        setMessage("No results found.");
      } else {
        setOrderList(result);
        showSuccessGrowler("Found orders.");
      }
    } catch (error) {
      setMessage(error.message);
    } finally {
      setIsLoading(isExecuting);
    }
  });

  useEffect(() => {
    if (Validator.isNotEmpty(initialSearchParams)) {
      sfPerformSearch(initialSearchParams);
    }
  }, [initialSearchParams, sfPerformSearch]);
                    `}
                    </code>
                  </pre>
                </PageSection>
              </Column>
            </Row>
          </Grid>

          <Grid>
            <Row>
              <Column width="25%">
                <p>25%</p>
              </Column>
              <Column width="25%">
                <p>25%</p>
              </Column>
              <Column width="50%">
                <Row collapse={false}>
                  <Column width="50%">
                    <p>50%</p>
                  </Column>

                  <Column width="50%">
                    <p>50%</p>
                  </Column>
                </Row>
              </Column>
            </Row>

            <Row>
              <Column width="25%">
                <p>25%</p>
              </Column>
              <Column width="25%">
                <p>25%</p>
              </Column>
              <Column width="25%">
                <p>25%</p>
              </Column>
              <Column width="25%">
                <p>25%</p>
              </Column>
            </Row>
          </Grid>
        </PageSection>
      </form>

      {contactTechSupportDialog}
    </div>
  );
}

export { Components };
