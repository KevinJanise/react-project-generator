import styles from "./ClientSearchResults.module.css";

import { useHistory } from "react-router-dom";

import { BlockMessage } from "components/BlockMessage";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { ClientTable } from "./ClientTable";

function ClientSearchResults({ clientList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasResults = clientList && clientList.length > 0;
  const history = useHistory();

  const handleEdit = clientId => {
    history.push(`/networkProductGroups/${clientId}`);
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection className={styles.clientSearchResults}>
        {hasResults && <ClientTable clientList={clientList} onEdit={handleEdit} />}

        <BlockMessage variant="info">{resultMessage}</BlockMessage>
        <BlockMessage variant="error">{errorMessage}</BlockMessage>
      </PageSection>
    </LoadingIndicator>
  );
}

export { ClientSearchResults };
