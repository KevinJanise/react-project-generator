import React from "react";
import styles from "./BlockMessage.module.css";
import { Block } from "csg-react-magnetic/block";

const BlockMessage = ({ heading, variant = "danger", onClose, children, className = "", style = {}, ...rest }) => {

  // If there are no children at all, return null immediately
  if (!children) {
    return null;
  }

  const combinedClassName = [styles.blockMessage, className].filter(Boolean).join(" ");

  const childrenArray = React.Children.toArray(children);

  // Helper function to check if a child is empty
  const isChildEmpty = (child) => {
    if (!child) return true;
    if (typeof child === 'string') return child.trim() === '';
    if (Array.isArray(child)) return child.length === 0;
    if (React.isValidElement(child)) {
      // Check if it's an empty span or p tag
      if (child.type === 'span' || child.type === 'p') {
        const childContent = child.props.children;
        return !childContent || 
               (typeof childContent === 'string' && childContent.trim() === '') ||
               (Array.isArray(childContent) && childContent.every(isChildEmpty));
      }
    }
    return false;
  };

  // Filter out empty children
  const nonEmptyChildren = childrenArray.filter(child => !isChildEmpty(child));

  // If there are no non-empty children, return null
  if (nonEmptyChildren.length === 0) {
    return null;
  }

  // Render single error message without ul/li
  if (nonEmptyChildren.length === 1) {
    return (
      <Block 
        heading={heading} 
        variant={variant === "error" ? "danger" : variant} 
        style={{...style }} 
        className={combinedClassName}
        closeButton={typeof onClose === 'function'}
        onClose={onClose}
        {...rest}
      >
        {nonEmptyChildren[0]}
      </Block>
    );
  }

  // Render multiple error messages with ul/li
  return (
    <Block 
      heading={heading} 
      variant={variant === "error" ? "danger" : variant} 
      style={{ margin: ".5rem", ...style }} 
      className={combinedClassName} 
      closeButton={typeof onClose === 'function'}
      onClose={onClose}
      {...rest}
    >
      <ul style={{ listStyleType: "square", marginLeft: "1.25rem" }}>
        {nonEmptyChildren.map((child, index) => (
          <li key={index}>{child}</li>
        ))}
      </ul>
    </Block>
  );
};

export { BlockMessage };
