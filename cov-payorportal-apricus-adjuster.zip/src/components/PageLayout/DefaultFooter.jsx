import styles from "./DefaultFooter.module.css";

import { CorporateLogo } from "csg-react-magnetic/corporate-logo";

const DefaultFooter = () => (
  <footer className={styles.footer}>
    <div style={{ display: "flex", alignItems: "center" }}>
      <a href="https://www.enlyte.com/" className={styles.logoLink} target="_blank" rel="noreferrer">
        <CorporateLogo size="XS" variant="enlyte" />
      </a>

      <a className={`${styles.link} underlineFromCenter`} href="https://www.enlyte.com/terms-use" target="_blank" rel="noreferrer">
        Terms & Conditions
      </a>
      <a className={`${styles.link} underlineFromCenter`} href="https://www.enlyte.com/privacy-policy" target="_blank" rel="noreferrer">
        Privacy Policy
      </a>
    </div>

    <span className={styles.copyright}>&copy; {new Date().getFullYear()} Enlyte Group, LLC.</span>
  </footer>
);

export { DefaultFooter };
