import { createContext } from "react";

const GridContext = createContext({ collapse: true });
GridContext.displayName = "GridContext";

export { GridContext };
