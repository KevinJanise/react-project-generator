export { default as JitUxPortalCard } from "./JitUxPortalCard";
