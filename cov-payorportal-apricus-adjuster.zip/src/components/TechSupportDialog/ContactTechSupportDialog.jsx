import styles from "./ContactTechSupportDialog.module.css";

import { Button } from "csg-react-magnetic/button";
import { Modal } from "csg-react-magnetic/modal";
import { TextArea } from "csg-react-magnetic/text-area";

import { ButtonBar } from "components/ButtonBar";
import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { ProgressIndicator } from "components/ProgressIndicator";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import { SendEmailCommand } from "services/SendEmailCommand";

import * as Validator from "utils/Validator";

const ContactTechSupportDialog = ({ onStatusUpdate, hideModal }) => {
  const { execute, isExecuting, cancel } = useCommand();

  let initialFormState = { message: undefined };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.message)) {
      addErrorMessage("message", "Please enter a message.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleSend = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    let command = new SendEmailCommand(formData.message);
    let result = await execute(command);

    if (result.isSuccess) {
      console.log(result);
      hideModal();
      onStatusUpdate({ isSuccess: true, message: `Sent message.` });
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", `There was a problem contacting Tech Support`);
      }
    }
  };

  const handleCancel = () => {
    cancel();
    hideModal();
    onStatusUpdate({ isSuccess: false, message: "Canceled contact Tech Support!" });
  };

  return (
    <Modal
      title="Contact Tech Support"
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button onClick={handleSend} loading={isExecuting}>
            OK
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <BlockMessage variant="error" className={styles.blockMessage}>
          {getErrorMessage("global")}
        </BlockMessage>

        <Grid>
          <Row>
            <Column width="100%">
              <TextArea
                label="message"
                required
                value={formData.message}
                maxLength={1000}
                charRemaining="remaining"
                onChange={handleMagneticChange("message", "text")}
                validationError={getErrorMessage("message")}
                style={{
                  width: "100%",
                  height: "10rem",
                  marginBottom: "3rem"
                }}
              />
            </Column>
          </Row>
        </Grid>

        <ProgressIndicator isLoading={isExecuting} position="bottom" />
      </div>
    </Modal>
  );
};

export { ContactTechSupportDialog };
