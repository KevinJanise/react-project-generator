import { useModal } from "csg-react-magnetic/modal";
import { ContactTechSupportDialog } from "../ContactTechSupportDialog";

const useContactTechSupportDialog = () => {
  const [contactTechSupportDialog, showModal, hideModal] = useModal();

  // Delay because if you instantly show a Growler it will flicker when the
  // popup and overlay are dismissed.
  const createHandleStatusUpdate = onStatusUpdate => {
    // Returns a function that takes a 'message' parameter
    return function (message) {
      setTimeout(() => {
        onStatusUpdate(message);
      }, 250);
    };
  };

  const showContactTechSupportDialog = onStatusUpdate => {
    showModal(<ContactTechSupportDialog onStatusUpdate={createHandleStatusUpdate(onStatusUpdate)} hideModal={hideModal} />);
  };

  return { contactTechSupportDialog, showContactTechSupportDialog };
};

export { useContactTechSupportDialog };
