import styles from "./ToolbarButton.module.css";

import { Button } from "csg-react-magnetic/button";

// Available Icons: http://uxdesign.enlyte.com/magnetic-design-system/?path=/docs/components-icon-all-icons--story-docs
function ToolbarButton({ icon = "access-denied", title = "", className = "", style = {}, onClick, ...rest }) {
  return (
    <Button icon={icon} variant="flat" type="button" compact={true} title={title} className={styles.toolbarButton} onClick={onClick} {...rest} />
  );
}

export { ToolbarButton };
