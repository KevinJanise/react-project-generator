import { useModal } from "csg-react-magnetic/modal";
import { EditNoteDialog } from "../EditNoteDialog";

function useEditNoteDialog() {
  const [editNoteDialog, showModal, hideModal] = useModal();

  // Delay because if you instantly show a Growler it will flicker when the
  // popup and overlay are dismissed.
  const showEditNoteDialog = (note, user, noteId, onStatusUpdate) => {
    const handleStatusUpdate = message => {
          setTimeout(() => {
            onStatusUpdate(message);
          }, 250);
        };
      
    console.log(`showEditNoteDialog ${note}`);
    showModal(<EditNoteDialog note={note} user={user} noteId={noteId} onStatusUpdate={handleStatusUpdate} hideModal={hideModal} />);
  };

  return { editNoteDialog, showEditNoteDialog };
}

export { useEditNoteDialog };
