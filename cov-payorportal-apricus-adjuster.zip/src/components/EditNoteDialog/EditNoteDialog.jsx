import styles from "./EditNoteDialog.module.css";

import { Button } from "csg-react-magnetic/button";
import { Modal } from "csg-react-magnetic/modal";
import { TextArea } from "csg-react-magnetic/text-area";

import { Grid, Row, Column } from "components/Grid";
import { ProgressIndicator } from "components/ProgressIndicator";
import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import { SaveNoteCommand } from "services/SaveNoteCommand";

import * as Validator from "utils/Validator";

const EditNoteDialog = ({ note, onStatusUpdate, hideModal }) => {
  const { execute, isExecuting } = useCommand();

  let initialFormState = { note: note };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.note)) {
      addErrorMessage("note", "Please enter a note.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleSaveNote = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    let command = new SaveNoteCommand(formData.note);
    let result = await execute(command);

    if (result.isSuccess) {
      console.log(result);
      hideModal();
      onStatusUpdate({ isSuccess: true, message: "Saved note." });
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", `There was a problem saving the note.`);
      }
    }
  };

  const handleCancel = () => {
    hideModal();
    onStatusUpdate({ isSuccess: true, message: "Canceled save note!" });
  };

  return (
    <Modal
      title="Edit Note"
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button onClick={handleSaveNote} loading={isExecuting}>
            OK
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <BlockMessage variant="error">{getErrorMessage("global")}</BlockMessage>

        <Grid>
          <Row>
            <Column width="100%">
              <TextArea
                label="Comments"
                required
                value={formData.note}
                maxLength={1000}
                charRemaining="remaining"
                onChange={handleMagneticChange("note", "text")}
                validationError={getErrorMessage("note")}
                style={{
                  width: "100%",
                  height: "10rem",
                  marginBottom: "2.75rem"
                }}
              />
            </Column>
          </Row>
        </Grid>

        <ProgressIndicator isLoading={isExecuting} position="bottom" />
      </div>
    </Modal>
  );
};

export { EditNoteDialog };
