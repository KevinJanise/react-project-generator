import styles from "./OrderDialogs.module.css";

import { useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { Modal } from "csg-react-magnetic/modal";
import { TextArea } from "csg-react-magnetic/text-area";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { ProgressIndicator } from "components/ProgressIndicator";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import { ApproveOrdersCommand } from "services/ApproveOrdersCommand";

import * as Validator from "utils/Validator";

const ApproveOrdersDialog = ({ orderList, onStatusUpdate, hideModal }) => {
  const isBulk = orderList.length > 1;
  const [isApproveEnabled, setIsApproveEnabled] = useState(!isBulk);
  const title = isBulk ? `Bulk Approve ${orderList.length} Orders` : `Approve Order ${orderList[0].orderNum}`;

  const { execute, isExecuting } = useCommand();

  let initialFormState = { comments: undefined };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.comments)) {
      addErrorMessage("comments", "Please enter a comment.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleApproveOrders = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    let command = new ApproveOrdersCommand(orderList, formData.comments);
    let result = await execute(command);

    result.isSuccess = false;
    result.isError = true;
    result.error = {};
    result.error.message = "Failed to fetch";

    if (result.isSuccess) {
      hideModal();

      console.log(result);
      onStatusUpdate({ isSuccess: true, message: `Approved orders.` });
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", "There was a problem approving orders.");
      }
    }
  };

  const handleCancel = () => {
    hideModal();
    onStatusUpdate({ isSuccess: true, message: "Canceled approve orders!" });
  };

  return (
    <Modal
      title={title}
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button disabled={!isApproveEnabled} onClick={handleApproveOrders} loading={isExecuting}>
            Approve
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <BlockMessage variant="error" className={styles.blockMessage}>
          {getErrorMessage("global")}
        </BlockMessage>

        <Grid>
          <Row>
            <Column width="100%">
              <TextArea
                label="Comments"
                value={formData.comments}
                maxLength={1000}
                charRemaining="remaining"
                onChange={handleMagneticChange("comments", "text")}
                validationError={getErrorMessage("comments")}
                style={{
                  width: "100%",
                  height: "10rem",
                  marginBottom: "2.5rem"
                }}
              />
            </Column>
          </Row>

          <Row>
            <Column width="100%">
              {isBulk && (
                <div className={styles.bulkMessage}>
                  <Checkbox
                    required
                    requiredFulfilled={isApproveEnabled}
                    checked={isApproveEnabled}
                    onChange={setIsApproveEnabled}
                    label={`Yes, I'm sure I want to bulk approve ${orderList.length} orders.`}
                  />
                </div>
              )}
            </Column>
          </Row>
        </Grid>

        <ProgressIndicator isLoading={isExecuting} position="bottom" />
      </div>
    </Modal>
  );
};

export { ApproveOrdersDialog };
