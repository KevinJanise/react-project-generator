import { useModal } from "csg-react-magnetic/modal";
import { DenyOrdersDialog } from "../DenyOrdersDialog";

const useDenyOrdersDialog = () => {
  const [denyOrdersDialog, showModal, hideModal] = useModal();

  const showDenyOrdersDialog = (orderList, onStatusUpdate) => {
    // Delay because if you instantly show a Growler it will flicker when the popup and overlay are dismissed.
    const handleStatusUpdate = message =>
      setTimeout(() => {
        onStatusUpdate(message);
      }, 250);

    showModal(<DenyOrdersDialog orderList={orderList} onStatusUpdate={handleStatusUpdate} hideModal={hideModal} />);
  };

  return { denyOrdersDialog, showDenyOrdersDialog };
};

export { useDenyOrdersDialog };
