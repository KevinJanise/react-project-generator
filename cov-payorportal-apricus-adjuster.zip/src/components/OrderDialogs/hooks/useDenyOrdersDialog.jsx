import { useModal } from "csg-react-magnetic/modal";
import { DenyOrdersDialog } from "../DenyOrdersDialog";

const useDenyOrdersDialog = () => {
  const [denyOrdersDialog, showModal, hideModal] = useModal();

  const showDenyOrdersDialog = (orderList, onStatusUpdate) => {
    showModal(<DenyOrdersDialog orderList={orderList} onStatusUpdate={onStatusUpdate} hideModal={hideModal} />);
  };

  return { denyOrdersDialog, showDenyOrdersDialog };
};

export { useDenyOrdersDialog };
