import { useModal } from "csg-react-magnetic/modal";
import { ApproveOrdersDialog } from "../ApproveOrdersDialog";

const useApproveOrdersDialog = () => {
  const [approveOrdersDialog, showModal, hideModal] = useModal();

  const showApproveOrdersDialog = (orderList, onStatusUpdate) => {
    showModal(<ApproveOrdersDialog orderList={orderList} onStatusUpdate={onStatusUpdate} hideModal={hideModal} />);
  };

  /*
  const handleStatusUpdate = message => {
    setTimeout(() => {
      onStatusUpdate(message);
    }, 250);

  showModal(<ApproveOrdersDialog orderList={orderList} onStatusUpdate={handleStatusUpdate} hideModal={hideModal} />);
};
*/
return { approveOrdersDialog, showApproveOrdersDialog };
};

export { useApproveOrdersDialog };
