import { useModal } from "csg-react-magnetic/modal";
import { TransferOrdersDialog } from "../TransferOrdersDialog";

const useTransferOrdersDialog = () => {
  const [transferOrdersDialog, showModal, hideModal] = useModal();

  const showTransferOrdersDialog = (orderList, onStatusUpdate) => {
    // Delay because if you instantly show a Growler it will flicker when the popup and overlay are dismissed.
    showModal(<TransferOrdersDialog orderList={orderList} onStatusUpdate={onStatusUpdate} hideModal={hideModal} />);
  };

  /*
  const showTransferOrdersDialog = (orderList, onStatusUpdate) => {
    // Delay because if you instantly show a Growler it will flicker when the popup and overlay are dismissed.
    const handleStatusUpdate = message =>
      setTimeout(() => {
        onStatusUpdate(message);
      }, 250);

    showModal(<TransferOrdersDialog orderList={orderList} onStatusUpdate={handleStatusUpdate} hideModal={hideModal} />);
  };
*/

  return { transferOrdersDialog, showTransferOrdersDialog };
};

export { useTransferOrdersDialog };
