import { useModal } from "csg-react-magnetic/modal";
import { TransferOrdersDialog } from "../TransferOrdersDialog";

const useTransferOrdersDialog = () => {
  const [transferOrdersDialog, showModal, hideModal] = useModal();

  const showTransferOrdersDialog = (orderList, onStatusUpdate) => {
    showModal(<TransferOrdersDialog orderList={orderList} onStatusUpdate={onStatusUpdate} hideModal={hideModal} />);
  };

  return { transferOrdersDialog, showTransferOrdersDialog };
};

export { useTransferOrdersDialog };
