import styles from "./OrderDialogs.module.css";

import { useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { Modal } from "csg-react-magnetic/modal";
import { SingleSelect } from "csg-react-magnetic/single-select";
import { TextArea } from "csg-react-magnetic/text-area";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { ProgressIndicator } from "components/ProgressIndicator";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import { TransferOrdersCommand } from "services/TransferOrdersCommand";

import * as Validator from "utils/Validator";

const ASSIGN_TO_OPTIONS = [
  { id: "0", name: "John Doe" },
  { id: "1", name: "Jane Doe" },
  { id: "2", name: "Gatsby Dogg" },
  { id: "3", name: "Marvin Martian" },
  { id: "4", name: "Indiana Jones" },
  { id: "5", name: "Iron Man" },
  { id: "6", name: "Benjamin Gates" }
];

const TransferOrdersDialog = ({ orderList, onStatusUpdate, hideModal }) => {
  const isBulk = Boolean(orderList?.length > 1);

  const [isTransferEnabled, setIsTransferEnabled] = useState(!isBulk);
  const title = isBulk ? `Bulk Transfer ${orderList.length} Orders` : `Transfer Order ${orderList[0].orderNum}`;

  const { execute, isExecuting } = useCommand();

  let initialFormState = { transferTo: null, comments: undefined };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.transferTo)) {
      addErrorMessage("transferTo", "Please select assign to.");
    }

    if (Validator.isEmpty(formData.comments)) {
      addErrorMessage("comments", "Please enter a comment.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleTransferOrders = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    let command = new TransferOrdersCommand(orderList, formData.transferTo, formData.comments);
    let result = await execute(command);
/*
    result.isSuccess = false;
    result.isError = true;
    result.error = {};
    result.error.message = "Failed to fetch";
*/
    if (result.isSuccess) {
      hideModal();

      console.log(result);
      onStatusUpdate({ isSuccess: true, message: `Transfered orders to ${formData.transferTo}!` });
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", "There was a problem transferring orders.");
      }
    }
  };

  const handleCancel = () => {
    hideModal();
    onStatusUpdate({ isSuccess: true, message: "Canceled transfer orders!" });
  };

  return (
    <Modal
      title={title}
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button disabled={!isTransferEnabled} onClick={handleTransferOrders} loading={isExecuting}>
            Transfer
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <BlockMessage variant="error" className={styles.blockMessage}>
          {getErrorMessage("global")}
        </BlockMessage>

        <Grid>
          <Row>
            <Column width="100%">
              <SingleSelect
                label="Assign To"
                placeholder="Select One..."
                required
                style={{ width: "25rem" }}
                value={formData.transferTo}
                options={ASSIGN_TO_OPTIONS}
                onChange={handleMagneticChange("transferTo", "single-select")}
                validationError={getErrorMessage("transferTo")}
              />
            </Column>
          </Row>

          <Row>
            <Column width="100%">
              <TextArea
                label="Comments"
                value={formData.comments}
                maxLength={1000}
                charRemaining="remaining"
                onChange={handleMagneticChange("comments", "text")}
                validationError={getErrorMessage("comments")}
                style={{
                  width: "100%",
                  height: "10rem",
                  marginBottom: "2.5rem"
                }}
              />
            </Column>
          </Row>

          <Row>
            <Column width="100%">
              {isBulk && (
                <div className={styles.bulkMessage}>
                  <Checkbox
                    required
                    requiredFulfilled={isTransferEnabled}
                    checked={isTransferEnabled}
                    onChange={setIsTransferEnabled}
                    label={`Yes, I'm sure I want to bulk transfer ${orderList.length} orders.`}
                  />
                </div>
              )}
            </Column>
          </Row>
        </Grid>

        <ProgressIndicator isLoading={isExecuting} position="bottom" />
      </div>
    </Modal>
  );
};

export { TransferOrdersDialog };
