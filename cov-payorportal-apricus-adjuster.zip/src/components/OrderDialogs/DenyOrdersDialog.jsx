import styles from "./OrderDialogs.module.css";

import { useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { Modal } from "csg-react-magnetic/modal";
import { TextArea } from "csg-react-magnetic/text-area";

import { BlockMessage } from "components/BlockMessage";
import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";
import { ProgressIndicator } from "components/ProgressIndicator";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import { DenyOrdersCommand } from "services/DenyOrdersCommand";

import * as Validator from "utils/Validator";

const DenyOrdersDialog = ({ orderList, onStatusUpdate, hideModal }) => {
  const isBulk = Boolean(orderList?.length > 1);

  const [isDenyEnabled, setIsDenyEnabled] = useState(!isBulk);
  const title = isBulk ? `Bulk Deny ${orderList.length} Orders` : `Deny Order ${orderList[0].orderNum}`;

  const { execute, isExecuting } = useCommand();

  let initialFormState = { comments: undefined };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.comments)) {
      addErrorMessage("comments", "Please enter a comment.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleDenyOrders = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    let command = new DenyOrdersCommand(orderList, formData.comments);
    let result = await execute(command);

    /*
    result.isSuccess = false;
    result.isError = true;
    result.error = {};
    result.error.message = "Failed to fetch";
*/

    if (result.isSuccess) {
      hideModal();

      console.log(result);
      onStatusUpdate({ isSuccess: true, message: `Denied orders.` });
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", "There was a problem denying orders.");
      }
    }
  };

  const handleCancel = () => {
    hideModal();
    onStatusUpdate({ isSuccess: true, message: "Canceled Deny orders!" });
  };

  return (
    <Modal
      title={title}
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button disabled={!isDenyEnabled} onClick={handleDenyOrders} loading={isExecuting}>
            Deny
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <BlockMessage variant="error" className={styles.blockMessage}>
          {getErrorMessage("global")}
        </BlockMessage>

        <Grid>
          <Row>
            <Column width="100%">
              <TextArea
                label="Comments"
                value={formData.comments}
                maxLength={1000}
                charRemaining="remaining"
                onChange={handleMagneticChange("comments", "text")}
                validationError={getErrorMessage("comments")}
                style={{
                  width: "100%",
                  height: "10rem",
                  marginBottom: "2.5rem"
                }}
              />
            </Column>
          </Row>

          <Row>
            <Column width="100%">
              {isBulk && (
                <div className={styles.bulkMessage}>
                  <Checkbox
                    required
                    requiredFulfilled={isDenyEnabled}
                    checked={isDenyEnabled}
                    onChange={setIsDenyEnabled}
                    label={`Yes, I'm sure I want to bulk deny ${orderList.length} orders.`}
                  />
                </div>
              )}
            </Column>
          </Row>
        </Grid>

        <ProgressIndicator isLoading={isExecuting} position="bottom" />
      </div>
    </Modal>
  );
};

export { DenyOrdersDialog };
