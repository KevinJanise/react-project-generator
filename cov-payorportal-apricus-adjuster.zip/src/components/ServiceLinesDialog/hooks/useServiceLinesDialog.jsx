import { useModal } from "csg-react-magnetic/modal";
import { ServiceLinesDialog } from "../ServiceLinesDialog";

const useServiceLinesDialog = () => {
  const [serviceLinesDialog, showModal, hideModal] = useModal();

  const showServiceLinesDialog = (orderNumber, serviceLines) => {
    showModal(<ServiceLinesDialog orderNumber={orderNumber} serviceLines={serviceLines} hideModal={hideModal} />);
  };

  return { serviceLinesDialog, showServiceLinesDialog };
};

export { useServiceLinesDialog };
