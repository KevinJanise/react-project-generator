import styles from "./ServiceLinesDialog.module.css";

import { Button } from "csg-react-magnetic/button";
import { Modal } from "csg-react-magnetic/modal";

import { ButtonBar } from "components/ButtonBar";
import { Grid, Row, Column } from "components/Grid";

const ServiceLinesDialog = ({ orderNumber, serviceLines, hideModal }) => {
  const handleOk = () => {
    hideModal();
  };

  return (
    <Modal
      title={`Service Lines for ${orderNumber}`}
      onClose={handleOk}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button onClick={handleOk}>OK</Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <Grid>
          <Row>
            <Column width="100%">
              <ul className={styles.serviceLinesList}>
                {serviceLines?.map((item, index) => (
                  <li key={index} className={styles.serviceItem}>
                    {item}
                  </li>
                ))}
              </ul>
            </Column>
          </Row>
        </Grid>
      </div>
    </Modal>
  );
};

export { ServiceLinesDialog };
