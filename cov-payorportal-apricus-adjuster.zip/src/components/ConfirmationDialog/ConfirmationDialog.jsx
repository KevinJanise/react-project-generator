import styles from "./ConfirmationDialog.module.css";

import { Button } from "csg-react-magnetic/button";
import { Modal } from "csg-react-magnetic/modal";

import { ButtonBar } from "components/ButtonBar";

const ConfirmationDialog = ({ title = "Confirmation", yesLabel = "OK", noLabel = "Cancel", onYes, onNo, hideModal, message }) => {
  const handleNo = () => {
    hideModal();
    onNo();
  };

  const handleYes = () => {
    hideModal();
    onYes();
  };

  return (
    <Modal
      title={title}
      onClose={handleNo}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button onClick={handleYes}>{yesLabel}</Button>

          <Button variant="outline" onClick={handleNo}>
            {noLabel}
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>{message}</div>
    </Modal>
  );
};

export { ConfirmationDialog };
