import { useModal } from "csg-react-magnetic/modal";

import { ConfirmationDialog } from "../ConfirmationDialog";

function useConfirmationDialog() {
  const [confirmationDialog, showModal, hideModal] = useModal();
  
  const showConfirmationDialog = ({ title, yesLabel, noLabel, onYes, onNo, message }) => {
    showModal(
      <ConfirmationDialog
        title={title}
        yesLabel={yesLabel}
        noLabel={noLabel}
        onYes={onYes}
        onNo={onNo}
        hideModal={hideModal}
        message={message}
      />
    );
  };

  return { confirmationDialog, showConfirmationDialog };
}

export { useConfirmationDialog };
