import { useModal } from "csg-react-magnetic/modal";
import { ConfirmationDialog } from "../ConfirmationDialog";

function useConfirmationDialog() {
  const [confirmationDialog, showModal, hideModal] = useModal();

  // Delay because if you instantly show a Growler it will flicker when the
  // popup and overlay are dismissed.

  const showConfirmationDialog = ({ title, yesLabel, noLabel, onYes, onNo, message }) => {
    console.log("content", message);

    showModal(
      <ConfirmationDialog
        title={title}
        yesLabel={yesLabel}
        noLabel={noLabel}
        onYes={onYes}
        onNo={onNo}
        message={message}
        hideModal={hideModal}
      />
    );
  };

  return { confirmationDialog, showConfirmationDialog };
}

export { useConfirmationDialog };
