import styles from "./MenuBar.module.css";

import { Link } from "react-router-dom";

function MenuBar({ children, className = "", style = {} }) {
/*
        <Link to="/home" className={`${styles.menuItem} underlineFromCenter`}>
          Component Demo
        </Link>
*/
  return (
    <nav className={`${styles.menuBar} ${className}`} style={style}>
      <div>
        <Link to="/components" className={`${styles.menuItem} underlineFromCenter`}>
          Components
        </Link>

        <Link to="/viewOrders" className={`${styles.menuItem} underlineFromCenter`}>
          View Orders
        </Link>

        <Link to="/submitOrder" className={`${styles.menuItem} underlineFromCenter`}>
          Submit Order/Referral
        </Link>

        <Link to="/claimSearch" className={`${styles.menuItem} underlineFromCenter`}>
          Claim Search
        </Link>

        <Link to="/coverage" className={`${styles.menuItem} underlineFromCenter`}>
          Coverage
        </Link>
      </div>
    </nav>
  );
}

export { MenuBar };
