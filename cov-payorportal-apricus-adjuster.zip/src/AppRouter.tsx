import { Switch, Route, Redirect } from "react-router-dom";

import { ClientSearch } from "routes/ClientSearch";
import { Components } from "routes/Components";
import { Coverage } from "routes/Coverage";
import { OrderDetail } from "routes/OrderDetail";
import { ViewOrders } from "routes/ViewOrders";

interface IAppRouterProps {
  baseHref?: string;
}

//       <Route exact path="/orderDetail/:orderNumber/:offlineDataFlag" component={OrderDetail} />

export default function AppRouter({ baseHref }: Readonly<IAppRouterProps>) {
  return (
    <Switch>
      <Route exact path="/components" component={Components} />
      <Route exact path="/clientSearch" component={ClientSearch} />
      <Route exact path="/viewOrders" component={ViewOrders} />
      <Route exact path="/viewOrders" component={ViewOrders} />
      <Route exact path="/orderDetail" component={OrderDetail} />
      <Route exact path="/coverage" component={Coverage} />
      <Route path="*">
        <Redirect to="/clientSearch" />
      </Route>
    </Switch>
  );
}
