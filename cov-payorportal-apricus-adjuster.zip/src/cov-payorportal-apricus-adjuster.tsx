import App from "./App";
import * as Jitux from "cov-jitux-appstore/scripts";

export const mount = Jitux.mount(App);
export const unmount = Jitux.unmount();
export const getMetadata = () => {};
