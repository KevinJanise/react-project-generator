// src/hocs/withLoading.jsx
import React from 'react';
import styles from './withLoading.module.css';

const withLoading = (WrappedComponent, customStyles = {}) => {
  const WithLoading = ({ isLoading, loadingStyles, ...props }) => {
    // Merge default styles with any custom styles
    const containerStyle = { ...customStyles.container };
    const overlayStyle = { ...customStyles.overlay, ...(loadingStyles || {}) };
    
    return (
      <div className={styles.container} style={containerStyle}>
        <WrappedComponent {...props} />
        
        {isLoading && (
          <div className={styles.overlay} style={overlayStyle}>
            <div className={styles.spinner}></div>
          </div>
        )}
      </div>
    );
  };
  
  WithLoading.displayName = `WithLoading(${getDisplayName(WrappedComponent)})`;
  
  return WithLoading;
};

function getDisplayName(WrappedComponent) {
  return WrappedComponent.displayName || WrappedComponent.name || 'Component';
}

export { withLoading };
