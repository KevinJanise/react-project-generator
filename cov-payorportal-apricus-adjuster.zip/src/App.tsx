import "./global.css";

import AppRouter from "./AppRouter";
import { ThemeProvider, getTheme } from "csg-react-magnetic/theming";

import { BrowserRouter } from "react-router-dom";

import { ConfigProvider } from "hooks/config";
import { GrowlerProvider } from "hooks/growler";

import { PageLayout } from "components/PageLayout";

interface IAppProps {
  baseHref?: string;
  jitux?: any;
}

const ConfigLoading = () => <div>Loading configuration...</div>;
const ConfigError = ({ error }: { error: string }) => <div>Error loading configuration: {error}</div>;

const GROWLER_DURATION_MS = 5000;  // 5 seconds

export default function App({ baseHref, jitux }: IAppProps) {
  const configUrl = `${baseHref ?? ""}/dist/config/config.json`;
  
  return (
    <div id="cov-payorportal-apricus-adjuster">
      <ConfigProvider configUrl={configUrl} storageEngine={sessionStorage} loadingComponent={ConfigLoading} errorComponent={ConfigError}>
        <BrowserRouter basename={baseHref ?? "/"}>
          <ThemeProvider theme={getTheme("Enlyte")}>
            <GrowlerProvider defaultDuration={GROWLER_DURATION_MS}>
              <PageLayout>
                <AppRouter baseHref={baseHref} />
              </PageLayout>
            </GrowlerProvider>
          </ThemeProvider>
        </BrowserRouter>
      </ConfigProvider>
    </div>
  );
}
