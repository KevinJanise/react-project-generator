JIRA Location for User Stories

https://jira.corp.int/secure/RapidBoard.jspa?rapidView=443&view=planning&selectedIssue=CAAI-4&issueLimit=100


Wireframes

https://mihub.sharepoint.com/:u:/r/sites/aet-CoventryConnect/_layouts/15/doc2.aspx?sourcedoc=%7BDB79FBF1-BFDC-44E0-9EEB-650C7C7BB460%7D&file=Apricus Wireframe - TO BE.vsdx&action=default&mobileredirect=true&CID=8aca3604-2331-4762-b281-c53d4913373d
