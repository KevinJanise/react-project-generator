module.exports = require("stylelint-config-csg/prettier");
