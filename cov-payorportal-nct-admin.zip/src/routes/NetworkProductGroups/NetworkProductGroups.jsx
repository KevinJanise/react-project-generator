import styles from "./NetworkProductGroups.module.css";

import { useEffect, useState } from "react";

import { useParams } from "react-router-dom";

import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useGrowler } from "hooks/growler";

import { FindNetworkProductGroupsCommand } from "services/FindNetworkProductGroupsCommand";

import { NetworkProductGroupsSearchResults } from "./NetworkProductGroupsSearchResults";

function NetworkProductGroups() {
  const { showSuccessGrowler, showErrorGrowler } = useGrowler();

  const onStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const { execute, isExecuting, cancel } = useCommand();
  const [networkProductList, setNetworkProductList] = useState(null);
  const { clientId } = useParams(); // get clientId from route URL
  const [hasSearched, setHasSearched] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [resultMessage, setResultMessage] = useState(null);

  const showStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  useEffect(() => {
    async function findNetworkProducts(theClientId) {
      setHasSearched(true);

      const command = new FindNetworkProductGroupsCommand(theClientId);
      let result = await execute(command);
      console.log(result);

      if (result.isSuccess) {
        setNetworkProductList(result.value);

        if (result.value.length === 0) {
          setResultMessage("No Network Product Groups were found.");
        }
        console.log(result);
      } else {
        setErrorMessage("Error finding network products: " + result.error);
        console.log(result.error);
      }
    }

    findNetworkProducts(clientId);
  }, [execute, clientId]);

  return (
    <div className={styles.clientSearch}>
      <PageTitle title="Network Product Groups" />

      {hasSearched && (
        <NetworkProductGroupsSearchResults
          networkProductList={networkProductList}
          isLoading={isExecuting}
          resultMessage={resultMessage}
          errorMessage={errorMessage}
          onStatusUpdate={showStatusUpdate}
        />
      )}
    </div>
  );
}

export { NetworkProductGroups };
