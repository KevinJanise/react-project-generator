import styles from "./NetworkProductGroupsTable.module.css";
import { useState } from "react";

import { DataGrid, ColumnResizeMode } from "csg-react-magnetic/data-grid";

import { ButtonBar } from "components/ButtonBar";
import { ToolbarButton } from "components/ToolbarButton";

import { usePageState } from "hooks/usePageState";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

/**
 * ClaimsTable Component
 *
 * This component renders a table of orders using the DataGrid component.
 * It allows for selection of multiple orders and provides pagination functionality.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Array} props.userList - An array of order objects to be displayed in the table
 * @param {Function} props.onOrderSelected - Callback function triggered when orders are selected
 *
 * @example
 * <ClaimsTable
 *   userList={[{claimNum: '123', ...}, {claimNum: '456', ...}]}
 *   onOrderSelected={(selectedOrders) => console.log(selectedOrders)}
 * />
 *
 * @returns {JSX.Element} A div containing a DataGrid component
 */
function NetworkProductGroupsTable({ networkProductList, onTerminate, onEdit, onReactivate }) {
  // headerTemplate is what appears in the table header
  // template is what appears in the row. Create one if you want something custom such as a link
  // otherwise it will use the field in the object array corresponding to the column id
  /*
   {
    "clientNm": "EVEREST GROUP",
    "networkNm": "CA EVEREST MPN CSTM",
    "networkProductGroupNm": "CA EVEREST MPN CSTM",
    "networkProductGroupDesc": "CA EVEREST MPN",
    "stateCd": "CA"
}
    */
  const columnTemplates = [
    {
      id: "clientNm",
      name: "Client",
      sortable: true,
      headerStyle: { minWidth: "175px" }
    },
    {
      id: "networkNm",
      name: "Network Name",
      sortable: true,
      headerStyle: { minWidth: "160px" }
    },
    {
      id: "networkProductGroupNm",
      name: "Network Group Name",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "networkProductGroupDesc",
      name: "Network Product Group Description",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "stateCd",
      name: "State",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "status",
      name: "Status",
      sortable: true,
      headerStyle: { minWidth: "190px" }
    },
    {
      id: "action",
      name: "Action",
      headerStyle: { width: "auto", minWidth: "150px" },
      template: (col, row) => (
        <ButtonBar variant="toolbar">
          <ToolbarButton title="Terminate" icon="delete" disabled={false && !(row.status === "Active")} onClick={() => onTerminate(row.networkProductGroupNm)} />
          <ToolbarButton title="Edit" icon="edit" onClick={() => onEdit(row.networkProductGroupNm)} />
          <ToolbarButton title="Reactivate" icon="revert" disabled={false && !(row.status === "Inactive")} onClick={() => onReactivate(row.networkProductGroupNm)} />
        </ButtonBar>
      )
    }
  ];

  const [columns, setColumns] = useState(columnTemplates);

  const { savePageState, clearPageState } = usePageState(
    "_UserTable",
    pageState => {
      console.log("UserTable pageState", pageState);
      // setColumns(pageState.columns);
    },
    () => {
      console.log("saving columns for UserTable", columns);

      return { columns: columns };
    }
  );

  return (
    <DataGrid className={styles.striped}
      data={networkProductList}
      reorderable={{
        reorderableColumns: true,
        onColumnReorder: e => {
          console.log(e);
          console.log(columns);
        }
      }}
      resizable={{
        columnResizeMode: ColumnResizeMode.Expand,
        onColumnResize: e => {
          console.log(e);
        }
      }}
      columns={columns}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
    />
  );
}

export { NetworkProductGroupsTable };
