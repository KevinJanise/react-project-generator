import styles from "./NetworkProductGroupsSearchResults.module.css";

import { Link, useHistory } from "react-router-dom";

import { useTerminateDialog } from "components/NCTDialogs";
import { useReactivateDialog } from "components/NCTDialogs";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { LoadingIndicator } from "components/LoadingIndicator";
import { PageSection } from "components/PageSection";

import { NetworkProductGroupsTable } from "./NetworkProductGroupsTable";

function NetworkProductGroupsSearchResults({ networkProductList, isLoading, resultMessage, errorMessage, onStatusUpdate }) {
  const hasResults = networkProductList && networkProductList.length > 0;
  const { terminateDialog, showTerminateDialog } = useTerminateDialog(onStatusUpdate);
  const { reactivateDialog, showReactivateDialog } = useReactivateDialog(onStatusUpdate);
  const history = useHistory();

  const handleTerminate = (groupId) => {
    showTerminateDialog(groupId);
  };

  const handleReactivate = (groupId) => {
    showReactivateDialog(groupId);
  };

  const handleEdit = (groupId) => {
    history.push(`/editNetworkProductGroup/${groupId}`);
  };

  return (
    <LoadingIndicator isLoading={isLoading}>
      <PageSection className={styles.groupSearchResults}>
        {!errorMessage && (
          <p className={styles.groupNotFoundMessage}>
            Network Product Group not found?{" "}
            <Link to={"/createNetworkProductGroup"} className={styles.submitOrderLink}>
              Add a new Network Product Group
            </Link>
          </p>
        )}

        {hasResults && (
          <>
            <Grid>
              <Row>
                <Column width="100%">
                  <NetworkProductGroupsTable
                    networkProductList={networkProductList}
                    onTerminate={handleTerminate}
                    onEdit={handleEdit}
                    onReactivate={handleReactivate}
                  />
                </Column>
              </Row>
            </Grid>
          </>
        )}

        <BlockMessage variant="info"> {resultMessage}</BlockMessage>
        <BlockMessage variant="error"> {errorMessage}</BlockMessage>
      </PageSection>

      {terminateDialog}
      {reactivateDialog}
    </LoadingIndicator>
  );
}

export { NetworkProductGroupsSearchResults };
