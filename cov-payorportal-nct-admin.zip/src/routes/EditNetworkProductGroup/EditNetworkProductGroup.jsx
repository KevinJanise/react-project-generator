import styles from "./EditNetworkProductGroup.module.css";

import { useState, useEffect, useCallback } from "react";

import { useParams } from "react-router-dom";

import { Button } from "csg-react-magnetic/button";
import { SingleSelect } from "csg-react-magnetic/single-select";
import { TextArea } from "csg-react-magnetic/text-area";
import { TextField } from "csg-react-magnetic/text-field";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { NotesSection } from "components/NotesSection";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { useStableFunction } from "hooks/useStableFunction";

import { FindNetworkProductGroupCommand } from "services/FindNetworkProductGroupCommand";
import { FindNetworkProductGroupNotesCommand } from "services/FindNetworkProductGroupNotesCommand";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

const STATE_LIST = [
  { id: "AK", name: "Alaska" },
  { id: "LA", name: "Louisiana" },
  { id: "TX", name: "Texas" }
];

const CLIENT_LIST = [
  { id: "GB", name: "Gallagher Basset" },
  { id: "CNA", name: "CNA" },
  { id: "XN", name: "Xynovation" }
];

const PRODUCT_GROUP_NAME_LIST = [
  { id: "groupId-1", name: "Group 1" },
  { id: "groupId-2", name: "Group 2" },
  { id: "groupId-3", name: "Group 3" }
];

function EditNetworkProductGroup() {
  const { groupId } = useParams(); // get order number from route URL

  const [isEditable, setIsEditable] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [notesErrorMessage, setNotesErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [message, setMessage] = useState(null);
  const [noteList, setNoteList] = useState([]);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();

  const { execute, isExecuting, executeAsync } = useCommand();

  let initialFormState = { clientId: null, productGroupName: null, groupDescription: "", networkName: "", state: null, note: undefined };
  const { formData, resetForm, handleMagneticChange, setFormData, trimValue, updateInitialState } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const initForm = useCallback(
    npg => {
      let formValues = {
        clientId: npg.clientId, // maps to id in CLIENT_LIST
        productGroupName: npg.groupId, // maps to id in PRODUCT_GROUP_NAME_LIST
        groupDescription: npg.networkProductGroupDescription,
        networkName: npg.networkName,
        state: npg.state,
        note: ""
      };

      updateInitialState(formValues);
    },
    [updateInitialState]
  );

  useEffect(() => {
    async function findNetworkProduct(groupId) {
      setHasSearched(true);

      const groupCommand = new FindNetworkProductGroupCommand(groupId);
      const noteCommand = new FindNetworkProductGroupNotesCommand(groupId);

      let [groupResult, noteResult] = await executeAsync([groupCommand, noteCommand]);

      console.log(groupResult);
      console.log(noteResult);

      if (noteResult.isError) {
        setNotesErrorMessage("Error retrieving notes.");
      }

      if (groupResult.isSuccess) {
        initForm(groupResult.value);

        setNoteList(noteResult.value);

        showSuccessGrowler(`Found network product group ${groupId}`);
        console.log(groupResult);
      } else {
        setErrorMessage("Error loading network product.");
        setNotesErrorMessage("Error loading notes.");
        console.log(groupResult.error);
        showErrorGrowler("Error loading network product.");
      }
    }

    if (Utils.isNotEmpty(groupId)) {
      findNetworkProduct(groupId);
    } else {
      showSuccessGrowler("No group so this is creating a new one!");
      setIsEditable(true);
    }
  }, [executeAsync, groupId, initForm, showErrorGrowler, showSuccessGrowler]);

  const validateForm = () => {
    clearErrorMessages();

    console.log(formData);

    if (Validator.isEmpty(formData.clientId)) {
      addErrorMessage("clientId", "Please select a client.");
    }

    if (Validator.isEmpty(formData.state)) {
      addErrorMessage("state", "Please select a state.");
    }

    if (Validator.isEmpty(formData.productGroupName)) {
      addErrorMessage("productGroupName", "Please select a Product Group Name.");
    }

    if (Validator.isEmpty(formData.groupDescription)) {
      addErrorMessage("groupDescription", "Please enter a Product Group Description.");
    }

    if (Validator.isEmpty(formData.networkName)) {
      addErrorMessage("networkName", "Please enter a Network Name.");
    }

    if (Validator.isEmpty(formData.note)) {
      addErrorMessage("note", "Please enter a note.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleSaveNetworkProductGroup = async event => {
    event.preventDefault();

    clearSearchResults();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    setHasSearched(true);

    // Save the validated form data but not the client list. Reload list when page reloads.
    //savePageState({ formData: formData, hasSearched: true });

    //    doClaimSearch(formData);

    showSuccessGrowler("Group was saved.");
  };

  const showStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    //    setNotesErrorMessage(null);
    //    setNoteList(null);
    setErrorMessage(null);
    setHasSearched(false);
  };

  const handleClear = () => {
    clearSearchResults();
    resetForm();
  };

  return (
    <div className={styles.editNetworkProductGroup}>
      <PageTitle title="Edit Network Product Group" />

      <PageSection>
        <BlockMessage variant="error" style={{ marginBottom: "1rem" }}>
          <span>{errorMessage}</span>
          <span>{getErrorMessage("global")}</span>
        </BlockMessage>

        <form onSubmit={handleSaveNetworkProductGroup}>
          <Grid>
            <Row>
              <Column width="50%">
                <SingleSelect
                  label="Client"
                  required
                  disabled={!isEditable}
                  name="client"
                  value={formData.clientId}
                  options={CLIENT_LIST}
                  onChange={handleMagneticChange("clientId", "single-select")}
                  validationError={getErrorMessage("clientId")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="50%">
                <SingleSelect
                  label="State"
                  required
                  disabled={!isEditable}
                  name="state"
                  value={formData.state}
                  options={STATE_LIST}
                  onChange={handleMagneticChange("state", "single-select")}
                  validationError={getErrorMessage("state")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="50%">
                <SingleSelect
                  label="Network Product Group Name"
                  required
                  disabled={!isEditable}
                  name="productGroupName"
                  value={formData.productGroupName}
                  options={PRODUCT_GROUP_NAME_LIST}
                  onChange={handleMagneticChange("productGroupName", "single-select")}
                  validationError={getErrorMessage("productGroupName")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="50%">
                <TextField
                  label="Network Product Group Description"
                  value={formData.groupDescription}
                  name="groupDescription"
                  maxLength={100}
                  required
                  onChange={handleMagneticChange("groupDescription", "text")}
                  onBlur={trimValue}
                  validationError={getErrorMessage("groupDescription")}
                />
              </Column>
            </Row>

            <Row>
              <Column width="50%">
                <TextField
                  label="Network Name"
                  value={formData.networkName}
                  name="networkName"
                  disabled={!isEditable}
                  onChange={handleMagneticChange("networkName", "text")}
                  validationError={getErrorMessage("networkName")}
                  onBlur={trimValue}
                />
              </Column>
            </Row>

            <Row>
              <Column width="100%">
                <TextArea
                  label="Note"
                  name="note"
                  required
                  value={formData.note}
                  maxLength={1000}
                  charRemaining="remaining"
                  onChange={handleMagneticChange("note", "text")}
                  onBlur={trimValue}
                  validationError={getErrorMessage("note")}
                  style={{
                    width: "100%",
                    height: "10rem",
                    marginBottom: "2.5rem"
                  }}
                />
              </Column>
            </Row>

            <Row>
              <Column width="100%">
                <Button variant="primary" type="submit" loading={isExecuting} style={{ marginRight: "1rem" }}>
                  Submit
                </Button>

                <Button variant="outline" type="button" onClick={handleClear}>
                  Clear
                </Button>
              </Column>
            </Row>
          </Grid>
        </form>
      </PageSection>

      <NotesSection errorMessage={notesErrorMessage} noteList={noteList} isEditable={true} onStatusUpdate={showStatusUpdate} />
    </div>
  );
}

export { EditNetworkProductGroup };
