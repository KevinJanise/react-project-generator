import styles from "./ClientSearch.module.css";

import { useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { TextField } from "csg-react-magnetic/text-field";

import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";
import { useGrowler } from "hooks/growler";
import { usePageState } from "hooks/usePageState";

import { FindClientsCommand } from "services/FindClientsCommand";

import { ClientSearchResults } from "./ClientSearchResults";

import * as Utils from "utils/Utils";
import * as Validator from "utils/Validator";

function ClientSearch() {
  const [clientList, setClientList] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [message, setMessage] = useState(null);

  const { showSuccessGrowler, showErrorGrowler } = useGrowler();
  const { execute, isExecuting } = useCommand();

  let initialFormState = { clientName: "", clientId: "" };
  const { formData, resetForm, handleMagneticChange, setFormData, trimValue } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  // Repopulate state variables and make service calls to get data when component mounts.
  const { savePageState, clearPageState } = usePageState(
    "_ClientSearch",
    pageState => {
      setFormData(pageState.formData);
      setHasSearched(pageState.hasSearched);
      doClaimSearch(pageState.formData);
    },
    null
  );

  const validateForm = () => {
    clearErrorMessages();

    // if form is empty display an error message
    if (Validator.isEmpty(formData)) {
      addErrorMessage("global", "Please enter search criteria.");
      return false;
    }

    if (Validator.isNotEmpty(formData.clientName) && Validator.length(formData.clientName) < 3) {
      addErrorMessage("clientName", "Enter at least 3 characters.");
    }

    return !hasFieldSpecificErrors();
  };

  const doClaimSearch = async searchCriteria => {
    clearSearchResults();

    setHasSearched(true);

    let command = new FindClientsCommand(searchCriteria);
    let result = await execute(command);

    if (result.isSuccess) {
      let list = result.value;

      setClientList(list);

      if (Utils.isObjectEmpty(list)) {
        setMessage("No clients were found.");
        showSuccessGrowler("No clients were found.");
      } else {
        showSuccessGrowler(list.length === 1 ? "Found 1 client." : `Found ${list.length} clients.`);
      }
    } else {
      let error = result.error;
      let errorMessage = null;

      console.error(error);

      if (error.message === "Failed to fetch") {
        errorMessage = "There was an error connecting to the server.";
      } else {
        errorMessage = "There was an error processing your request.";
      }

      setErrorMessage(errorMessage);
      showErrorGrowler(errorMessage);
    }
  };

  const handleClaimSearch = async event => {
    event.preventDefault();

    clearSearchResults();

    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    setHasSearched(true);

    // Save the validated form data but not the client list. Reload list when page reloads.
    savePageState({ formData: formData, hasSearched: true });

    doClaimSearch(formData);
  };

  const handleStatusUpdate = message => {
    if (message.isSuccess) {
      showSuccessGrowler(message.message);
    } else {
      showErrorGrowler(message.message);
    }
  };

  const clearSearchResults = () => {
    clearErrorMessages();
    setMessage(null);
    setErrorMessage(null);
    setHasSearched(false);
    setClientList(null);
  };

  const handleClear = () => {
    clearSearchResults();
    resetForm();
    clearPageState();
  };

  return (
    <div className={styles.clientSearch}>
      <PageTitle title="Client Search" />

      <PageSection>
        <BlockMessage variant="error" style={{ marginBottom: "1rem" }}>
          {getErrorMessage("global")}
        </BlockMessage>

        <form onSubmit={handleClaimSearch}>
          <Grid>
            <Row>
              <Column width="50%">
                <TextField
                  label="Client Name"
                  name="clientName"
                  onChange={handleMagneticChange("clientName", "text")}
                  value={formData.clientName}
                  validationError={getErrorMessage("clientName")}
                  onBlur={trimValue}
                />
              </Column>

              <Column width="50%">
                <TextField
                  label="Client ID"
                  name="clientId"
                  onChange={handleMagneticChange("clientId", "text")}
                  value={formData.clientId}
                  validationError={getErrorMessage("clientId")}
                  onBlur={trimValue}
                />
              </Column>
            </Row>

            <Row>
              <Column width="100%">
                <Button variant="primary" type="submit" loading={isExecuting} style={{ marginRight: "1rem" }}>
                  Search
                </Button>

                <Button variant="outline" type="button" onClick={handleClear}>
                  Clear
                </Button>
              </Column>
            </Row>
          </Grid>
        </form>
      </PageSection>

      {hasSearched && (
        <ClientSearchResults
          clientList={clientList}
          isLoading={isExecuting}
          resultMessage={message}
          errorMessage={errorMessage}
          onStatusUpdate={handleStatusUpdate}
        />
      )}
    </div>
  );
}

export { ClientSearch };
