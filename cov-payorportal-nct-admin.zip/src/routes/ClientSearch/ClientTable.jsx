import styles from "./ClientTable.module.css";

import { useState } from "react";
import { DataGrid, DataGridSortSelectModeType, DataGridSortOrderType } from "csg-react-magnetic/data-grid";
import { ToolbarButton } from "components/ToolbarButton";
import { ButtonBar } from "components/ButtonBar";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 15, 25];

  /*
  {
    "clientId": "6166",
    "clientNm": "GALLAGHER-BASSETT",
    "clientStatusCd": "ACTIVE"
}
*/

function ClientTable({ clientList, onEdit }) {
  // Setup initial sort order for table. Can sort on multiple columns by listing multiple
  // object in the sortParams array.
  const [sortable, setSortable] = useState({
    sortMode: DataGridSortSelectModeType.Multiple,
    sortParams: [{ sortColumn: "clientNm", sortOrder: DataGridSortOrderType.Ascending }],
    onSort: (sortedColumns) => {
      const params = sortedColumns.multiSort?.map(({ sortColumn, sortOrder }) => ({ sortColumn, sortOrder })) || [];
      setSortable(prev => ({ ...prev, sortParams: params }));
    }
  });

  // headerTemplate: used to control the display in the table column header
  // template: used to control the display in the row for a specific column (the data cell, td element)
const columnTemplates = [
  {
    id: "clientNm",
    name: "Client Name",
    sortable: true,
    headerStyle: { minWidth: "250px" },
//    template: (col, row) => <Link to={`/claimActivity/${row.clientId}`}>{row.clientNm}</Link>,
    headerTemplate: (col, row) => <span>{col.name}</span>
  },
  {
    id: "clientId",
    name: "Client ID",
    sortable: true,
    headerStyle: { minWidth: "150px" },
//    template: (col, row) => <span>{`${row.clientId}`}</span>
  },
  {
    id: "clientStatusCd",
    name: "Status",
    sortable: true,
    headerStyle: { minWidth: "150px" },
//    template: (col, row) => <span>{`${row.clientStatusCd}`}</span>
  },
  {
    id: "action",
    name: "Action",
    headerStyle: { width: "auto", minWidth: "90px" },
    template: (col, row) => (
      <ButtonBar variant="toolbar">
        <ToolbarButton title="Manage Network Product Groups" icon="settings" onClick={() => onEdit(row.clientId)} />
      </ButtonBar>
    )
  }
];

  return (
    <DataGrid className={styles.striped}
      data={clientList}
      columns={columnTemplates}
      sortable={sortable}
      pageable={{
        paginator: true,
        first: 0,
        rowsPerPage: ROWS_PER_PAGE_OPTIONS[0],
        rowsPerPageOption: ROWS_PER_PAGE_OPTIONS
      }}
    />
  );
};

export { ClientTable };
