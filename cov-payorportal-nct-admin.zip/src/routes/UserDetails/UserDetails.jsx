import styles from "./UserDetails.module.css";

import { useState, useEffect } from "react";

import { Link, useParams } from "react-router";

import { LabelValuePair } from "csg-react-magnetic/label-value-pair";

import { useCommand } from "hooks/useCommand";

import { Grid, Row, Column } from "components/Grid";
import { PageSection } from "components/PageSection";
import { PageTitle } from "components/PageTitle";

import { FindUserDetailCommand } from "services/FindUserDetailCommand";
import { LoadingIndicator } from "components/LoadingIndicator";

function UserDetails() {
  const { userId } = useParams(); // get order number from route URL
  const [userDetail, setUserDetail] = useState(null);

  const { execute, isExecuting } = useCommand();

  useEffect(() => {
    async function findUserDetail() {
      console.log("findUserDetail for user: " + userId);

      const findUserDetailCommand = new FindUserDetailCommand(userId);
      let result = await execute(findUserDetailCommand);
      console.log(result);

      if (result.isCanceled) return;

      if (result.isSuccess) {
        setUserDetail(result.value);
      } else {
        console.log(result.error);
      }
    }

    findUserDetail();
  }, [execute, userId]);

  return (
    <div className={styles.userDetails}>
      <PageTitle title="User Details" />

      <LoadingIndicator isLoading={isExecuting}>
        {userDetail && (
          <>
            <PageSection title="User Information">
              <Grid>
                <Row>
                  <Column width="50%">
                    <LabelValuePair label="Client">{userDetail.clientName}</LabelValuePair>
                  </Column>
                </Row>

                <Row>
                  <Column width="50%">
                    <LabelValuePair label="Username">{userDetail.username}</LabelValuePair>
                  </Column>

                  <Column width="50%">
                    <LabelValuePair label="Status">{userDetail.status}</LabelValuePair>
                  </Column>
                </Row>

                <Row>
                  <Column width="50%">
                    <LabelValuePair label="First Name">{userDetail.firstName}</LabelValuePair>
                  </Column>

                  <Column width="50%">
                    <LabelValuePair label="Last Name">{userDetail.lastName}</LabelValuePair>
                  </Column>
                </Row>

                <Row>
                  <Column width="50%">
                    <LabelValuePair label="Email">{userDetail.email}</LabelValuePair>
                  </Column>

                  <Column width="50%">
                    <LabelValuePair label="Phone">{userDetail.phone}</LabelValuePair>
                  </Column>
                </Row>
              </Grid>
            </PageSection>

            <PageSection title="User Entitlements" style={{ marginTop: "1rem" }}>
              <Grid>
                <Row>
                  <Column width="50%">
                    <p>Component goes here</p>
                  </Column>

                  <Column width="50%">
                    <p>Component goes here</p>
                  </Column>
                </Row>
              </Grid>
            </PageSection>

            <PageSection title="Network Product Groups" style={{ marginTop: "1rem" }}>
              <Grid>
                <Row>
                  <Column width="50%">
                    <p>Component goes here</p>
                  </Column>

                  <Column width="50%">
                    <p>Component goes here</p>
                  </Column>
                </Row>
              </Grid>
            </PageSection>
          </>
        )}
      </LoadingIndicator>
    </div>
  );
}

export { UserDetails };
