import { Command } from "services/Command";
import { Config } from "hooks/config";

import * as Utils from "utils/Utils";

class TerminateGroupCommand extends Command {
  static OPERATION = "TERMINATE_GROUP";

  constructor(orderId, options = {}) {
    const config = Config.getInstance();

    // has serviceUrlLocal and endpoint
    let url = `${config.serviceUrlLocal}/order-api/v1/orders/${orderId}`;
    console.log("FindOrderCommand url: " + url);

    // Merge default options this command provides with provided options
    // Any options provided in the options parameter will be used
    /*
    const retryOptionsWithDefaults = {
      maxAttempts: 5,
      baseDelay: 555,
      timeout: 5555,
      ...(options.retryOptions ?? {})
    };
    options.retryOptions = retryOptionsWithDefaults;
*/

    super(url, options);
  }

  async execute() {
    try {
      await Utils.pause(7000);

      return await this.get();
    } catch (error) {
      if (error.response.status === 404) {
        console.log("404 error", error.response);

        return {};
      } else {
        throw error;
      }
    }
  }
}

export { TerminateGroupCommand };
