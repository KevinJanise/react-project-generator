import { Command } from "./Command";
import { Config } from "hooks/config";

class FindClientsCommand extends Command {
  static OPERATION = "FIND_CLIENTS";

  // searchCriteria = {clientName: "someName"} // *** for all
  constructor(searchCriteria, options = {}) {
    const config = Config.getInstance();
    let url = null;
    let endpoint = "/client-api/v1/client-search";
    //https://nct-admin-services.dev.enlyte360.com/client-api/v1/client-search?clientNm=*bas*

    url = `${config.serviceUrl}${endpoint}`;
    super(url);

    this.searchCriteria = searchCriteria;
  }

  prepareSearchParams() {
    let searchParams = {};

    if (this.searchCriteria.clientName) {
      searchParams.clientNm = `*${this.searchCriteria.clientName}*`;
    }

    if (this.searchCriteria.clientId) {
      searchParams.clientId = `${this.searchCriteria.clientId}`;
    }

    return searchParams;
  }

  processSearchResults(results) {
    console.log("processSearchResults: ", results);

    return results;
  }

  async execute() {
    try {
      let searchParams = this.prepareSearchParams();

      console.log(searchParams);

      // searchParams will be translated into query parameters
      let result = await this.get(searchParams);
      console.log("result", result);
      let processedResults = this.processSearchResults(result);

      return processedResults;
    } catch (error) {
      if (error?.response?.status === 404) {
        console.log("404 error", error.response);

        return {};
      }

      throw error;
    }
  }
}

export { FindClientsCommand };
