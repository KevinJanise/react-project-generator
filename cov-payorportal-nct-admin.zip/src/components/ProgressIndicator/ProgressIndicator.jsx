import styles from "./ProgressIndicator.module.css";

// Put in a div and the indicator will be positioned along the top or bottom of it
function ProgressIndicator({isLoading = false, position = "top", className = "", style = {}, ...rest}) {
  return (
    <>
      {isLoading && (
        <div className={`${styles.progressBar} ${styles[position]} ${className}`} style={style} {...rest}>
          <div className={styles.progress}></div>
        </div>
      )}
    </>
  );
}

export { ProgressIndicator };
