import styles from "./PageTitle.module.css";

import { Grid, Row, Column } from "components/Grid";

const PageTitle = ({ title, className = "", style = {}, ...rest }) => (
  <Grid>
    <Row align="left">
      <Column style={{ paddingLeft: "0" }}>
        <h3 className={`${styles.pageTitle} ${className}`} style={style} {...rest} >{title}</h3>
      </Column>
    </Row>
  </Grid>
);

export { PageTitle };
