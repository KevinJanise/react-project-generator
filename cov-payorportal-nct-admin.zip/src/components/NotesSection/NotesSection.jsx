import styles from "./NotesSection.module.css";

import { BlockMessage } from "components/BlockMessage";
import { PageSection } from "components/PageSection";

import { useEditNoteDialog } from "components/EditNoteDialog";

import { NotesTable } from "./NotesTable";

function NotesSection({ noteList, errorMessage, isEditable = false, onStatusUpdate, className = "", style = {}, ...rest }) {
  const combinedClassName = `${styles.notesSection} ${className}`;
  const { editNoteDialog, showEditNoteDialog } = useEditNoteDialog();

  const handleEditNote = (note, user, noteId) => {
    showEditNoteDialog(note, user, noteId, onStatusUpdate);
  };

  const renderContent = () => {
    if (errorMessage) {
      return <BlockMessage variant="error">{errorMessage}</BlockMessage>;
    }

    if (noteList?.length > 0) {
      return <NotesTable noteList={noteList} isEditable={isEditable} onEditNote={handleEditNote} />;
    }

    return (
      <BlockMessage variant="info">
        <span>There are no notes.</span>
      </BlockMessage>
    );
  };

  return (
    <PageSection title="Notes" className={combinedClassName} style={style} {...rest}>
      {renderContent()}

      {editNoteDialog}
    </PageSection>
  );
}

export { NotesSection };
