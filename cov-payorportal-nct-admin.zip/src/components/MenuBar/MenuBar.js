import styles from "./MenuBar.module.css";

import { Link } from "react-router-dom";

function MenuBar({ children, className = "", style = {} }) {
/*
        <Link to="/home" className={`${styles.menuItem} underlineFromCenter`}>
          Component Demo
        </Link>
*/
  return (
    <nav className={`${styles.menuBar} ${className}`} style={style}>
      <div>
        <Link to="/clientSearch" className={`${styles.menuItem} underlineFromCenter`}>
          Client Search
        </Link>
        <Link to="/userSearch" className={`${styles.menuItem} underlineFromCenter`}>
          User Search
        </Link>
      </div>
    </nav>
  );
}

export { MenuBar };
