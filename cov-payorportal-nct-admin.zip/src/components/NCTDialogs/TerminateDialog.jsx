import styles from "./TerminateDialog.module.css";

import { useState } from "react";

import { Button } from "csg-react-magnetic/button";
import { Checkbox } from "csg-react-magnetic/checkbox";
import { Modal } from "csg-react-magnetic/modal";
import { TextArea } from "csg-react-magnetic/text-area";

import { ButtonBar } from "components/ButtonBar";
import { BlockMessage } from "components/BlockMessage";
import { Grid, Row, Column } from "components/Grid";
import { ProgressIndicator } from "components/ProgressIndicator";

import { useCommand } from "hooks/useCommand";
import { useErrorMessages } from "hooks/useErrorMessages";
import { useForm } from "hooks/useForm";

import { TerminateGroupCommand } from "services/TerminateGroupCommand";

import * as Validator from "utils/Validator";

const TerminateDialog = ({ groupName, onStatusUpdate, hideModal }) => {
  const confirmationQuestion = `Are you sure you want to terminate ${groupName}?`;

  const [isOkEnabled, setIsOkEnabled] = useState(false);
  const { execute, isExecuting } = useCommand();

  let initialFormState = { comments: undefined };
  const { formData, handleMagneticChange } = useForm(initialFormState);

  const { addErrorMessage, clearErrorMessages, getErrorMessage, hasFieldSpecificErrors, setFocusOnFirstError } = useErrorMessages();

  const validateForm = () => {
    clearErrorMessages();

    if (Validator.isEmpty(formData.comments)) {
      addErrorMessage("comments", "Please enter a comment.");
    }

    return !hasFieldSpecificErrors();
  };

  const handleTerminateGroup = async () => {
    if (!validateForm()) {
      setFocusOnFirstError();
      return;
    }

    let command = new TerminateGroupCommand(groupName, formData.comments);
    let result = await execute(command);

    if (result.isSuccess) {
      console.log(result);
      hideModal();
      onStatusUpdate({ isSuccess: true, message: `Terminated ${groupName}.` });
    } else {
      let error = result.error;

      console.error(error);

      if (error.message === "Failed to fetch") {
        addErrorMessage("global", `There was an error connecting to the server.`);
      } else {
        addErrorMessage("global", `There was a problem terminating ${groupName}.`);
      }
    }
  };

  const handleCancel = () => {
    hideModal();
    onStatusUpdate({ isSuccess: true, message: "Canceled terminate group!" });
  };

  return (
    <Modal
      title="Terminate Network Product Group"
      onClose={handleCancel}
      footer={
        <ButtonBar className={styles.buttonBar} align="right">
          <Button disabled={!isOkEnabled} onClick={handleTerminateGroup} loading={isExecuting}>
            OK
          </Button>

          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        </ButtonBar>
      }
    >
      <div className={styles.dialogBody}>
        <BlockMessage variant="error" className={styles.blockMessage}>
          {getErrorMessage("global")}
        </BlockMessage>

        <Grid>
          <Row>
            <Column width="100%">
              <p className={styles.question}>{confirmationQuestion}</p>
            </Column>
          </Row>

          <Row>
            <Column width="100%">
              <TextArea
                label="Comments"
                required
                value={formData.comments}
                maxLength={1000}
                charRemaining="remaining"
                onChange={handleMagneticChange("comments", "text")}
                validationError={getErrorMessage("comments")}
                style={{
                  width: "100%",
                  height: "10rem",
                  marginBottom: "2.5rem"
                }}
              />
            </Column>
          </Row>

          <Row>
            <Column width="100%">
              <div className={styles.bulkMessage}>
                <Checkbox
                  required
                  requiredFulfilled={isOkEnabled}
                  checked={isOkEnabled}
                  onChange={setIsOkEnabled}
                  label={`Yes, I'm sure I want to terminate this Network Product Group.`}
                />
              </div>
            </Column>
          </Row>
        </Grid>

        <ProgressIndicator isLoading={isExecuting} position="bottom" />
      </div>
    </Modal>
  );
};

export { TerminateDialog };
