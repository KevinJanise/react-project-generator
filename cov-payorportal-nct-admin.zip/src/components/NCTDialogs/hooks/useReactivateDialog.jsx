import { useModal } from "csg-react-magnetic/modal";
import { ReactivateDialog } from "../ReactivateDialog";

function useReactivateDialog(onStatusUpdate) {
  const [reactivateDialog, showModal, hideModal] = useModal();

  // Delay because if you instantly show a Growler it will flicker when the
  // popup and overlay are dismissed.
  const handleStatusUpdate = message => {
    setTimeout(() => {
      onStatusUpdate(message);
    }, 250);
  };

  const showReactivateDialog = (groupName) => {
    showModal(<ReactivateDialog groupName={groupName} onStatusUpdate={handleStatusUpdate} hideModal={hideModal} />);
  };

  return { reactivateDialog, showReactivateDialog };
}

export { useReactivateDialog };
