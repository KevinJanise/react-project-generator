import { useModal } from "csg-react-magnetic/modal";
import { TerminateDialog } from "../TerminateDialog";

function useTerminateDialog(onStatusUpdate) {
  const [terminateDialog, showModal, hideModal] = useModal();

  // Delay because if you instantly show a Growler it will flicker when the
  // popup and overlay are dismissed.
  const handleStatusUpdate = message => {
    setTimeout(() => {
      onStatusUpdate(message);
    }, 250);
  };

  const showTerminateDialog = (groupName) => {
    showModal(<TerminateDialog groupName={groupName} onStatusUpdate={handleStatusUpdate} hideModal={hideModal} />);
  };

  return { terminateDialog, showTerminateDialog };
}

export { useTerminateDialog };
