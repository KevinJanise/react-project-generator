import styles from "./JitUxPortalCard.module.css";

import { ApplicationCard } from "csg-react-magnetic/application-card";
import { ProductIcon } from "@magnetic/react-components";
import { getTheme, ThemeProvider } from "csg-react-magnetic/theming";

export default function JitUxPortalCard() {
  return (
    <ThemeProvider theme={getTheme("Enlyte")}>
      <ApplicationCard externalLink={false} company={"brandName"} product={"cardName"} icon={<ProductIcon variant="adjusterWorkspace" />}>
        <div style={{ display: "inline-block" }}>{"config.message"}</div>
      </ApplicationCard>
    </ThemeProvider>
  );
}
