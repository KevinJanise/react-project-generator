// LabeledControlGroup.jsx
import React from "react";
import styles from "./LabeledControlGroup.module.css";
import { RequiredIndicator } from "csg-react-magnetic/required-indicator";
import { ErrorMessage } from "components/ErrorMessage";

const LabeledControlGroup = ({
  label,
  children,
  validationError,
  style,
  layout = "column",
  required = false,
  requiredFulfilled = false,
  disabled = false,
  ...rest
}) => {
  const errorId = React.useMemo(() => `${label.replace(/\s+/g, "-").toLowerCase()}-error`, [label]);
  const labelId = React.useMemo(() => `${label.replace(/\s+/g, "-").toLowerCase()}-label`, [label]);

  const childrenWithProps = React.useMemo(
    () =>
      React.Children.map(children, child =>
        React.cloneElement(child, {
          disabled: disabled || child.props.disabled,
          "aria-labelledby": labelId
        })
      ),
    [children, disabled, labelId]
  );

  return (
    <fieldset
      className={`${styles.container} ${styles.labeledControlGroup}`}
      style={style}
      aria-required={required}
      aria-invalid={!!validationError}
      aria-describedby={validationError ? errorId : undefined}
      aria-disabled={disabled}
      {...rest}
    >
      <legend className={styles.legendContainer}>
        <span className={styles.labelWrapper}>
          {required && <RequiredIndicator fulfilled={requiredFulfilled} className={styles.requiredIndicator} />}
          <span id={labelId} className={`magLabel ${styles.label}`}>
            {label}
          </span>
        </span>
      </legend>
      <div className={`${styles.formControl} ${validationError ? styles.error : ""} ${styles[layout]}`}>{childrenWithProps}</div>
      {validationError && <ErrorMessage id={errorId}>{validationError}</ErrorMessage>}
    </fieldset>
  );
};

export { LabeledControlGroup };
