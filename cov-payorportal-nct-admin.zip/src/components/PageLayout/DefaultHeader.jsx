import styles from "./DefaultHeader.module.css";

import { ApplicationHeader, Action, Avatar, NotificationBadge, Toolbar } from "csg-react-magnetic/application-header";
import { Inline } from "csg-react-magnetic/inline";
import { useAuthenticatedUser } from "hooks/useAuthenticatedUser";

function DefaultHeader() {
  let authenticatedUser = useAuthenticatedUser();

  const handleSignOut = () => {
    console.log("handleSignOut - signout avatar");
  };

  const handleOther = () => {
    console.log("handleOther");
  };

  const handleNotifications = () => {
    console.log("handleNotifications");
  };

  const handleHelp = () => {
    console.log("handleHelp");
  };

  return (
    <ApplicationHeader className={`${styles.header}`}>
      <Inline alignY="center" fullWidth justify="between">
        <div>
          <span className={styles.companyName}>NCT</span>
          <span className={styles.productName}>Admin</span>
        </div>

        <Toolbar>
          <Action aria-label="get help" id="help-btn" icon="help-filled-circle" onClick={handleHelp} />

          <NotificationBadge count={7}>
            <Action aria-label="notifications" id="notification-btn" icon={"notification"} onClick={handleNotifications} />
          </NotificationBadge>

          <Avatar
            name={authenticatedUser.name}
            id="sign-out-btn"
            items={[
              { label: "Sign Out", id: "sign-out", icon: "sign-out-right", onChange: handleSignOut },
              { label: "Other", id: "other", onChange: handleOther }
            ]}
          />
        </Toolbar>
      </Inline>
    </ApplicationHeader>
  );
}

export { DefaultHeader };
