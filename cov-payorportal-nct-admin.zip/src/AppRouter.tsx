import { Switch, Route, Redirect } from "react-router-dom";
import { ClientSearch } from "routes/ClientSearch";
import { UserSearch } from "routes/UserSearch";
import { UserDetails } from "routes/UserDetails";
import { NetworkProductGroups } from "routes/NetworkProductGroups";
import { EditNetworkProductGroup } from "routes/EditNetworkProductGroup";

interface IAppRouterProps {
  baseHref?: string;
}

export default function AppRouter({ baseHref }: Readonly<IAppRouterProps>) {
  return (
    <Switch>
      <Route exact path="/clientSearch" component={ClientSearch} />
      <Route exact path="/userSearch" component={UserSearch} />
      <Route exact path="/userDetails/:userId" component={UserDetails} />
      <Route exact path="/networkProductGroups/:clientId" component={NetworkProductGroups} />
      <Route exact path="/editNetworkProductGroup/:groupId" component={EditNetworkProductGroup} />
      <Route exact path="/createNetworkProductGroup" component={EditNetworkProductGroup} />      
      <Route path="*">
        <Redirect to="/clientSearch" />
      </Route>
    </Switch>
  );
}
