The NCT Admin application

Project Documents: https://mihub.sharepoint.com/sites/aet-CoventryConnect/CC_SP_SharedDocuments/Forms/AllItems.aspx?viewpath=%2Fsites%2Faet-CoventryConnect%2FCC_SP_SharedDocuments%2FForms%2FAllItems%2Easpx&id=%2Fsites%2Faet-CoventryConnect%2FCC_SP_SharedDocuments%2FNCT&viewid=3cf05954-c4a0-4d3b-94d4-266f9af4f81a

UI Designs: https://mihub.sharepoint.com/:u:/r/sites/aet-CoventryConnect/_layouts/15/Doc.aspx?sourcedoc=%7B15D23306-9D88-4BBF-AA03-3417E07FF053%7D&file=NCT%20Admin%20Designs.vsdx&action=default&mobileredirect=true

npm install --legacy-peer-deps
